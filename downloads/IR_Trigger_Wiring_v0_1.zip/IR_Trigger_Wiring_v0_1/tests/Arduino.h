#pragma once
#include <cstdint>
#include <cstring>
#include <deque>
#include <vector>
#include <array>
#include <algorithm>
constexpr int HIGH=1, LOW=0, INPUT=0, OUTPUT=1, MSBFIRST=1;
#define MOSI 11
#define MISO 13
#define SCK 12
inline std::array<int,64> modes{}, levels{};
inline unsigned sckRises=0;
inline uint32_t fakeTime=0;
inline void pinMode(int pin,int mode) { modes.at(pin)=mode; }
inline void digitalWrite(int pin,int value) {
  if(pin==SCK && value==HIGH && levels.at(pin)==LOW) ++sckRises;
  levels.at(pin)=value;
}
inline int digitalRead(int) { return 0; }
inline void delay(uint32_t ms) { fakeTime+=ms; }
inline void delayMicroseconds(uint32_t) {}
inline uint32_t millis() { return fakeTime; }
struct MockSerial {
  std::deque<uint8_t> rx;
  std::vector<uint8_t> tx;
  void begin(unsigned) {}
  int available() const { return rx.size(); }
  int read() { if(rx.empty()) return -1; auto b=rx.front(); rx.pop_front(); return b; }
  void print(char b) { tx.push_back(static_cast<uint8_t>(b)); }
  void print(const char* p) { while(*p) print(*p++); }
  void write(uint8_t b) { tx.push_back(b); }
};
inline MockSerial Serial;
