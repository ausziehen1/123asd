Host protocol checks; Linux, g++ with ASAN/UBSAN. Run from the package root:

```sh
g++ -std=c++17 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I tests tests/protocol.cpp -o /tmp/ir-isp-protocol
ASAN_OPTIONS=detect_leaks=0 /tmp/ir-isp-protocol
```

These mocks test packet handling, not electrical ISP timing or an actual AVR target.
