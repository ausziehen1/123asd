#include "Arduino.h"
#include <cassert>
#include <iostream>
// Arduino's .ino preprocessor supplies this forward declaration on device.
uint8_t write_flash_pages(int length);
#include "../ESP32S3_ISP/ESP32S3_ISP.ino"

static void send(std::initializer_list<uint8_t> bytes) {
  Serial.rx.assign(bytes);
  Serial.tx.clear();
  sckRises=0;
  loop();
}
static void expect(std::initializer_list<uint8_t> bytes) {
  assert(Serial.tx==std::vector<uint8_t>(bytes));
}
static void enter() { send({'P',CRC_EOP}); expect({STK_INSYNC,STK_OK}); }

int main() {
  setup();
  assert(modes[RESET]==INPUT && modes[SCK]==INPUT && modes[MOSI]==INPUT && modes[MISO]==INPUT);
  send({'0',CRC_EOP}); expect({STK_INSYNC,STK_OK}); assert(sckRises==0);
  enter();
  send({'V',0x30,0,0,0,CRC_EOP});
  expect({STK_INSYNC,0,STK_OK}); assert(sckRises==32);
  send({'V',0xAC,0xA0,0,0,0x99});
  expect({STK_NOSYNC}); assert(sckRises==0); // Invalid fuse command frame.
  send({'V',0xAC,0xA0}); // Lost USB while sending a fuse command.
  expect({STK_NOSYNC}); assert(sckRises==0 && pmode==0 && modes[RESET]==INPUT);
  enter();
  send({'d',1,1,'F'}); // 257-byte page: reject before buffer access.
  expect({STK_NOSYNC}); assert(sckRises==0 && pmode==0);
  enter();
  send({'d',0,3,'F',1,2,3,CRC_EOP}); // Odd flash payload must not write.
  expect({STK_NOSYNC}); assert(sckRises==0);
  enter();
  param.eepromsize=512;
  here=0;
  send({'d',0,2,'E',1,2,0x99}); // Complete data but invalid end marker.
  expect({STK_NOSYNC}); assert(sckRises==0);
  send({'d',0,2,'E',1}); // Truncated EEPROM data.
  expect({STK_NOSYNC}); assert(sckRises==0 && pmode==0);
  enter();
  send({'d',0,2,'E',1,2,CRC_EOP});
  expect({STK_INSYNC,STK_OK}); assert(sckRises==64);
  param.pagesize=64;
  here=0;
  const uint32_t beforeFlash=fakeTime;
  send({'d',0,4,'F',1,2,3,4,CRC_EOP});
  expect({STK_INSYNC,STK_OK});
  assert(sckRises==160 && fakeTime-beforeFlash>=30); // Page write completion delay.
  send({'d',0,4,'F',1,2,3,4,0x99});
  expect({STK_NOSYNC}); assert(sckRises==0);
  send({'Q',CRC_EOP}); expect({STK_INSYNC,STK_OK});
  assert(pmode==0 && modes[RESET]==INPUT && modes[MOSI]==INPUT && modes[SCK]==INPUT);
  std::cout << "Protocol checks passed: sync, SPI, partial/bad packets, EEPROM/Flash, page wait, bounds, pin release.\n";
}
