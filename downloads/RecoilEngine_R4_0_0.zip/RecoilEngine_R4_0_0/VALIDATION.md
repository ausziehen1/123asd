# Проверка RecoilEngine R4.0.0

Дата: 2026-11-03. Этот отчёт относится к исходникам R4, а не к проверкам из прошлой переписки.

## Сборка для ESP32-S3 — PASS

- PlatformIO Core 6.2.0, espressif32 6.12.0.
- Arduino-ESP32 2.0.17, Xtensa ESP32-S3 GCC 8.4.0 / esp-2021r2-patch5.
- ESP32Async AsyncTCP 3.3.2, ESPAsyncWebServer 3.6.0.
- ESP32-S3-DevKitC-1, flash 4 MB, QIO 80 MHz, Huge APP, CPU 240 MHz.
- USB OTG / TinyUSB, CDC On Boot 0, Arduino / Events / AsyncTCP Core 0.
- Статическая RAM: 75336 / 327680 байт. Это не расход heap работающего AP.
- Flash приложения: 809117 / 3145728 байт.
- Компиляция и линковка прошли, firmware.bin создан. Образ не включён в архив:
  параметры реальной платы следует проверить перед собственной сборкой.
- В заключительной сборке предупреждений компилятора нет.

Зависимости загружены из официальных GitHub-тегов. Локальная проверка использовала
имеющиеся официальные SDK/toolchain через platform_packages и lib_extra_dirs,
поскольку облачной сети недоступен реестр PlatformIO. Поставляемый platformio.ini
использует стандартные пакеты и фиксирует версии библиотек. SDK и библиотеки
для компиляции не изменялись.

## Программные проверки — PASS

Команда: `bash tests/run.sh` (G++ с AddressSanitizer/UndefinedBehaviorSanitizer,
Node.js для встроенного JS). LeakSanitizer отключён из-за среды исполнения.

- 6 исходных групп проверок математики и защит.
- Формулы коэффициентов, шкала 0..150, независимость режимов, бинарный формат,
  CRC, границы значений и строгий разбор целых чисел.
- 15 сценариев самого скетча с заглушками GPIO/USB/RTOS: старт с удержанием,
  reconnect/suspend, просроченные USB-пакеты/возврат, нулевая сила, NVS handshake,
  остановка при настройке, подавление X вместе с шумом, нулевые участки,
  независимые коэффициенты режимов и корректность расширенного поля силы.
- Настоящие функции EngineeringMode.cpp с заглушками сети/NVS: разрешённые и
  запрещённые запросы, Host/Origin/токен, валидация, конфликт ревизий, debounce,
  повтор после ошибки записи, новая редакция во время сохранения, финальный flush,
  задержка выхода до сохранения режима FN, восстановление NVS, повреждённый blob,
  timeout паузы, сбои AP/слушателя, сохранение OFF через restart, обычный cold boot.
- Синтаксическая регрессия ранних прототипов Arduino IDE. Это не запуск GUI IDE
  и не отдельная сборка Arduino Builder 1.6.1.
- Встроенный JS исполнялся в DOM/HTTP harness: очередь без параллельных POST,
  переключение редактируемого режима, общая сила, устаревший ответ GET,
  конфликт другой вкладки и статус ошибки NVS во время выхода.

Банки PATTERN_CLOSE/PATTERN_LONG, таблица прежних MULTIPLIERS (только миграция)
и report_descriptor побайтово совпадают с приложенным R3.3.1. Контролы GPIO7/8
и цветовая индикация изменения силы удалены.

## Что не проверялось

Физическая плата, реальные USB/RF тайминги, электрическая схема, запас стеков и
heap под нагрузкой, отключение питания во время настоящей записи NVS, настоящий
браузер и Windows Arduino IDE. Заглушки не моделируют планирование двух ядер,
сеть, USB-хост или физическую атомарность flash. Результат сборки и этих тестов
не подтверждает фактические 1000 отчётов/с и аппаратную стабильность.

## Вывод тестов

```text
PASS: 6 engine safety regression groups
PASS: tuning defaults, bounds, region gains, profile separation, NVS CRC/atomic decode, strict parser
PASS: 15 actual-sketch integration scenarios (stub hardware)
PASS: actual engineering handlers, authentication, validation, revision conflicts, debounce/retry, concurrent save and shutdown
PASS: engineering NVS boot restore/corrupt fallback
PASS: engineering NVS boot restore/corrupt fallback
PASS: engineering handshake timeout stays paused
PASS: engineering AP/listener failure stays paused with radio off
PASS: engineering AP/listener failure stays paused with radio off
PASS: engineering reboot preserves OFF, cold boot keeps original policy
PASS: engineering reboot preserves OFF, cold boot keeps original policy
PASS: Arduino IDE early-prototype compilation regression
PASS: embedded JS syntax, slider queue, mode isolation, global strength, stale replies, conflicts and exit error status
```
