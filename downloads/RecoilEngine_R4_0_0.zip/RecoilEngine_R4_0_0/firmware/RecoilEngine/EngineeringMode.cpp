#include "EngineeringMode.h"
#include "EngineeringPage.h"
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_random.h>
#include <esp_system.h>
#include <esp_attr.h>
#include <Preferences.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <lwip/tcp.h>
#include <new>
#include <limits.h>

namespace engineering {
std::atomic<bool> pauseRequested{false};
std::atomic<bool> pauseGranted{false};
namespace {
std::atomic<Phase> current{Phase::PLAY};
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
tuning::Profile runtime[2]; // published once before task creation; no later writers
struct Draft {
    tuning::Profile profiles[2];
    uint32_t revision = 0, savedRevision = 0;
    uint32_t changedAt = 0;
    uint16_t strength = tuning::STRENGTH_STEPS;
    bool storageError = false, baseStorageError = false, accepting = false;
} draft;
Preferences storage;
bool storageOpen = false;
bool validStoredConfig = false;
RTC_NOINIT_ATTR uint32_t resumeCookie; // survives software restart; validated before use
static constexpr uint32_t RESUME_MAGIC = 0x53335400u;
bool enabledAtBoot = true, enabledBeforeTuning = true;
uint32_t phaseAt = 0, lastSaveAttempt = 0;
bool attemptedSave = false;
char token[33] = {};

class CheckedServer : public AsyncWebServer {
public:
    CheckedServer() : AsyncWebServer(80) {}
    bool listening() { return _server.status() == LISTEN; }
};
CheckedServer* server = nullptr; // retained until reset: outstanding callbacks may reference it

Draft snapshot() {
    portENTER_CRITICAL(&mux);
    const Draft result = draft;
    portEXIT_CRITICAL(&mux);
    return result;
}
const char* phaseName() {
    switch (current.load(std::memory_order_acquire)) {
    case Phase::TUNING: return "tuning";
    case Phase::SAVING_EXIT: return "saving";
    case Phase::FAULT: return "fault";
    default: return "transition";
    }
}
// Arduino 2.0.17 WiFi.mode(OFF) normally calls stop + deinit internally.
// Idempotent low-level calls also cover a partially failed initialization.
bool radioOff() {
    (void)WiFi.mode(WIFI_OFF);
    const esp_err_t stop = esp_wifi_stop();
    const esp_err_t deinit = esp_wifi_deinit();
    wifi_mode_t mode;
    return (stop == ESP_OK || stop == ESP_ERR_WIFI_NOT_INIT) &&
           (deinit == ESP_OK || deinit == ESP_ERR_WIFI_NOT_INIT) &&
           esp_wifi_get_mode(&mode) == ESP_ERR_WIFI_NOT_INIT;
}
void headers(AsyncWebServerResponse* response) {
    response->addHeader("Cache-Control", "no-store");
    response->addHeader("X-Content-Type-Options", "nosniff");
    response->addHeader("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    response->addHeader("Connection", "close");
}
void reply(AsyncWebServerRequest* request, int code, const String& body) {
    auto* response = request->beginResponse(code, "application/json; charset=utf-8", body);
    headers(response);
    request->send(response);
}
bool hostAllowed(AsyncWebServerRequest* request) {
    return request->host() == "192.168.4.1" || request->host() == "192.168.4.1:80";
}
void configReply(AsyncWebServerRequest* request, const Draft& s) {
    char body[768];
    const auto& a=s.profiles[0]; const auto& b=s.profiles[1];
    snprintf(body, sizeof(body),
        "{\"phase\":\"%s\",\"revision\":%lu,\"savedRevision\":%lu,\"storageError\":%s,\"token\":\"%s\",\"strength\":%u,"
        "\"profiles\":[{\"horizontal\":%d,\"vertical\":%d,\"start\":%d,\"body\":%d,\"tail\":%d},"
        "{\"horizontal\":%d,\"vertical\":%d,\"start\":%d,\"body\":%d,\"tail\":%d}]}",
        phaseName(), (unsigned long)s.revision, (unsigned long)s.savedRevision,
        (s.storageError || s.baseStorageError) ? "true" : "false", token, unsigned(s.strength),
        a.horizontal,a.vertical,a.start,a.body,a.tail,b.horizontal,b.vertical,b.start,b.body,b.tail);
    reply(request,200,body);
}
bool number(AsyncWebServerRequest* request, const char* key, int low, int high, int& out) {
    const auto* parameter = request->getParam(key,true);
    return parameter && tuning::parseInt(parameter->value().c_str(),low,high,out);
}
void update(AsyncWebServerRequest* request) {
    if (!hostAllowed(request) ||
        (request->hasHeader("Origin") && request->getHeader("Origin")->value() != "http://192.168.4.1") ||
        !request->hasHeader("X-Tune-Token") || request->getHeader("X-Tune-Token")->value() != token) {
        reply(request,403,"{\"error\":\"Доступ запрещён\"}"); return;
    }
    if (request->contentLength() > 256 || request->params() != 8) {
        reply(request,400,"{\"error\":\"Некорректный размер или набор параметров\"}"); return;
    }
    const auto* mode = request->getParam("mode",true);
    const int index = !mode ? -1 : mode->value()=="close" ? 0 : mode->value()=="long" ? 1 : -1;
    int h,v,s,b,t,revision,strength;
    if (index < 0 || !number(request,"horizontal",0,100,h) || !number(request,"vertical",0,100,v) ||
        !number(request,"start",-100,100,s) || !number(request,"body",-100,100,b) ||
        !number(request,"tail",-100,100,t) || !number(request,"strength",0,tuning::STRENGTH_STEPS,strength) ||
        !number(request,"revision",0,1000000000,revision)) {
        reply(request,400,"{\"error\":\"Параметры вне допустимого диапазона\"}"); return;
    }
    tuning::Profile staged;
    staged.horizontal=h; staged.vertical=v; staged.start=s; staged.body=b; staged.tail=t;
    const uint32_t now=millis();
    int error=0;
    Draft accepted;
    portENTER_CRITICAL(&mux);
    if (!draft.accepting) error=503;
    else if (draft.revision != uint32_t(revision)) error=409;
    else if (!tuning::equal(draft.profiles[index],staged) || draft.strength!=strength) {
        if (draft.revision >= 1000000000u) error=409;
        else { draft.profiles[index]=staged; draft.strength=uint16_t(strength); ++draft.revision; draft.changedAt=now; }
    }
    accepted=draft;
    portEXIT_CRITICAL(&mux);
    if (error) {
        reply(request,error,error==409 ? "{\"error\":\"Конфликт версии; обновите страницу\"}" : "{\"error\":\"Режим настройки завершается\"}");
        return;
    }
    configReply(request,accepted); // exact accepted revision, even if another client writes next
}
bool startAP() {
    WiFi.persistent(false);
    const IPAddress ip(192,168,4,1), mask(255,255,255,0);
    if (!WiFi.mode(WIFI_AP) || !WiFi.softAPConfig(ip,ip,mask) ||
        !WiFi.softAP(ENGINEERING_AP_SSID, ENGINEERING_AP_PASSWORD, 1, false, 2)) return false;
    // RF is active now: ESP hardware RNG has its Wi-Fi entropy source available.
    for (unsigned i=0; i<4; ++i) snprintf(token+i*8,9,"%08lx",(unsigned long)esp_random());
    server = new (std::nothrow) CheckedServer();
    if (!server) return false;
    server->on("/",HTTP_GET,[](AsyncWebServerRequest* r) {
        if (!hostAllowed(r)) { reply(r,403,"{\"error\":\"Неверный Host\"}"); return; }
        auto* response=r->beginResponse(200,"text/html; charset=utf-8",
            reinterpret_cast<const uint8_t*>(ENGINEERING_HTML),sizeof(ENGINEERING_HTML)-1);
        headers(response); r->send(response);
    });
    server->on("/api/config",HTTP_GET,[](AsyncWebServerRequest* r) {
        if (!hostAllowed(r)) { reply(r,403,"{\"error\":\"Неверный Host\"}"); return; }
        configReply(r,snapshot());
    });
    server->on("/update",HTTP_POST,update);
    server->onNotFound([](AsyncWebServerRequest* r) {reply(r,404,"{\"error\":\"Не найдено\"}");});
    server->begin();
    return server->listening();
}
bool saveDraft(const Draft& s) {
    if (!storageOpen) storageOpen=storage.begin("recoil_tune",false);
    uint8_t blob[tuning::BLOB_SIZE], check[tuning::BLOB_SIZE];
    tuning::encode(s.profiles,blob,s.strength);
    const bool ok=storageOpen && storage.putBytes("config",blob,sizeof(blob))==sizeof(blob) &&
                  storage.getBytesLength("config")==sizeof(check) &&
                  storage.getBytes("config",check,sizeof(check))==sizeof(check) &&
                  memcmp(blob,check,sizeof(blob))==0;
    portENTER_CRITICAL(&mux);
    draft.storageError=!ok;
    if (ok) draft.savedRevision=s.revision; // newer concurrent updates remain dirty
    portEXIT_CRITICAL(&mux);
    return ok;
}
void fault() {
    portENTER_CRITICAL(&mux); draft.accepting=false; portEXIT_CRITICAL(&mux);
    current.store(Phase::FAULT,std::memory_order_release);
    if (server) server->end();
    (void)radioOff();
    // Keep pauseRequested asserted. A physical second press may restart safely.
}
} // namespace

bool begin() {
    const uint32_t cookie=resumeCookie; resumeCookie=0;
    if (esp_reset_reason()==ESP_RST_SW && (cookie & ~1u)==RESUME_MAGIC)
        enabledAtBoot=(cookie & 1u)!=0;
    if (!radioOff()) return false;
    storageOpen=storage.begin("recoil_tune",false);
    bool error=!storageOpen;
    if (storageOpen && storage.isKey("config")) {
        uint8_t blob[tuning::BLOB_SIZE];
        error=storage.getBytesLength("config")!=sizeof(blob) ||
              storage.getBytes("config",blob,sizeof(blob))!=sizeof(blob) ||
              !tuning::decode(blob,sizeof(blob),runtime,&draft.strength);
        validStoredConfig=!error;
    }
    draft.profiles[0]=runtime[0]; draft.profiles[1]=runtime[1]; draft.storageError=error;
    return true; // bad/missing NVS uses validated defaults, with visible warning
}
int adoptLegacyStrength(int fallbackStep) {
    if (!validStoredConfig) draft.strength=uint16_t(fallbackStep<0?0:fallbackStep>tuning::STRENGTH_STEPS?tuning::STRENGTH_STEPS:fallbackStep);
    return draft.strength;
}
bool bootEnabled() {return enabledAtBoot;}
const tuning::Profile& runtimeProfile(bool longMode) {return runtime[longMode ? 1 : 0];}
Phase phase() {return current.load(std::memory_order_acquire);}
bool active() {return phase()!=Phase::PLAY;}
bool storageFault() {const Draft s=snapshot(); return s.storageError || s.baseStorageError;}
void buttonPressed(uint32_t now, bool enabled) {
    if (phase()==Phase::PLAY) {
        enabledBeforeTuning=enabled;
        phaseAt=now;
        current.store(Phase::WAIT_PAUSE,std::memory_order_release);
        pauseRequested.store(true,std::memory_order_release);
    } else if (phase()==Phase::TUNING) {
        // Same lock as /update: every accepted update is included, later updates rejected.
        portENTER_CRITICAL(&mux); draft.accepting=false; portEXIT_CRITICAL(&mux);
        current.store(Phase::SAVING_EXIT,std::memory_order_release);
        attemptedSave=false; // force final flush even if debounce/rate limit has not elapsed
    } else if (phase()==Phase::FAULT) {
        resumeCookie=RESUME_MAGIC | (enabledBeforeTuning ? 1u : 0u);
        ESP.restart(); // no edited draft can exist on AP/handshake startup failure
    }
}
void service(uint32_t now, bool baseSettingsSaved) {
    const Phase state=phase();
    if (state==Phase::PLAY || state==Phase::FAULT) return;
    if (state==Phase::WAIT_PAUSE) {
        if (pauseGranted.load(std::memory_order_acquire)) {
            portENTER_CRITICAL(&mux); draft.baseStorageError=!baseSettingsSaved; portEXIT_CRITICAL(&mux);
            if (!baseSettingsSaved) return; // finish any earlier FN-mode NVS write first
            // Driver/HTTP allocation only AFTER the only HID sender acknowledges pause.
            // Publish the ready state before the listener becomes reachable.
            current.store(Phase::TUNING,std::memory_order_release);
            portENTER_CRITICAL(&mux); draft.accepting=true; portEXIT_CRITICAL(&mux);
            if (!startAP()) {fault();return;}
        } else if (uint32_t(now-phaseAt)>=2000) fault();
        return;
    }
    if (state==Phase::STOPPING) {
        if (uint32_t(now-phaseAt)>=200) {
            resumeCookie=RESUME_MAGIC | (enabledBeforeTuning ? 1u : 0u);
            ESP.restart();
        }
        return;
    }
    if (!pauseGranted.load(std::memory_order_acquire)) {fault();return;}
    portENTER_CRITICAL(&mux); draft.baseStorageError=!baseSettingsSaved; portEXIT_CRITICAL(&mux);
    Draft s=snapshot();
    const bool dirty=s.revision!=s.savedRevision;
    const bool due=!attemptedSave || uint32_t(now-lastSaveAttempt)>=2000;
    if (dirty && due && (state==Phase::SAVING_EXIT || uint32_t(now-s.changedAt)>=600)) {
        attemptedSave=true;lastSaveAttempt=now;
        (void)saveDraft(s);
        s=snapshot();
    }
    if (state==Phase::SAVING_EXIT && s.revision==s.savedRevision && baseSettingsSaved) {
        if (server) server->end();
        storage.end();storageOpen=false;
        // AsyncTCP's task/queue has no supported teardown in the pinned library.
        // Do not delete a server with outstanding callbacks. Reset reclaims all of it.
        (void)radioOff();
        current.store(Phase::STOPPING,std::memory_order_release);
        phaseAt=now;
    }
}
} // namespace engineering
