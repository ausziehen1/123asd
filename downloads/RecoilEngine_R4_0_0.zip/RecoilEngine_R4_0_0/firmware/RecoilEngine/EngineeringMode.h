#pragma once
#include <atomic>
#include <stdint.h>
#include "EngineeringConfig.h"
#include "TuningModel.h"

namespace engineering {
enum class Phase : uint8_t { PLAY, WAIT_PAUSE, TUNING, SAVING_EXIT, STOPPING, FAULT };
extern std::atomic<bool> pauseRequested;
extern std::atomic<bool> pauseGranted;
// Called before creating either task; no AP/server/TCP initialization here.
bool begin();
// Setup migration, called only before task creation.
int adoptLegacyStrength(int fallbackStep);
bool bootEnabled();
// Single writer for these operations: ControlTask, Core 0.
void buttonPressed(uint32_t nowMs, bool enabled=true);
void service(uint32_t nowMs, bool baseSettingsSaved);
Phase phase();
bool active();
bool storageFault();
// Immutable after begin(); HTTP only edits a separate draft, applied by reboot.
const tuning::Profile& runtimeProfile(bool longMode);
} // namespace engineering
