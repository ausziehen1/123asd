#pragma once
#include <Arduino.h>
static const char ENGINEERING_HTML[] PROGMEM = R"rawliteral(<!doctype html>
<html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Настройка траектории · ESP32-S3</title>
<style>
:root{color-scheme:dark;font:16px system-ui,sans-serif;background:#10151e;color:#e5edf8}
*{box-sizing:border-box}body{max-width:850px;margin:auto;padding:32px 20px 60px}h1{font-size:30px;margin:6px 0 12px}
p{line-height:1.6;color:#aab8cb}.tag{font-size:12px;letter-spacing:.15em;color:#8fc7ff}.card{background:#182231;border:1px solid #2d3c52;border-radius:18px;padding:24px;margin:20px 0}
nav{display:flex;gap:10px}button{background:#26374e;border:1px solid #40546f;color:#e5edf8;padding:12px 20px;border-radius:10px;font:inherit;cursor:pointer}
button[aria-selected=true]{background:#a7d4ff;color:#102033;border-color:#a7d4ff}button:disabled,input:disabled{opacity:.5;cursor:default}
.row{padding:17px 0;border-bottom:1px solid #2d3c52}.row:last-child{border:0}.line{display:flex;justify-content:space-between;gap:20px}output{color:#a7d4ff;font-variant-numeric:tabular-nums;white-space:nowrap}
input{width:100%;margin:18px 0 4px;accent-color:#a7d4ff}small{color:#aab8cb;line-height:1.5;display:block}.status{min-height:48px;padding:14px 18px;border-left:3px solid #a7d4ff;background:#182231;line-height:1.5}.error{border-color:#ffb294;color:#ffb294}h2{font-size:18px;margin:8px 0}
</style>
<body><div class="tag">ESP32-S3 / ИНЖЕНЕРНЫЙ РЕЖИМ</div><h1>Настройка траектории</h1>
<p>Генерация движений приостановлена. Выберите режим и настройте его независимо от второго.
После сохранения нажмите физическую кнопку настройки: устройство перезапустится и применит коэффициенты.</p>
<div class="status" id="status" role="status" aria-live="polite">Подключение к контроллеру…</div>
<section class="card"><div class="line"><label for="strength">Общая сила</label><output id="strengthValue" for="strength">3,00× · 150/150</output></div>
<input id="strength" type="range" min="0" max="150" step="1" value="150" disabled>
<small>Для обоих режимов. 150 шагов от 0 до 3,00: шаг 0,02, каждые 10 шагов — 0,20. Изменяется только здесь, кнопок силы нет.</small></section>
<section class="card"><nav role="tablist" aria-label="Режим траектории">
<button type="button" role="tab" id="close" aria-selected="true" disabled>Ближний</button>
<button type="button" role="tab" id="long" aria-selected="false" disabled>Дальний</button></nav>
<div class="row"><div class="line"><label for="horizontal">Компрессия горизонтального шума</label><output id="horizontalValue" for="horizontal">100%</output></div>
<input id="horizontal" type="range" min="0" max="100" step="1" value="100" disabled>
<small>100% — исходное горизонтальное движение, включая шум. 0% — все смещения X отключены.</small></div>
<div class="row"><div class="line"><label for="vertical">Компрессия вертикали паттерна</label><output id="verticalValue" for="vertical">100%</output></div>
<input id="vertical" type="range" min="0" max="100" step="1" value="100" disabled>
<small>100% — форма текущего пресета. 0% — ровная вертикальная основа; вертикальный микрошум остаётся.</small></div>
</section><section class="card"><h2>Компрессия участков траектории</h2>
<small>Меняется величина смещения, время прохождения сохраняется: −100% = 0×, 0% = 1×, +100% = 2×.</small>
<div class="row"><div class="line"><label for="start">Начало · сегменты 1–6</label><output id="startValue" for="start">0%</output></div><input id="start" type="range" min="-100" max="100" step="1" value="0" disabled></div>
<div class="row"><div class="line"><label for="body">Тело · сегменты 7–18</label><output id="bodyValue" for="body">0%</output></div><input id="body" type="range" min="-100" max="100" step="1" value="0" disabled></div>
<div class="row"><div class="line"><label for="tail">Хвост · сегменты 19–30 и повторения</label><output id="tailValue" for="tail">0%</output></div><input id="tail" type="range" min="-100" max="100" step="1" value="0" disabled></div>
</section><small>Дождитесь «Сохранено во флеш» перед выходом. При ошибке записи устройство останется в режиме настройки.
Для проверки движения выйдите из этого режима; при работающем Wi-Fi HID-движения не выдаются.</small>
<script>
'use strict';
const keys=['horizontal','vertical','start','body','tail'];
let profiles=[],strength=150,mode=0,revision=0,savedRevision=0,token='',busy=false,failed=false,ready=false,timer;
let pending=[false,false];
const status=document.getElementById('status');
function message(text,error=false){status.textContent=text;status.classList.toggle('error',error);}
function enable(value){for(const e of document.querySelectorAll('button,input'))e.disabled=!value;}
function draw(){keys.forEach(k=>{document.getElementById(k).value=profiles[mode][k];document.getElementById(k+'Value').textContent=(profiles[mode][k]>0&&['start','body','tail'].includes(k)?'+':'')+profiles[mode][k]+'%';});document.getElementById('strength').value=strength;document.getElementById('strengthValue').textContent=(strength*0.02).toFixed(2).replace('.',',')+'× · '+strength+'/150';['close','long'].forEach((id,i)=>document.getElementById(id).setAttribute('aria-selected',String(mode===i)));}
async function api(url,options={}){const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),5000);try{const r=await fetch(url,{cache:'no-store',...options,signal:controller.signal});const data=await r.json();if(!r.ok)throw new Error(r.status===409?'Настройки изменены в другой вкладке. Обновите страницу.':(data.error||'Ошибка HTTP '+r.status));return data;}finally{clearTimeout(timeout);}}
function showState(s){savedRevision=s.savedRevision;if(s.phase!=='tuning'){ready=false;enable(false);message(s.storageError?'Ошибка NVS: выход приостановлен, запись будет повторена.':s.phase==='saving'?'Завершение: сохранение во флеш…':'Режим настройки завершается.',s.storageError);return;}if(s.storageError)message('Ошибка NVS: изменения ещё не сохранены. Контроллер повторит запись.',true);else if(busy||pending.some(Boolean))message('Отправка изменений…');else if(savedRevision===revision)message('Сохранено во флеш · можно выйти кнопкой на устройстве');else message('Принято контроллером · ожидается сохранение во флеш…');}
function fail(e){failed=true;ready=false;enable(false);message(e.message+' Проверьте подключение к точке доступа и обновите страницу.',true);}
async function pump(){if(busy||failed||!ready)return;const index=pending.findIndex(Boolean);if(index<0)return;pending[index]=false;busy=true;const snapshot={...profiles[index],strength};message('Отправка изменений…');try{const data=await api('/update',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Tune-Token':token},body:new URLSearchParams({mode:index===0?'close':'long',revision:String(revision),...snapshot})});revision=data.revision;busy=false;showState(data);if(pending.some(Boolean))pump();}catch(e){busy=false;fail(e);}}
keys.forEach(k=>document.getElementById(k).addEventListener('input',()=>{if(!ready)return;profiles[mode][k]=Number(document.getElementById(k).value);pending[mode]=true;draw();message('Отправка изменений…');clearTimeout(timer);timer=setTimeout(pump,60);}));
document.getElementById('strength').addEventListener('input',()=>{if(!ready)return;strength=Number(document.getElementById('strength').value);pending[mode]=true;draw();message('Отправка изменений…');clearTimeout(timer);timer=setTimeout(pump,60);});
['close','long'].forEach((id,index)=>document.getElementById(id).addEventListener('click',()=>{mode=index;draw();pump();}));
async function poll(){if(failed)return;try{const s=await api('/api/config');if(s.revision<revision)return;if(s.revision!==revision&&!busy&&!pending.some(Boolean))throw new Error('Настройки изменены в другой вкладке. Обновите страницу.');showState(s);}catch(e){fail(e);}}
api('/api/config').then(s=>{profiles=s.profiles;strength=s.strength;revision=s.revision;token=s.token;ready=s.phase==='tuning';draw();enable(ready);showState(s);setInterval(poll,1000);}).catch(fail);
window.addEventListener('beforeunload',e=>{if(busy||pending.some(Boolean)||savedRevision!==revision){e.preventDefault();e.returnValue='';}});
</script></body></html>)rawliteral";
