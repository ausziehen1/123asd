#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_build_dir=$(mktemp -d)
trap 'rm -rf "$test_build_dir"' EXIT
cxx=${CXX:-g++}
# LeakSanitizer cannot run under the cloud executor's ptrace. ASan and UBSan stay on.
export ASAN_OPTIONS="${ASAN_OPTIONS:+$ASAN_OPTIONS:}detect_leaks=0"
"$cxx" -std=c++11 -Wall -Wextra -Werror -fsanitize=address,undefined -g \
    tests/test_engine_safety.cpp -o "$test_build_dir/safety"
"$test_build_dir/safety"
"$cxx" -std=c++11 -Wall -Wextra -Werror -fsanitize=address,undefined -g \
    tests/test_tuning.cpp -o "$test_build_dir/tuning"
"$test_build_dir/tuning"
"$cxx" -std=c++11 -Itests/stubs -Wall -Wextra -Wno-unused-function \
    -Wno-unused-parameter -Wno-unused-variable -fsanitize=address,undefined -g \
    tests/test_engine_integration.cpp -o "$test_build_dir/integration"
"$test_build_dir/integration"
"$cxx" -std=c++11 -Itests/stubs -Wall -Wextra -Werror -Wno-unused-function \
    -Wno-unused-parameter -Wno-unused-variable -fsanitize=address,undefined -g \
    tests/test_engineering.cpp -o "$test_build_dir/engineering"
for scenario in normal restore corrupt timeout apfail listenfail bootdisabled coldboot; do
    "$test_build_dir/engineering" "$scenario"
done
"$cxx" -std=c++11 -Itests/stubs -Wall -Wextra -Wno-unused-function \
    -Wno-unused-parameter -Wno-unused-variable -fsyntax-only \
    tests/test_arduino_prototypes.cpp
printf '%s\n' 'PASS: Arduino IDE early-prototype compilation regression'
if command -v node >/dev/null 2>&1; then
    node tests/test_page.mjs
else
    printf '%s\n' 'SKIP: embedded JS tests (Node.js is not installed)'
fi
