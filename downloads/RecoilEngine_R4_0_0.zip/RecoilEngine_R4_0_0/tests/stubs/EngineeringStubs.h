#pragma once
#include "../../firmware/RecoilEngine/EngineeringMode.h"
namespace fake { static tuning::Profile calibration[2]; }
namespace engineering {
std::atomic<bool> pauseRequested{false}, pauseGranted{false};
bool begin(){return true;}
int adoptLegacyStrength(int fallback){return fallback;}
bool bootEnabled(){return true;}
void buttonPressed(uint32_t,bool){}
void service(uint32_t,bool){}
Phase phase(){return Phase::PLAY;}
bool active(){return false;}
bool storageFault(){return false;}
const tuning::Profile& runtimeProfile(bool longMode){return fake::calibration[longMode?1:0];}
}
