#pragma once
#include "HardwareStubs.h"
#include <memory>
using String=std::string;
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(p) ((void)(p))
#define portEXIT_CRITICAL(p) ((void)(p))
#define WIFI_OFF 0
#define WIFI_AP 2
#define ESP_ERR_WIFI_NOT_INIT 99
#define ESP_RST_SW 3
#define LISTEN 1
#define HTTP_GET 1
#define HTTP_POST 2
using wifi_mode_t=int;
namespace fake {
struct Restart{};
static bool wifiInitialized=false, wifiStarted=false, apOk=true, listenerOk=true;
static int apStarts=0,restarts=0,serverEnds=0;
static int resetReason=1;
}
inline int esp_reset_reason(){return fake::resetReason;}
inline int esp_wifi_stop(){if(!fake::wifiInitialized)return ESP_ERR_WIFI_NOT_INIT;fake::wifiStarted=false;return ESP_OK;}
inline int esp_wifi_deinit(){if(!fake::wifiInitialized)return ESP_ERR_WIFI_NOT_INIT;fake::wifiInitialized=false;return ESP_OK;}
inline int esp_wifi_get_mode(wifi_mode_t* m){if(!fake::wifiInitialized)return ESP_ERR_WIFI_NOT_INIT;*m=WIFI_AP;return ESP_OK;}
struct IPAddress{IPAddress(int,int,int,int){}};
struct FakeWiFi {
 void persistent(bool){}
 bool mode(int mode){if(mode==WIFI_OFF){fake::wifiStarted=fake::wifiInitialized=false;}else{fake::wifiInitialized=true;}return true;}
 bool softAPConfig(IPAddress,IPAddress,IPAddress){return true;}
 bool softAP(const char*,const char*,int,bool,int){++fake::apStarts;fake::wifiStarted=fake::apOk;return fake::apOk;}
};
static FakeWiFi WiFi;
struct FakeESP{void restart(){++fake::restarts;throw fake::Restart();}};
static FakeESP ESP;
struct AsyncWebServerResponse {
 int code;String body;std::map<String,String> headers;
 AsyncWebServerResponse(int c,const String& b):code(c),body(b){}
 void addHeader(const String& k,const String& v){headers[k]=v;}
};
struct AsyncWebParameter {String text;const String& value() const{return text;}};
using AsyncWebHeader=AsyncWebParameter;
struct AsyncWebServerRequest {
 String hostName="192.168.4.1";size_t length=80;
 std::map<String,AsyncWebParameter> fields,headers;
 std::unique_ptr<AsyncWebServerResponse> response;
 const String& host()const{return hostName;}
 size_t contentLength()const{return length;}
 size_t params()const{return fields.size();}
 const AsyncWebParameter* getParam(const char* k,bool)const{auto i=fields.find(k);return i==fields.end()?nullptr:&i->second;}
 bool hasHeader(const char* k)const{return headers.count(k);}
 const AsyncWebHeader* getHeader(const char* k)const{return &headers.at(k);}
 AsyncWebServerResponse* beginResponse(int c,const String&,const String& b){return new AsyncWebServerResponse(c,b);}
 AsyncWebServerResponse* beginResponse_P(int c,const String&,const char* b){return new AsyncWebServerResponse(c,b);}
 AsyncWebServerResponse* beginResponse(int c,const String&,const uint8_t* b,size_t n){return new AsyncWebServerResponse(c,String((const char*)b,n));}
 void send(AsyncWebServerResponse* r){response.reset(r);}
};
using Handler=std::function<void(AsyncWebServerRequest*)>;
class AsyncWebServer {
protected:
 struct Listener{uint8_t status(){return fake::listenerOk?LISTEN:0;}} _server;
public:
 std::map<String,Handler> routes;Handler missing;
 explicit AsyncWebServer(int){}
 void on(const String& path,int,Handler cb){routes[path]=cb;}
 void onNotFound(Handler cb){missing=cb;}
 void begin(){}
 void end(){++fake::serverEnds;}
};
