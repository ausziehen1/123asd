// Execute the actual HTTP handlers and lifecycle with sequential network/NVS mocks.
// Does not emulate RF, TCP scheduling, browser behavior or physical power loss.
#include "../firmware/RecoilEngine/EngineeringMode.cpp"
#include <cassert>
using namespace engineering;
AsyncWebServerRequest request(const char* mode, int revision) {
    AsyncWebServerRequest r;
    r.headers["Origin"].text="http://192.168.4.1";
    r.headers["X-Tune-Token"].text=token;
    r.fields["mode"].text=mode;r.fields["revision"].text=std::to_string(revision);
    r.fields["horizontal"].text="100";r.fields["vertical"].text="100";
    r.fields["start"].text="0";r.fields["body"].text="0";r.fields["tail"].text="0";
    r.fields["strength"].text=std::to_string(snapshot().strength);
    return r;
}
int post(AsyncWebServerRequest& r) {server->routes.at("/update")(&r);return r.response->code;}
int main(int argc,char** argv) {
    fake::end=20000000;
    const std::string scenario=argc>1?argv[1]:"normal";
    if(scenario=="bootdisabled"||scenario=="coldboot") {
        resumeCookie=RESUME_MAGIC;fake::resetReason=scenario=="bootdisabled"?ESP_RST_SW:1;
        assert(begin());assert(bootEnabled()==(scenario=="coldboot"));assert(resumeCookie==0);
        std::puts("PASS: engineering reboot preserves OFF, cold boot keeps original policy");return 0;
    }
    if(scenario=="restore"||scenario=="corrupt") {
        tuning::Profile seed[2];seed[0].start=-35;seed[1].horizontal=28;
        uint8_t blob[tuning::BLOB_SIZE];tuning::encode(seed,blob,123);
        if(scenario=="corrupt")blob[9]^=1;
        storage.putBytes("config",blob,sizeof(blob));assert(begin());
        if(scenario=="restore") {
            assert(tuning::equal(runtimeProfile(false),seed[0]));
            assert(tuning::equal(runtimeProfile(true),seed[1]));assert(!storageFault());
            assert(adoptLegacyStrength(50)==123);
        } else {assert(runtimeProfile(false).start==0&&runtimeProfile(true).horizontal==100);assert(storageFault());assert(adoptLegacyStrength(50)==50);}
        std::puts("PASS: engineering NVS boot restore/corrupt fallback");return 0;
    }
    assert(begin());assert(!fake::wifiInitialized&&fake::apStarts==0);
    assert(adoptLegacyStrength(150)==150);
    buttonPressed(10,false);assert(pauseRequested.load());service(11,true);assert(fake::apStarts==0);
    if(scenario=="timeout") {
        service(2010,true);assert(phase()==Phase::FAULT&&pauseRequested.load()&&fake::apStarts==0);
        std::puts("PASS: engineering handshake timeout stays paused");return 0;
    }
    if(scenario=="apfail")fake::apOk=false;
    if(scenario=="listenfail")fake::listenerOk=false;
    pauseGranted.store(true);service(12,true);
    if(scenario=="apfail"||scenario=="listenfail") {
        assert(phase()==Phase::FAULT&&pauseRequested.load()&&!fake::wifiInitialized);
        std::puts("PASS: engineering AP/listener failure stays paused with radio off");return 0;
    }
    assert(phase()==Phase::TUNING&&fake::apStarts==1);
    AsyncWebServerRequest page;server->routes.at("/")(&page);
    assert(page.response->code==200&&page.response->body.find("<html lang=\"ru\">")!=std::string::npos);
    assert(page.response->headers.count("Content-Security-Policy"));
    {
        auto r=request("close",0);r.hostName="evil.example";assert(post(r)==403);
        r=request("close",0);r.headers["Origin"].text="http://evil.example";assert(post(r)==403);
        r=request("close",0);r.headers.erase("X-Tune-Token");assert(post(r)==403);
        r=request("close",0);r.fields["vertical"].text="101";assert(post(r)==400);
        r=request("close",0);r.fields["tail"].text="-101";assert(post(r)==400);
        r=request("close",0);r.fields["start"].text="1.5";assert(post(r)==400);
        r=request("close",0);r.fields["body"].text=" 1";assert(post(r)==400);
        r=request("other",0);assert(post(r)==400);
        r=request("close",0);r.fields["strength"].text="151";assert(post(r)==400);
        r=request("close",0);r.length=257;assert(post(r)==400);
        assert(snapshot().revision==0);
    }
    fake::now=20000;
    auto close=request("close",0);close.fields["horizontal"].text="0";
    close.fields["strength"].text="123";
    close.fields["start"].text="-100";close.fields["body"].text="100";
    assert(post(close)==200&&snapshot().revision==1);
    assert(runtimeProfile(false).horizontal==100); // engine snapshot is immutable
    auto stale=request("long",0);assert(post(stale)==409);
    auto far=request("long",1);far.fields["vertical"].text="20";assert(post(far)==200);
    assert(snapshot().profiles[0].horizontal==0&&snapshot().profiles[1].vertical==20);
    assert(snapshot().strength==123);
    service(100,true);assert(snapshot().savedRevision==0); // debounce
    fake::prefsWriteOk=false;service(1000,true);assert(storageFault()&&snapshot().savedRevision==0);
    fake::prefsWriteOk=true;service(1500,true);assert(snapshot().savedRevision==0); // retry rate
    service(3100,true);assert(!storageFault()&&snapshot().savedRevision==2);
    fake::now=3200000;
    auto third=request("close",2);third.fields["start"].text="25";assert(post(third)==200);
    fake::onWrite=[](){auto concurrent=request("long",3);concurrent.fields["horizontal"].text="30";assert(post(concurrent)==200);};
    service(6000,true);
    assert(snapshot().savedRevision==3&&snapshot().revision==4); // concurrent write stays dirty
    fake::onWrite=[](){};
    buttonPressed(6100);assert(phase()==Phase::SAVING_EXIT);
    auto late=request("close",4);assert(post(late)==503);
    fake::prefsWriteOk=false;service(6100,false);
    assert(phase()==Phase::SAVING_EXIT&&fake::restarts==0&&fake::wifiInitialized);
    fake::prefsWriteOk=true;service(8200,false);assert(snapshot().savedRevision==4);
    assert(phase()==Phase::SAVING_EXIT); // original profile/mode must also be saved
    service(8210,true);assert(phase()==Phase::STOPPING&&!fake::wifiInitialized&&fake::serverEnds==1);
    tuning::Profile saved[2];uint8_t blob[tuning::BLOB_SIZE];
    uint16_t savedStrength=0;
    assert(storage.getBytes("config",blob,sizeof(blob))==sizeof(blob)&&tuning::decode(blob,sizeof(blob),saved,&savedStrength));
    assert(savedStrength==123);
    assert(saved[0].start==25&&saved[1].horizontal==30&&saved[1].vertical==100);
    service(8300,true);assert(fake::restarts==0);
    try{service(8410,true);assert(false);}catch(const fake::Restart&){}
    assert(fake::restarts==1&&pauseRequested.load());
    assert(resumeCookie==RESUME_MAGIC); // OFF remains OFF after the controlled reset
    std::puts("PASS: actual engineering handlers, authentication, validation, revision conflicts, debounce/retry, concurrent save and shutdown");
}
