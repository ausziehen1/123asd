// Run the embedded JS in a small DOM/HTTP harness. No browser rendering is simulated.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source=fs.readFileSync(new URL('../firmware/RecoilEngine/EngineeringPage.h',import.meta.url),'utf8');
const script=source.match(/<script>([\s\S]*?)<\/script>/)[1];
const defaults=()=>({horizontal:100,vertical:100,start:0,body:0,tail:0});
let state={phase:'tuning',revision:0,savedRevision:0,strength:150,storageError:false,token:'session-token',profiles:[defaults(),defaults()]};
let hold=[],inFlight=0,maxInFlight=0,staleGet=false,getCount=0;
function harness(){
 const elements={};
 for(const id of ['status','close','long','strength','strengthValue',...['horizontal','vertical','start','body','tail'].flatMap(k=>[k,k+'Value'])])
  elements[id]={value:'',disabled:true,textContent:'',listeners:{},classList:{toggle(){}},setAttribute(){},addEventListener(type,cb){this.listeners[type]=cb;}};
 const timers=new Map(),intervals=[];let next=0;
 const context=vm.createContext({
  document:{getElementById:id=>elements[id],querySelectorAll:()=>['close','long','strength','horizontal','vertical','start','body','tail'].map(k=>elements[k])},
  window:{addEventListener(){}},AbortController,URLSearchParams,
  setTimeout:(fn,ms)=>{timers.set(++next,{fn,ms});return next;},clearTimeout:id=>timers.delete(id),
  setInterval:fn=>intervals.push(fn),
  fetch:async(url,options)=>{
   if(url==='/api/config'){++getCount;const s=structuredClone(state);if(staleGet)s.revision=0;return {ok:true,json:async()=>s};}
   assert.equal(url,'/update');assert.equal(options.method,'POST');
   assert.equal(options.headers['X-Tune-Token'],state.token);
   ++inFlight;maxInFlight=Math.max(maxInFlight,inFlight);
   return await new Promise(resolve=>hold.push(()=>{
    const p=options.body;
    assert.equal(Number(p.get('revision')),state.revision);
    const mode=p.get('mode')==='close'?0:1;
    for(const k of ['horizontal','vertical','start','body','tail'])state.profiles[mode][k]=Number(p.get(k));
    state.strength=Number(p.get('strength'));++state.revision;--inFlight;
    resolve({ok:true,json:async()=>structuredClone(state)});
   }));
  }
 });
 vm.runInContext(script,context);
 return {elements,intervals,context,input:(id,value)=>{elements[id].value=String(value);elements[id].listeners.input();},click:id=>elements[id].listeners.click(),flush:()=>{for(const [id,t] of timers)if(t.ms===60){timers.delete(id);t.fn();}}};
}
async function settle(){for(let i=0;i<30;++i)await Promise.resolve();}
let h=harness();await settle();
assert.equal(h.elements.strength.value,150);assert.equal(h.elements.horizontal.disabled,false);
h.input('horizontal',0);h.flush();await settle();assert.equal(hold.length,1);
h.input('strength',73);h.click('long');h.input('vertical',23);h.flush();await settle();
assert.equal(hold.length,1); // no simultaneous POSTs from one tab
for(let i=0;i<3;++i){assert.equal(hold.length,1);hold.shift()();await settle();}
assert.equal(inFlight,0);assert.equal(maxInFlight,1);assert.equal(state.revision,3);
assert.equal(state.profiles[0].horizontal,0);assert.equal(state.profiles[1].vertical,23);assert.equal(state.strength,73);
state.savedRevision=3;await h.intervals[0]();
assert.match(h.elements.status.textContent,/Сохранено во флеш/);
staleGet=true;await h.intervals[0]();assert.equal(h.elements.horizontal.disabled,false);staleGet=false;
++state.revision;await h.intervals[0]();assert.equal(h.elements.horizontal.disabled,true);
assert.match(h.elements.status.textContent,/другой вкладке/);
state.phase='saving';state.storageError=true;
h=harness();await settle();assert.match(h.elements.status.textContent,/Ошибка NVS/);
const count=getCount;await h.intervals[0]();assert.equal(getCount,count+1); // keep polling during failed exit
console.log('PASS: embedded JS syntax, slider queue, mode isolation, global strength, stale replies, conflicts and exit error status');
