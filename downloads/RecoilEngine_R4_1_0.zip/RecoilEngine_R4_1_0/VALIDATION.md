# Проверка RecoilEngine R4.1.0

Дата: 2026-11-03. Проверены именно исходники этой ревизии.

## Целевая сборка — PASS

- PlatformIO Core 6.2.0, espressif32 6.12.0, Arduino-ESP32 2.0.17.
- Xtensa ESP32-S3 GCC 8.4.0 / esp-2021r2-patch5.
- ESP32Async AsyncTCP 3.3.2 и ESPAsyncWebServer 3.6.0; cJSON SDK 1.7.17.
- ESP32-S3-DevKitC-1, 4 MB QIO 80 MHz, Huge APP, 240 MHz, без BOARD_HAS_PSRAM.
- TinyUSB (USB Mode 0), CDC On Boot 0, Arduino/Events/AsyncTCP Core 0.
- Статическая RAM: 75592 / 327680 байт.
- Flash приложения: 850445 / 3145728 байт.
- Компиляция и линковка успешны, заключительная сборка без предупреждений.
- Это не измерение динамической heap или запаса стеков работающей платы.

Использованы локально имеющиеся официальные SDK/toolchain и официальные GitHub-теги
сетевых библиотек через platform_packages/lib_extra_dirs. Поставляемый platformio.ini
содержит обычные пакеты и закреплённые версии. Исходники SDK/AsyncTCP/сервера не
патчились. В host-тестах используется исходная cJSON 1.7.17 с лицензией в tests/vendor.

## Программные проверки — PASS

Воспроизводимая команда: `bash tests/run.sh`. G++/CC, AddressSanitizer +
UndefinedBehaviorSanitizer, Node.js. LeakSanitizer отключён из-за ограничений runner.

- Исходные 6 групп проверок защит и прежнего 32-байтного формата.
- Схема 3: CRC, типы/диапазоны, неподвижность результата при ошибке, rollover поколения.
- Сглаживание участков: ограниченный/монотонный переход, строгий ноль внутри
  выключенного участка; охлаждение: монотонность и ноль у конца окна.
- RC-микрошум: ограничение диапазона/режим 0; лимит catch-up и зависимость шума от силы.
- Две копии NVS: создание резерва, сбой первой записи/seed, повтор, восстановление
  после порчи новой копии, readback rejection, миграция, поколение через UINT32_MAX.
- Реальный cJSON: импорт/экспорт, типы, диапазоны, дубли, глубина/размер/NUL,
  схема 2 -> режим совместимости. JSON не разбирается заглушкой.
- 22 сценария настоящего скетча: прежние USB/кнопки/паузы, учёт последнего удержания,
  ограничение catch-up с отбрасыванием, восстановление дробной фазы, tap при приближении
  к холодному старту, выключенное тело, расчёт preview и новые defaults.
- 5 точных HID-трасс опубликованной R4.0.0 совпали: количество, время и X/Y
  в детерминированной модели. Базовый ZIP SHA256:
  `06541db946b6627e1b4f99eccaf6e303f4771429101ac6118d7a713122e00394`.
  Эталоны в tests/test_legacy_compat.cpp. Проверка не доказывает совпадение реального
  процессорного времени или USB-таймингов двух версий на железе.
- Реальные HTTP-обработчики с fake Wi-Fi/NVS: Host/Origin/token, CAS, полная атомарная
  редакция, debounce/retry, новая редакция во время записи, CSV/preview, import/reset,
  отложенный выход до сохранения, AP/слушатель/таймаут паузы, RTC OFF и причина сбоя,
  автоматический выход только после отсутствия клиентов.
- Встроенный JS исполнялся в DOM/HTTP harness: сериализация полных снимков,
  независимые наборы, включение новой модели без сброса калибровки, старый ответ графика,
  JSON/именованные наборы/reset, невалидный импорт без заморозки страницы,
  гистограмма/диагностика и конфликт вкладок.
- Ранняя видимость типов/прототипов Arduino проверена отдельно, включая buildPreview.
  Windows GUI IDE и полный Arduino Builder 1.6.1 для этой ревизии не запускались.

PATTERN_CLOSE, PATTERN_LONG, исходная MULTIPLIERS для миграции и report_descriptor
сверены побайтово с R4.0.0 и не изменились. Контролов GPIO7/8 нет. RF24 не добавлен.

## Что не проверялось

Физическая плата, реальные два CPU/RTOS, RF и USB-хост, heap/запас стеков,
настоящее выключение питания во время NVS, длительные циклы AP/restart, реальный
браузер/ОС. Заглушки не моделируют физическую атомарность flash и не являются
тестом фактических 1000 отчётов/с. График — геометрия основы, не эмуляция всего HID.

Бесшовный выход без reset исследован по исходникам библиотек и не включён:
основание в DESIGN_DECISIONS.md. Рабочий вариант сохраняет restart/переподключение USB.

## Вывод набора тестов

```text
PASS: 6 engine safety regression groups
PASS: tuning defaults, bounds, region gains, profile separation, NVS CRC/atomic decode, strict parser
PASS: schema3 CRC/bounds, generation rollover, smooth gains/strict zero, continuous cooldown, bounded correlated noise, catch-up cap and motion accounting
PASS: two-slot NVS, first-save fallback, power/retry failures, corrupt-newest recovery, readback rejection, R4 migration and generation wrap
PASS: real cJSON import/export, strict complete schema, duplicate/type/range rejection, nesting/size/NUL limits and schema2 conversion
PASS: 5 exact deterministic HID-trace fixtures match published R4.0.0 in legacy mode
PASS: 22 actual-sketch integration scenarios (stub hardware), including diagnostics, catch-up cap, fractional warm phase/blended tap, strict disabled body, preview and modern defaults
PASS: actual HTTP security/CAS, RAM vs NVS, debounce/retry/concurrent save, graph/CSV, and final flush before radio/reset
PASS: schema3 boot restore and newest-corrupt fallback
PASS: schema3 boot restore and newest-corrupt fallback
PASS: R4.0 NVS migration keeps legacy model
PASS: pause timeout keeps HID paused
PASS: AP/listener startup failure shuts radio, retains pause
PASS: AP/listener startup failure shuts radio, retains pause
PASS: RTC resume OFF and cold-boot policy
PASS: RTC resume OFF and cold-boot policy
PASS: startup fault retained through recovery reset
PASS: idle timeout counts only time without clients, flushes then exits
PASS: legacy JSON import, complete export and protected atomic reset
PASS: Arduino IDE early-prototype compilation regression
PASS: embedded JS full-config queue, independent modes, noise options, preview/stale response, JSON export/import rejection, local presets/reset, CAS conflict and exit-error polling
```
