#pragma once
#include "EngineeringConfig.h"
#include "MotionReport.h"
#include "TuningConfig.h"
#include <atomic>
#include <stdint.h>

namespace engineering {
enum class Phase : uint8_t { PLAY, WAIT_PAUSE, TUNING, SAVING_EXIT, STOPPING, FAULT };
extern std::atomic<bool> pauseRequested;
extern std::atomic<bool> pauseGranted;
// Called before creating either task; no AP/server/TCP initialization here.
bool begin();
// Setup migration, called only before task creation.
int adoptLegacyStrength(int fallbackStep);
bool bootEnabled();
// Single writer for these operations: ControlTask, Core 0.
void buttonPressed(uint32_t nowMs, bool enabled = true);
void service(uint32_t nowMs, bool baseSettingsSaved, int workingMode = 0);
Phase phase();
bool active();
bool storageFault();
// Immutable after begin(); HTTP only edits a separate draft, applied by reboot.
const tuning::Profile &runtimeProfile(bool longMode);
const tuning::Config &runtimeConfig();
void publishMotion(const motion::Report &report);
struct PreviewPoint {
    float beforeX, beforeY, afterX, afterY;
};
struct Preview {
    static constexpr unsigned COUNT = 241;
    PreviewPoint points[COUNT];
};
// Implemented by the sketch, reusing its actual banks/spline, called only while paused.
void buildPreview(bool longMode, int pattern, const tuning::Config &config, Preview &out);
} // namespace engineering
