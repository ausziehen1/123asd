#pragma once
#include <Arduino.h>
static const char ENGINEERING_HTML[] PROGMEM = R"rawliteral(<!doctype html>
<html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RecoilEngine R4.1 · Настройка</title>
<style>
:root{color-scheme:dark;font:16px system-ui,sans-serif;background:#10151e;color:#e5edf8}*{box-sizing:border-box}body{max-width:1080px;margin:auto;padding:30px 20px 60px}h1{font-size:30px;margin:6px 0 12px}h2{font-size:19px;margin:0 0 16px}p,small{line-height:1.6;color:#aab8cb}small{display:block}.tag{font-size:12px;letter-spacing:.15em;color:#8fc7ff}.card{background:#182231;border:1px solid #2d3c52;border-radius:16px;padding:22px;margin:18px 0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.grid>.card{margin:0}.row{padding:14px 0;border-bottom:1px solid #2d3c52}.row:last-child{border:0}.line{display:flex;justify-content:space-between;gap:16px}output{color:#a7d4ff;font-variant-numeric:tabular-nums;white-space:nowrap}input[type=range]{width:100%;margin:16px 0 4px;accent-color:#a7d4ff}input[type=checkbox]{accent-color:#a7d4ff;margin-right:10px}input[type=text],input[type=number],select{font:inherit;background:#101b2a;border:1px solid #40546f;border-radius:8px;padding:9px;color:#e5edf8;max-width:100%}input[type=number]{width:100px}nav,.actions{display:flex;gap:10px;flex-wrap:wrap}button,.link{background:#26374e;border:1px solid #40546f;color:#e5edf8;padding:10px 15px;border-radius:9px;font:inherit;cursor:pointer;text-decoration:none}button[aria-selected=true]{background:#a7d4ff;color:#102033}button:disabled,input:disabled,select:disabled{opacity:.5;cursor:default}.status{min-height:48px;padding:14px 18px;border-left:3px solid #a7d4ff;background:#182231;line-height:1.5}.error{border-color:#ffb294;color:#ffb294}.meta{margin-top:8px;color:#aab8cb;font-size:14px}svg{display:block;width:100%;height:auto;background:#101b2a;border-radius:10px;margin:14px 0}polyline{fill:none;stroke-width:2;vector-effect:non-scaling-stroke}.before{stroke:#8593a7}.after{stroke:#92d5ff}pre{white-space:pre-wrap;font:14px/1.65 ui-monospace,monospace;color:#d5e5fa;margin-bottom:0}.legend{display:flex;gap:20px;font-size:14px}.legend span:first-child{color:#8593a7}.legend span:last-child{color:#92d5ff}#file{max-width:100%}@media(max-width:760px){.grid{grid-template-columns:1fr}.line{gap:8px}body{padding:24px 14px}output{font-size:14px}}
</style>
<body><div class="tag">ESP32-S3 / RECOILENGINE R4.1.0</div><h1>Настройка траектории</h1>
<p>HID-движения приостановлены. После сохранения выйдите физической кнопкой настройки: устройство перезапустится и применит значения. GPIO7/GPIO8 свободны; силу меняет только веб-интерфейс.</p>
<div class="status" id="status" role="status" aria-live="polite">Подключение к контроллеру…</div><div class="meta" id="meta"></div>
<section class="card"><div class="line"><label for="strength">Общая сила для обоих режимов</label><output id="strengthValue">3,00× · 150/150</output></div><input id="strength" type="range" min="0" max="150" step="1" value="150" disabled><small>Шаг 0,02. Максимум 3,00. Для перенесённой R4 сначала сохранено прежнее поведение шумов.</small></section>
<section class="card"><nav aria-label="Редактируемый набор"><button id="close" type="button" aria-selected="true" disabled>Ближний</button><button id="long" type="button" aria-selected="false" disabled>Дальний</button></nav><p id="editing">Редактируется Ближний. Рабочий режим выбирает FN.</p><div id="sliders">
<div class="row"><div class="line"><label for="horizontal">Горизонталь, включая шум</label><output id="horizontalValue"></output></div><input id="horizontal" type="range" min="0" max="100" step="1" disabled></div>
<div class="row"><div class="line"><label for="vertical">Вертикальная форма паттерна</label><output id="verticalValue"></output></div><input id="vertical" type="range" min="0" max="100" step="1" disabled><small>0% выравнивает форму к опоре; это не выключение вертикального движения.</small></div>
<div class="row"><div class="line"><label for="start">Начало · сегменты 1–6</label><output id="startValue"></output></div><input id="start" type="range" min="-100" max="100" step="1" disabled></div>
<div class="row"><div class="line"><label for="body">Тело · сегменты 7–18</label><output id="bodyValue"></output></div><input id="body" type="range" min="-100" max="100" step="1" disabled></div>
<div class="row"><div class="line"><label for="tail">Хвост · сегменты 19–30 и повторения</label><output id="tailValue"></output></div><input id="tail" type="range" min="-100" max="100" step="1" disabled><small>−100% = нулевое движение участка, 0% = исходная величина, +100% = удвоенная. Время сохраняется.</small></div>
<div class="row"><div class="line"><label for="noise">Уровень вариативности</label><output id="noiseValue"></output></div><input id="noise" type="range" min="0" max="200" step="1" disabled><small>Масштаб дрейфа и микрошумa. 0% — только основа. 100% — амплитуда исходных констант до зависимости от силы.</small></div>
<div class="row"><div class="line"><label for="microMs">Связность микрошумa</label><output id="microMsValue"></output></div><input id="microMs" type="range" min="0" max="100" step="1" disabled><small>0 мс — независимые отсчёты R4. Выше — более медленные, связанные отклонения; их дисперсия уменьшается.</small></div>
</div></section>
<section class="card"><h2>Переходы и восстановление</h2><button id="enableRefinements" type="button" disabled>Применить новую модель R4.1</button><small>Сохраняет силу и пять коэффициентов каждого режима. Включает переходы 40 мс, связь шума с силой, микрошум 12 мс, лимит catch-up 50% и плавное охлаждение.</small>
<div class="row"><div class="line"><label for="transitionMs">Ширина перехода между участками</label><output id="transitionMsValue"></output></div><input id="transitionMs" type="range" min="0" max="100" step="1" disabled><small>Номинальное время при сегменте 100 мс. 0 — прежние границы. Внутри выключенного участка сохраняется строгий ноль.</small></div>
<div class="row"><label><input id="noiseFollowStrength" type="checkbox" disabled>Амплитуда шума следует за силой</label><small>При включении шум умножается на силу / 3. При силе 3,00 масштаб равен 1.</small></div>
<div class="row"><label><input id="limitCatchup" type="checkbox" disabled>Ограничивать скорость catch-up</label><div class="line"><label for="catchupMaxPct">Максимальная добавка к текущей основной скорости</label><output id="catchupMaxPctValue"></output></div><input id="catchupMaxPct" type="range" min="0" max="300" step="1" disabled><small>Неотданный к концу первого сегмента долг отбрасывается и учитывается в диагностике. Выключенная галочка сохраняет старый catch-up.</small></div>
<div class="row"><label><input id="continuousWarm" type="checkbox" disabled>Плавное охлаждение дробной фазы</label><small>Включено — сохраняется доля сегмента и используется непрерывный откат к началу. Выключено — ступенчатая модель R4.</small></div>
<div class="row"><label for="idleTimeoutSec">Выход при отсутствии Wi-Fi-клиентов, секунд </label><input id="idleTimeoutSec" type="number" min="0" max="3600" step="1" disabled><small>0 — выключен; иначе от 30 до 3600 секунд. При ошибке записи выход задерживается.</small></div>
</section>
<div class="grid"><section class="card"><h2>Расчётная геометрия основы</h2><label for="pattern">Паттерн банка, 0–39 </label><input id="pattern" type="number" min="0" max="39" step="1" value="0" disabled><div class="legend"><span>Исходный пресет</span><span>С коэффициентами</span></div>
<svg viewBox="0 0 700 420" role="img" aria-label="Геометрия X Y"><polyline id="pathBefore" class="before"></polyline><polyline id="pathAfter" class="after"></polyline></svg><small>Оси X/Y, одинаковый масштаб. Один проход из 30 сегментов.</small>
<svg viewBox="0 0 700 300" role="img" aria-label="Вертикальное смещение по фазе"><polyline id="phaseBefore" class="before"></polyline><polyline id="phaseAfter" class="after"></polyline></svg><pre id="previewTotals"></pre><small>График использует реальные банки и формулы калибровки. Без tap/catch-up, шума, зеркалирования, EMA, округления и USB. Это не измерение движения на хосте.</small></section>
<section class="card"><h2>Последнее удержание</h2><pre id="diagnostics">Пока нет измерения.</pre><svg viewBox="0 0 700 220" role="img" aria-label="Гистограмма интервала расчётов"><g id="histogram"></g></svg><small>Интервалы: &lt;900; 900–949; 950–999; 1000–1049; 1050–1099; 1100–1249; 1250–1999; 2000–4999; ≥5000 мкс.</small><p><a class="link" href="/diagnostics.csv" download>Скачать CSV</a></p><small>Учтены отчёты, принятые TinyUSB во время удержания, до Spring-Back. Это не подтверждение обработки ОС. Данные RAM теряются при перезапуске.</small></section></div>
<section class="card"><h2>Копии и наборы настроек</h2><div class="actions"><button id="export" disabled>Экспорт JSON</button><button id="reset" disabled>Исходные значения R4.1</button></div><p><label for="file">Импорт файла JSON </label><input id="file" type="file" accept=".json,application/json" disabled></p><small>Импорт проверяется целиком. Старый документ schema 2 переносится с прежними шумом, переходами, catch-up и охлаждением.</small>
<div class="row"><label for="presetName">Имя набора в этом браузере </label><input id="presetName" type="text" maxlength="40" placeholder="Например, спокойный" disabled><div class="actions" style="margin-top:12px"><button id="saveLocal" disabled>Сохранить в браузере</button><select id="presets" disabled aria-label="Сохранённые наборы"></select><button id="loadLocal" disabled>Загрузить</button><button id="deleteLocal" disabled>Удалить</button></div><small>Наборы загружаются только по вашей команде. Хранилище браузера не заменяет экспорт файла и NVS устройства.</small></div></section>
<small>Перед выходом дождитесь сохранения последней редакции. Повторное нажатие GPIO9 выполняет сохранение, выключение сети и restart с переподключением USB. При удерживаемом микрике после запуска требуется отпускание.</small>
<script>

'use strict';
const $ = id => document.getElementById(id), clone = v => JSON.parse(JSON.stringify(v));
const profileKeys = ['horizontal', 'vertical', 'start', 'body', 'tail', 'noise', 'microMs'];
const numberKeys = ['strength', 'transitionMs', 'catchupMaxPct', 'idleTimeoutSec'];
const boolKeys = ['noiseFollowStrength', 'limitCatchup', 'continuousWarm'];
const actionIds = [
  'enableRefinements', 'export', 'reset', 'file', 'saveLocal', 'loadLocal', 'deleteLocal', 'presets',
  'presetName'
];
let config = null, mode = 0, revision = 0, savedRevision = 0, token = '', ready = false, failed = false,
    busy = false, pending = false, exclusive = false, closing = false, timer, previewTimer,
    previewBusy = false, presets = [];
let lastState = null;
function message(text, error = false) {
  $('status').textContent = text;
  $('status').classList.toggle('error', error);
}
function setEnabled() {
  for (const e of document.querySelectorAll('input,button,select'))
    e.disabled = !ready || failed || exclusive;
  for (const id of actionIds) $(id).disabled = !ready || failed || busy || pending || exclusive;
}
function draw() {
  profileKeys.forEach(k => {
    $(k).value = config.profiles[mode][k];
    $(k + 'Value').textContent =
        (['start', 'body', 'tail'].includes(k) && config.profiles[mode][k] > 0 ? '+' : '') +
        config.profiles[mode][k] + (k === 'microMs' ? ' мс' : '%');
  });
  numberKeys.forEach(k => $(k).value = config[k]);
  boolKeys.forEach(k => $(k).checked = config[k]);
  $('strengthValue').textContent =
      (config.strength * .02).toFixed(2).replace('.', ',') + '× · ' + config.strength + '/150';
  $('transitionMsValue').textContent = config.transitionMs + ' мс';
  $('catchupMaxPctValue').textContent = config.catchupMaxPct + '%';
  ['close', 'long'].forEach((id, i) => $(id).setAttribute('aria-selected', String(i === mode)));
  $('editing').textContent =
      'Редактируется ' + (mode === 0 ? 'Ближний' : 'Дальний') + '. Рабочий режим выбирает FN.';
  setEnabled();
}
async function api(url, options = {}) {
  const control = new AbortController(), timeout = setTimeout(() => control.abort(), 8000);
  try {
    const r = await fetch(url, {cache: 'no-store', ...options, signal: control.signal});
    const data = await r.json();
    if (!r.ok) {
      const error = new Error(
          r.status === 409 ? 'Конфликт редакции: перечитайте страницу.' : data.error || 'HTTP ' + r.status);
      error.status = r.status;
      throw error;
    }
    return data;
  } finally {
    clearTimeout(timeout);
  }
}
function fail(e) {
  failed = true;
  ready = false;
  setEnabled();
  message(e.message + ' Проверьте соединение с AP и перечитайте страницу.', true);
}
function diagnostics(m) {
  if (!m || !m.sequence) {
    $('diagnostics').textContent =
        'Пока нет измерения. Выполните удержание в обычном режиме, затем войдите в настройку.';
    return;
  }
  const reasons = ['отпускание', 'вход в настройку', 'потеря USB', 'OFF'];
  $('diagnostics').textContent = [
    'Удержание № ' + m.sequence + ' · ' + (m.mode === 0 ? 'Ближний' : 'Дальний') + ' · паттерн ' + m.pattern +
        ' · сила ' + (m.strength * .02).toFixed(2),
    'Фаза начала / конца: ' + m.startPhase.toFixed(4) + ' / ' + m.endPhase.toFixed(4),
    'Длительность: ' + (m.durationUs / 1000).toFixed(1) + ' мс',
    'Расчётов: ' + m.ticks + ' · dt min / mean / max: ' + m.minDtUs + ' / ' + m.meanDtUs.toFixed(2) + ' / ' +
        m.maxDtUs + ' мкс',
    'Опозданий ≥50 мкс: ' + m.lateTicks + ' · пропущено дедлайнов: ' + m.missedSlots,
    'USB busy / rejected / drops: ' + m.busy + ' / ' + m.rejected + ' / ' + m.drops,
    'Принято очередью: ' + m.queued + ' · X/Y: ' + m.queuedX + ' / ' + m.queuedY,
    'Максимальный интервал постановок: ' + m.maxQueueGapUs + ' мкс',
    'Отброшенный catch-up X/Y: ' + m.droppedCatchupX.toFixed(3) + ' / ' + m.droppedCatchupY.toFixed(3),
    'Завершено: ' + reasons[m.reason]
  ].join('\n');
  const g = $('histogram');
  while (g.firstChild) g.removeChild(g.firstChild);
  const max = Math.max(1, ...m.histogram);
  m.histogram.forEach((n, i) => {
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', 12 + i * 76);
    rect.setAttribute('y', 200 - n / max * 180);
    rect.setAttribute('width', 55);
    rect.setAttribute('height', n / max * 180);
    rect.setAttribute('fill', '#92d5ff');
    g.appendChild(rect);
  });
}
function showState(s) {
  if (s.revision < revision) return;
  savedRevision = s.savedRevision;
  lastState = s;
  $('meta').textContent = 'Рабочий режим FN: ' + (s.workingMode === 0 ? 'Ближний' : 'Дальний') + ' · RAM ' +
      s.revision + ' / NVS ' + s.savedRevision + ' · поколение ' + s.generation +
      (s.lastBootError && s.lastBootError !== 'none' ? ' · прошлый сбой: ' + s.lastBootError : '') +
      (s.migrated      ? ' · перенесена R4.0' :
           s.recovered ? ' · восстановлена резервная копия' :
                         '');
  diagnostics(s.lastHold);
  if (s.phase !== 'tuning') {
    closing = true;
    ready = false;
    setEnabled();
    message(
        s.storageError ? 'Выход задержан: ' + s.errorCode + '. Запись будет повторена.' :
                         'Сохранение и завершение режима настройки…',
        s.storageError);
    return;
  }
  if (closing) return;
  if (s.storageError)
    message('Ошибка хранения: ' + s.errorCode + '. Последние изменения ещё не сохранены.', true);
  else if (busy || pending)
    message('Отправка изменений…');
  else if (savedRevision !== revision)
    message('Принято в RAM · ожидается запись NVS…');
  else
    message(
        s.generation === 0 && revision === 0 ? 'Исходные или перенесённые значения · новых изменений нет' :
                                               'Сохранено во флеш · можно выйти физической кнопкой');
  setEnabled();
}
function changed() {
  if (!ready) return;
  pending = true;
  draw();
  message('Отправка изменений…');
  clearTimeout(timer);
  timer = setTimeout(pump, 60);
}
async function pump() {
  if (!ready || failed || busy || exclusive || !pending) return;
  pending = false;
  busy = true;
  const sent = clone(config);
  setEnabled();
  try {
    const s = await api('/update', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Tune-Token': token},
      body: new URLSearchParams(
          {revision: String(revision), document: JSON.stringify({schema: 3, config: sent})})
    });
    revision = s.revision;
    busy = false;
    showState(s);
    if (pending)
      pump();
    else
      schedulePreview();
  } catch (e) {
    busy = false;
    fail(e);
  }
}
profileKeys.forEach(k => $(k).addEventListener('input', () => {
  if (!ready) return;
  config.profiles[mode][k] = Number($(k).value);
  changed();
}));
numberKeys.forEach(k => $(k).addEventListener('input', () => {
  if (!ready) return;
  const n = Number($(k).value);
  if ($(k).value === '' || !Number.isInteger(n) || n < 0 ||
      (k === 'idleTimeoutSec' && n !== 0 && (n < 30 || n > 3600))) {
    message('Тайм-аут: 0 либо целое число от 30 до 3600.', true);
    return;
  }
  config[k] = n;
  changed();
}));
numberKeys.forEach(k => $(k).addEventListener('change', () => {
  if (Number($(k).value) !== config[k] || $(k).value === '') {
    $(k).value = config[k];
    message('Значение не принято: восстановлено последнее допустимое.', true);
  }
}));
boolKeys.forEach(k => $(k).addEventListener('change', () => {
  if (!ready) return;
  config[k] = $(k).checked;
  changed();
}));
['close', 'long'].forEach((id, i) => $(id).addEventListener('click', () => {
  mode = i;
  draw();
  schedulePreview();
}));
$('pattern').addEventListener('change', schedulePreview);
function schedulePreview() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(loadPreview, 180);
}
function plot(data) {
  const points = data.points;
  if (!Array.isArray(points) || !points.length) return;
  const xs = points.flatMap(p => [p[0], p[2]]), ys = points.flatMap(p => [p[1], p[3]]);
  const xmin = Math.min(...xs), xmax = Math.max(...xs), ymin = Math.min(...ys), ymax = Math.max(...ys),
        scale = Math.min(640 / Math.max(xmax - xmin, 1), 360 / Math.max(ymax - ymin, 1));
  const offsetX = 350 - (xmin + xmax) / 2 * scale;
  function xy(x, y) {
    return (offsetX + x * scale).toFixed(2) + ',' + (30 + (y - ymin) * scale).toFixed(2);
  }
  function phase(i, y) {
    return (30 + i / (points.length - 1) * 640).toFixed(2) + ',' +
        (20 + (y - ymin) / Math.max(ymax - ymin, 1) * 260).toFixed(2);
  }
  ['Before', 'After'].forEach((name, index) => {
    $('path' + name).setAttribute('points', points.map(p => xy(p[index * 2], p[index * 2 + 1])).join(' '));
    $('phase' + name).setAttribute('points', points.map((p, i) => phase(i, p[index * 2 + 1])).join(' '));
  });
  const end = points[points.length - 1];
  $('previewTotals').textContent = 'Основа X/Y: ' + end[0].toFixed(3) + ' / ' + end[1].toFixed(3) +
      '\nС настройкой: ' + end[2].toFixed(3) + ' / ' + end[3].toFixed(3);
}
async function loadPreview() {
  if (!ready || failed || busy || pending || exclusive || previewBusy) return;
  const pattern = Number($('pattern').value);
  if (!Number.isInteger(pattern) || pattern < 0 || pattern > 39) {
    message('Номер паттерна должен быть от 0 до 39.', true);
    return;
  }
  previewBusy = true;
  const selected = mode;
  try {
    const s = await api('/preview?mode=' + (mode === 0 ? 'close' : 'long') + '&pattern=' + pattern);
    if (s.revision === revision && !busy && !pending && selected === mode &&
        pattern === Number($('pattern').value))
      plot(s);
    else
      schedulePreview();
  } catch (e) {
    if (!closing) message('График недоступен: ' + e.message, true);
  } finally {
    previewBusy = false;
  }
}
async function replaceDocument(document, reset = false) {
  if (!ready || busy || pending || exclusive) return;
  exclusive = true;
  setEnabled();
  try {
    const s = await api(reset ? '/reset' : '/import', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded', 'X-Tune-Token': token},
      body: new URLSearchParams(
          reset ? {revision: String(revision)} :
                  {revision: String(revision), document: JSON.stringify(document)})
    });
    config = s.config;
    revision = s.revision;
    exclusive = false;
    draw();
    showState(s);
    schedulePreview();
  } catch (e) {
    exclusive = false;
    if (e.status === 400) {
      draw();
      message(e.message, true);
    } else
      fail(e);
  }
}
$('file').addEventListener('change', async () => {
  const f = $('file').files[0];
  if (!f) return;
  try {
    if (f.size > 8192) throw new Error('Файл больше 8 КБ.');
    const document = JSON.parse(await f.text());
    if (window.confirm('Заменить оба набора и общую силу содержимым файла?')) await replaceDocument(document);
  } catch (e) {
    message('Импорт: ' + e.message, true);
  } finally {
    $('file').value = '';
  }
});
$('enableRefinements').addEventListener('click', () => {
  if (!ready || busy || pending) return;
  config.transitionMs = 40;
  config.noiseFollowStrength = true;
  config.limitCatchup = true;
  config.catchupMaxPct = 50;
  config.continuousWarm = true;
  config.profiles.forEach(p => p.microMs = 12);
  changed();
});
$('reset').addEventListener('click', () => {
  if (window.confirm('Загрузить исходные значения R4.1, включая силу 3,00?')) replaceDocument(null, true);
});
$('export').addEventListener('click', async () => {
  if (busy || pending || !ready) return;
  try {
    const data = await api('/export');
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'}));
    const a = document.createElement('a');
    a.href = url;
    a.download =
        ($('presetName').value.trim().replace(/[^\p{L}\p{N}_-]/gu, '_') || 'RecoilEngine-R4.1') + '.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (e) {
    message('Экспорт: ' + e.message, true);
  }
});
const STORAGE_KEY = 'RecoilEngine-presets-schema3';
function renderPresets() {
  const list = $('presets');
  while (list.firstChild) list.removeChild(list.firstChild);
  presets.forEach((p, i) => {
    const o = document.createElement('option');
    o.value = String(i);
    o.textContent = p.name;
    list.appendChild(o);
  });
}
function storePresets() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(presets));
    renderPresets();
  } catch (e) {
    message('Браузер не сохранил набор: ' + e.message, true);
  }
}
try {
  const p = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  if (Array.isArray(p)) presets = p.filter(v => v && typeof v.name === 'string' && v.document).slice(0, 20);
} catch (e) {
}
renderPresets();
$('saveLocal').addEventListener('click', () => {
  if (!ready || busy || pending) return;
  const name = $('presetName').value.trim();
  if (!name) {
    message('Введите имя набора.', true);
    return;
  }
  const item = {name, document: {schema: 3, config: clone(config)}},
        i = presets.findIndex(p => p.name === name);
  if (i >= 0) {
    if (!window.confirm('Заменить набор «' + name + '»?')) return;
    presets[i] = item;
  } else {
    if (presets.length >= 20) {
      message('В браузере максимум 20 наборов. Экспортируйте или удалите ненужный.', true);
      return;
    }
    presets.push(item);
  }
  storePresets();
});
$('loadLocal').addEventListener('click', () => {
  const p = presets[Number($('presets').value)];
  if (p && window.confirm('Загрузить «' + p.name + '» в контроллер?')) replaceDocument(p.document);
});
$('deleteLocal').addEventListener('click', () => {
  const i = Number($('presets').value);
  if (presets[i] && window.confirm('Удалить этот набор из браузера?')) {
    presets.splice(i, 1);
    storePresets();
  }
});
async function poll() {
  if (failed) return;
  try {
    const s = await api('/api/config');
    if (s.revision < revision) return;
    if (s.revision !== revision && !busy && !pending && !exclusive)
      throw new Error('Настройки изменены другой вкладкой. Перечитайте страницу.');
    showState(s);
  } catch (e) {
    if (closing) {
      failed = true;
      message(
          'Связь с AP завершена. После перезапуска проверьте устройство; для новой настройки снова нажмите GPIO9.');
    } else
      fail(e);
  }
}
api('/api/config')
    .then(s => {
      config = s.config;
      revision = s.revision;
      token = s.token;
      ready = s.phase === 'tuning';
      draw();
      showState(s);
      schedulePreview();
      setInterval(poll, 1000);
    })
    .catch(fail);
window.addEventListener('beforeunload', e => {
  if (busy || pending || exclusive || savedRevision !== revision) {
    e.preventDefault();
    e.returnValue = '';
  }
});
</script></body></html>)rawliteral";
