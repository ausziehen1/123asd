// Execute the actual sketch's task against deterministic hardware/RTOS stubs.
// This validates state transitions; it does not emulate USB hardware or scheduling.
#include "../firmware/RecoilEngine/RecoilEngine.ino"
#include "stubs/EngineeringStubs.h"
#include <cassert>
void reset(uint64_t end=300000) {
 fake::now=0;fake::end=end;fake::wake=0;fake::rng=7;
 fake::reports.clear();fake::rejectReports=false;fake::isMounted=true;fake::isReady=true;fake::isSuspended=false;
 fake::trigger=[](uint64_t){return false;};fake::step=[](uint64_t){};fake::onDelay=[](){};
 g_tasksReady.store(true);g_engineFault.store(false);
 g_flashSaveRequested.store(false);g_flashSaveGranted.store(false);
 engineering::pauseRequested.store(false);engineering::pauseGranted.store(false);
 fake::calibration[0]=tuning::Profile{};fake::calibration[1]=tuning::Profile{};
 fake::calibration[0].microMs=fake::calibration[1].microMs=0;
 fake::options=tuning::legacyConfig(fake::calibration,150);fake::lastHold=motion::Report{};fake::holdReports.clear();
 g_atomicState.packed.store(packControl(150,MODE_CLOSE,true));
 engineWakeTimer=(void*)1;r32InitDynamics();
}
void run() {try{EngineTask(nullptr);}catch(const fake::Stop&){} }
void normalPress() {
 reset();fake::trigger=[](uint64_t t){return t>=10000 && t<200000;};run();
 assert(!fake::reports.empty());
 for(auto r:fake::reports)assert(r.at>=13000 && r.at<205000);
}
void bootHeld() {
 reset();fake::trigger=[](uint64_t t){return t<90000 || (t>=150000 && t<250000);};run();
 assert(!fake::reports.empty());for(auto r:fake::reports)assert(r.at>=153000);
}
void reconnectHeld(bool suspend) {
 reset(400000);
 fake::trigger=[](uint64_t t){return t>=10000 && (t<250000 || t>=300000);};
 fake::step=[suspend](uint64_t t){
   fake::isMounted=suspend || !(t>=90000 && t<150000);
   fake::isSuspended=suspend && t>=90000 && t<150000;
 };
 run();bool before=false, after=false;
 for(auto r:fake::reports){if(r.at<90000)before=true;if(r.at>303000)after=true;assert(r.at<90000 || r.at>=303000);}
 assert(before && after);
}
void longBusyRecovery() {
 reset();fake::trigger=[](uint64_t t){return t>=10000 && t<250000;};
 fake::step=[](uint64_t t){fake::isReady=!(t>=70000 && t<170000);};
 run(); bool after=false;
 for(auto r:fake::reports) {
   assert(r.at<70000 || r.at>=170000);
   if(r.at>=170000){after=true;assert(std::abs(r.x)<=2 && std::abs(r.y)<=2);}
 }
 assert(after);
}
void rejectedQueueRecovery() {
 reset();fake::trigger=[](uint64_t t){return t>=10000 && t<250000;};
 fake::step=[](uint64_t t){fake::rejectReports=t>=70000 && t<170000;};
 run();bool recovered=false;
 for(auto r:fake::reports) {
   assert(r.at<70000 || r.at>=170000);
   if(!recovered && r.at>=170000) {
     assert(r.x==0 && r.y==0); // a stale transport first accepts a zero-motion probe
     recovered=true;
   }
 }
 assert(recovered);
}
void zeroProfileStopsTail() {
 reset();fake::trigger=[](uint64_t t){return t>=10000 && t<250000;};
 fake::step=[](uint64_t t){if(t>=100000)setControlStrength(0);};
 run();bool before=false;
 for(auto r:fake::reports){assert(r.at<117000);before=true;}
 assert(before); // profile refresh is intentionally still every 16 ticks
}
void delayedSpring() {
 reset(120000);fake::trigger=[](uint64_t t){return t>=10000 && t<54000;};
 // Let the tap produce movement but block all reports from release to 100ms.
 fake::step=[](uint64_t t){fake::isReady=t<55000 || t>=100000;};
 run();assert(!fake::reports.empty());
 for(auto r:fake::reports)assert(r.at<55000); // expired return never escapes
}
void flashHandshake() {
 reset(100000);fake::trigger=[](uint64_t){return false;};
 bool grantObserved=false;
 fake::step=[](uint64_t t){if(t>=10000 && t<11000)g_flashSaveRequested.store(true);};
 fake::onDelay=[&](){grantObserved=g_flashSaveGranted.load();assert(grantObserved);g_flashSaveRequested.store(false);};
 run();assert(grantObserved);assert(!g_flashSaveGranted.load());assert(fake::reports.empty());
}
void failedNvsWriteRetries() {
 reset();prefs.data.clear();settingsStoreReady=true;needSaveMode=true;
 fake::prefsWriteOk=false;assert(!saveConfigSafely());
 assert(needSaveMode && settingsSaveFailed);
 fake::prefsWriteOk=true;assert(saveConfigSafely());
 assert(!needSaveMode && !settingsSaveFailed);
 assert(prefs.getInt("mode_idx",-1)==MODE_CLOSE);
}
void engineeringPauseClearsMotion() {
 reset(400000);
 fake::trigger=[](uint64_t t){return t>=10000 && (t<250000 || t>=300000);};
 bool requested=false,granted=false;size_t queuedAtPause=0;
 fake::step=[&](uint64_t t){if(t>=70000&&!requested){requested=true;engineering::pauseRequested.store(true);}};
 fake::onDelay=[&](){
   assert(engineering::pauseGranted.load());
   if(!granted){granted=true;queuedAtPause=fake::reports.size();}
   if(fake::now>=170000)engineering::pauseRequested.store(false);
 };
 run();assert(granted);assert(!engineering::pauseGranted.load());
 assert(queuedAtPause>0);bool after=false;
 for(size_t i=queuedAtPause;i<fake::reports.size();++i){assert(fake::reports[i].at>=303000);after=true;}
 assert(after);
}
void zeroHorizontalIncludesNoise() {
 reset();fake::calibration[0].horizontal=0;
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();
 assert(!fake::reports.empty());for(auto r:fake::reports)assert(r.x==0);
}
void zeroSectionsIncludeNoise() {
 reset();fake::calibration[0].start=fake::calibration[0].body=fake::calibration[0].tail=-100;
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();assert(fake::reports.empty());
}
void modeCalibrationIndependent() {
 reset();fake::calibration[1].start=-100;
 g_atomicState.packed.store(packControl(150,MODE_LONG,true));
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();assert(fake::reports.empty());
 reset();fake::calibration[1].start=-100;
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();assert(!fake::reports.empty());
}
void expandedStrengthPreservesControlBits() {
 reset();g_atomicState.packed.store(packControl(150,MODE_LONG,false));
 auto c=readControl();assert(c.strengthStep==150&&c.mode==MODE_LONG&&!c.enabled);
 setControlEnabled(true);setControlMode(MODE_CLOSE);
 c=readControl();assert(c.strengthStep==150&&c.mode==MODE_CLOSE&&c.enabled);
 setControlStrength(0);c=readControl();assert(c.strengthStep==0&&c.enabled);
}
void lastHoldAccounting() {
 reset();fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();
 const auto& m=fake::lastHold;assert(m.sequence==1&&m.ticks>100&&m.minDtUs>900&&m.maxDtUs<1100);
 uint32_t hist=0;for(auto n:m.histogram)hist+=n;assert(hist==m.ticks&&m.queued==fake::reports.size());
 int64_t x=0,y=0;for(auto r:fake::reports){x+=r.x;y+=r.y;}assert(x==m.queuedX&&y==m.queuedY);
 assert(m.reason==motion::EndReason::RELEASE&&m.maxQueueGapUs>0);
}
void catchupCapDropsDebt() {
 reset();fake::calibration[0].noise=0;fake::options.limitCatchup=true;fake::options.catchupMaxPct=0;
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();
 const auto limited=fake::lastHold;assert(limited.droppedCatchupY>0);
 reset();fake::calibration[0].noise=0;
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();
 assert(fake::lastHold.queuedY>limited.queuedY);
}
void warmStartRestoresFraction() {
 reset(3400000);fake::options.continuousWarm=true;
 fake::trigger=[](uint64_t t){return (t>=10000&&t<2300000)||(t>=2400000&&t<3200000);};run();
 assert(fake::holdReports.size()==2);const auto& a=fake::holdReports[0];const auto& b=fake::holdReports[1];
 const auto idle=b.startUs-(a.startUs+a.durationUs);
 const float expected=tuning::cooledPhase(a.endPhase,idle,uint64_t(SPRAY_COOLDOWN_MS)*1000ULL);
 assert(fabsf(expected-b.startPhase)<.001f&&b.startPhase>1&&fabsf(b.startPhase-floorf(b.startPhase))>.001f);
}
void disabledBodyDoesNotLeak() {
 reset(3500000);fake::calibration[0].body=-100;fake::calibration[0].noise=0;fake::options.transitionMs=100;
 fake::trigger=[](uint64_t t){return t>=10000&&t<3400000;};run();
 bool before=false,after=false;for(auto r:fake::reports){assert(r.at<700000||r.at>1650000);if(r.at<700000)before=true;if(r.at>2000000)after=true;}assert(before&&after);
}
void geometricPreviewIsBounded() {
 reset();tuning::Config c;c.strength=150;engineering::Preview p;
 engineering::buildPreview(false,0,c,p);
 for(auto point:p.points){assert(std::isfinite(point.afterX)&&std::isfinite(point.afterY));assert(fabsf(point.beforeY-point.afterY)<.0001f);}
 c.profiles[0].start=c.profiles[0].body=c.profiles[0].tail=-100;
 engineering::buildPreview(false,39,c,p);for(auto point:p.points)assert(point.afterX==0&&point.afterY==0);
}
void modernDefaultsAreBounded() {
 reset();fake::options=tuning::Config{};fake::calibration[0]=tuning::Profile{};fake::calibration[1]=tuning::Profile{};
 fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};run();
 assert(!fake::reports.empty());for(auto r:fake::reports)assert(std::abs(r.x)<=3&&std::abs(r.y)<=3);
 assert(fake::lastHold.droppedCatchupY>0);
}
void warmNearColdBlendsTap() {
 reset(2900000);fake::options.continuousWarm=true;fake::options.limitCatchup=true;fake::calibration[0].noise=0;
 fake::trigger=[](uint64_t t){return (t>=10000&&t<2300000)||(t>=2600000&&t<2630000);};run();
 assert(fake::holdReports.size()==2);const auto& m=fake::holdReports[1];
 assert(m.startPhase>0&&m.startPhase<1&&m.queuedY<=2);
}
int main(){
 normalPress();bootHeld();reconnectHeld(false);reconnectHeld(true);
 longBusyRecovery();rejectedQueueRecovery();zeroProfileStopsTail();delayedSpring();flashHandshake();failedNvsWriteRetries();
 engineeringPauseClearsMotion();zeroHorizontalIncludesNoise();zeroSectionsIncludeNoise();modeCalibrationIndependent();
 expandedStrengthPreservesControlBits();
 lastHoldAccounting();catchupCapDropsDebt();warmStartRestoresFraction();disabledBodyDoesNotLeak();geometricPreviewIsBounded();
 modernDefaultsAreBounded();warmNearColdBlendsTap();
 std::puts("PASS: 22 actual-sketch integration scenarios (stub hardware), including diagnostics, catch-up cap, fractional warm phase/blended tap, strict disabled body, preview and modern defaults");
}
