// Actual handlers/lifecycle; fake network and NVS, real JSON parser.
#include "../firmware/RecoilEngine/EngineeringMode.cpp"
#include <cassert>
using namespace engineering;
void engineering::buildPreview(bool,int,const tuning::Config& c,engineering::Preview& p){for(unsigned i=0;i<Preview::COUNT;++i)p.points[i]={0,float(i),0,float(i)*c.strength*.02f};}
AsyncWebServerRequest request(int revision,const tuning::Config& c){
    AsyncWebServerRequest r;r.headers["Origin"].text="http://192.168.4.1";r.headers["X-Tune-Token"].text=token;
    r.fields["revision"].text=std::to_string(revision);r.fields["document"].text=tuning::documentJson(c);
    r.length=r.fields["document"].text.length()+100;return r;
}
int post(AsyncWebServerRequest& r,const char* path="/update"){server->routes.at(path)(&r);return r.response->code;}
void at(uint32_t ms,bool base=true,int mode=0){fake::now=uint64_t(ms)*1000;service(ms,base,mode);}
void seed(const char* key,const tuning::Config& c,uint32_t generation){uint8_t data[tuning::CONFIG_BLOB_SIZE];tuning::encodeConfig(c,generation,data);storage.putBytes(key,data,sizeof(data));}
int main(int argc,char** argv){
    fake::end=1000000000000000ULL;
    const std::string scenario=argc>1?argv[1]:"normal";
    if(scenario=="bootfault"){
        faultCookie=FAULT_MAGIC|1;fake::resetReason=ESP_RST_SW;assert(begin());
        assert(std::string(lastBootError)=="ap_start"&&faultCookie==0);
        std::puts("PASS: startup fault retained through recovery reset");return 0;
    }
    if(scenario=="bootdisabled"||scenario=="coldboot"){
        resumeCookie=RESUME_MAGIC;fake::resetReason=scenario=="bootdisabled"?ESP_RST_SW:1;
        assert(begin()&&bootEnabled()==(scenario=="coldboot")&&resumeCookie==0);
        std::puts("PASS: RTC resume OFF and cold-boot policy");return 0;
    }
    if(scenario=="restore"||scenario=="corrupt"){
        tuning::Config a;a.strength=53;seed("a",a,4);auto b=a;b.strength=123;b.profiles[1].noise=25;seed("b",b,5);
        if(scenario=="corrupt")storage.bytes["b"][20]^=1;
        assert(begin());assert(adoptLegacyStrength(150)==(scenario=="restore"?123:53));
        assert(runtimeConfig().strength==(scenario=="restore"?123:53));
        assert(snapshot().recovered==(scenario=="corrupt"));assert(!storageFault());
        std::puts("PASS: schema3 boot restore and newest-corrupt fallback");return 0;
    }
    if(scenario=="legacy"){
        tuning::Profile p[2];p[1].tail=32;uint8_t old[tuning::BLOB_SIZE];tuning::encode(p,old,67);storage.putBytes("config",old,sizeof(old));
        assert(begin()&&adoptLegacyStrength(150)==67);assert(snapshot().migrated);
        assert(runtimeProfile(true).tail==32&&runtimeProfile(true).microMs==0&&!runtimeConfig().limitCatchup);
        std::puts("PASS: R4.0 NVS migration keeps legacy model");return 0;
    }
    assert(begin());assert(!fake::wifiInitialized&&fake::apStarts==0);assert(adoptLegacyStrength(150)==150);
    buttonPressed(10,false);at(11);assert(pauseRequested.load()&&fake::apStarts==0);
    if(scenario=="timeout"){at(2010);assert(phase()==Phase::FAULT&&fake::apStarts==0);std::puts("PASS: pause timeout keeps HID paused");return 0;}
    if(scenario=="apfail")fake::apOk=false;
    if(scenario=="listenfail")fake::listenerOk=false;
    pauseGranted.store(true);at(12);
    if(scenario=="apfail"||scenario=="listenfail"){
        assert(phase()==Phase::FAULT&&pauseRequested.load()&&!fake::wifiInitialized);assert((faultCookie&0xffffff00u)==FAULT_MAGIC);
        std::puts("PASS: AP/listener startup failure shuts radio, retains pause");return 0;
    }
    assert(phase()==Phase::TUNING&&fake::apStarts==1);
    if(scenario=="idle"){
        fake::stations=1;at(300012);assert(phase()==Phase::TUNING);
        fake::stations=0;at(300013);at(600012);assert(phase()==Phase::TUNING);
        at(600013);assert(phase()==Phase::SAVING_EXIT);at(600014);assert(phase()==Phase::STOPPING);
        std::puts("PASS: idle timeout counts only time without clients, flushes then exits");return 0;
    }
    if(scenario=="import"){
        std::string p="{\"horizontal\":100,\"vertical\":50,\"start\":-20,\"body\":0,\"tail\":30}";
        auto r=request(0,snapshot().config);r.fields["document"].text="{\"schema\":2,\"strength\":43,\"profiles\":["+p+","+p+"]}";
        assert(post(r,"/import")==200&&snapshot().config.strength==43&&!snapshot().config.continuousWarm);
        AsyncWebServerRequest exported;server->routes.at("/export")(&exported);tuning::Config parsed;
        assert(tuning::parseDocument(exported.response->body,parsed)&&tuning::equal(parsed,snapshot().config));
        auto reset=request(1,snapshot().config);reset.fields.erase("document");reset.length=10;
        assert(post(reset,"/reset")==200&&snapshot().revision==2&&snapshot().config.limitCatchup);
        std::puts("PASS: legacy JSON import, complete export and protected atomic reset");return 0;
    }
    AsyncWebServerRequest page;server->routes.at("/")(&page);assert(page.response->code==200&&page.response->headers.count("Content-Security-Policy"));
    auto c=snapshot().config;
    {auto r=request(0,c);r.hostName="evil.example";assert(post(r)==403);
     r=request(0,c);r.headers["Origin"].text="http://evil.example";assert(post(r)==403);
     r=request(0,c);r.headers.erase("X-Tune-Token");assert(post(r)==403);
     r=request(0,c);r.fields["document"].text="{}";assert(post(r)==400);
     r=request(0,c);r.length=8193;assert(post(r)==400);
     r=request(0,c);r.fields["extra"].text="1";assert(post(r)==400);
     assert(snapshot().revision==0);}
    fake::now=20000;c.strength=73;c.profiles[0].start=-100;c.profiles[1].noise=33;
    auto edit=request(0,c);assert(post(edit)==200&&snapshot().revision==1);assert(runtimeConfig().strength==150);
    auto stale=request(0,c);assert(post(stale)==409);
    c.profiles[1].vertical=20;auto next=request(1,c);assert(post(next)==200);
    at(100);assert(snapshot().savedRevision==0);
    fake::prefsWriteOk=false;at(1000);assert(storageFault()&&snapshot().savedRevision==0);
    fake::prefsWriteOk=true;at(1500);assert(snapshot().savedRevision==0);at(3100);
    assert(snapshot().savedRevision==2&&!storageFault()&&storage.isKey("a")&&storage.isKey("b"));
    fake::now=3200000;c.profiles[0].start=25;auto third=request(2,c);assert(post(third)==200);
    fake::onWrite=[](){auto concurrent=snapshot().config;concurrent.profiles[1].horizontal=30;auto r=request(3,concurrent);assert(post(r)==200);};
    at(6000);assert(snapshot().revision==4&&snapshot().savedRevision==3);fake::onWrite=[](){};
    // JSON, CSV and bounded preview routes execute the real handlers.
    motion::Report m;m.sequence=7;m.ticks=2;m.queuedX=3;m.minDtUs=999;m.dtSumUs=2000;m.histogram[2]=1;m.histogram[3]=1;publishMotion(m);
    AsyncWebServerRequest state;server->routes.at("/api/config")(&state);assert(state.response->body.find("\"sequence\":7")!=std::string::npos);
    AsyncWebServerRequest csv;server->routes.at("/diagnostics.csv")(&csv);assert(csv.response->body.find("queued_x,3,HID_counts")!=std::string::npos);
    AsyncWebServerRequest graph;graph.fields["mode"].text="close";graph.fields["pattern"].text="0";server->routes.at("/preview")(&graph);
    assert(graph.response->code==200&&graph.response->body.find("\"points\":[")!=std::string::npos);
    buttonPressed(6100);assert(phase()==Phase::SAVING_EXIT);auto late=request(4,c);assert(post(late)==503);
    fake::prefsWriteOk=false;at(6100,false);assert(phase()==Phase::SAVING_EXIT&&fake::wifiInitialized&&fake::restarts==0);
    fake::prefsWriteOk=true;at(8200,false);assert(snapshot().savedRevision==4&&phase()==Phase::SAVING_EXIT);
    at(8210);assert(phase()==Phase::STOPPING&&!fake::wifiInitialized&&fake::serverEnds==1);
    tuning::CalibrationStore boot(storage);auto restored=boot.load();assert(restored.strength==73&&restored.profiles[1].horizontal==30);
    at(8300);assert(fake::restarts==0);try{at(8410);assert(false);}catch(const fake::Restart&){}
    assert(fake::restarts==1&&resumeCookie==RESUME_MAGIC);
    std::puts("PASS: actual HTTP security/CAS, RAM vs NVS, debounce/retry/concurrent save, graph/CSV, and final flush before radio/reset");
}
