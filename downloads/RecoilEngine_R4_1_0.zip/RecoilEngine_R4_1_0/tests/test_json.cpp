#include "../firmware/RecoilEngine/TuningJson.h"
#include <cassert>
#include <string>
int main(){
    tuning::Config c;c.profiles[1].microMs=23;c.strength=75;
    auto json=tuning::documentJson(c);tuning::Config out;
    assert(tuning::parseDocument(json,out)&&tuning::equal(c,out));
    auto mutate=[&](const std::string& a,const std::string& b){auto s=json;auto p=s.find(a);assert(p!=s.npos);s.replace(p,a.length(),b);return s;};
    assert(!tuning::parseDocument(mutate("\"strength\":75","\"strength\":151"),out));
    assert(!tuning::parseDocument(mutate("\"strength\":75","\"strength\":1.5"),out));
    assert(!tuning::parseDocument(mutate("\"strength\":75","\"strength\":null"),out));
    assert(!tuning::parseDocument(mutate("\"strength\":75","\"strength\":75,\"strength\":1"),out));
    assert(!tuning::parseDocument(mutate("\"limitCatchup\":true","\"limitCatchup\":1"),out));
    assert(!tuning::parseDocument(mutate("\"idleTimeoutSec\":300","\"idleTimeoutSec\":1"),out));
    assert(!tuning::parseDocument(json+"junk",out));
    assert(!tuning::parseDocument(std::string(2100,' '),out));
    assert(!tuning::parseDocument(std::string(20,'[')+std::string(20,']'),out));
    assert(!tuning::parseDocument(json+std::string(1,'\0')+"{}",out));
    std::string p="{\"horizontal\":100,\"vertical\":100,\"start\":0,\"body\":0,\"tail\":0}";
    auto legacy="{\"schema\":2,\"strength\":33,\"profiles\":["+p+","+p+"]}";
    assert(tuning::parseDocument(legacy,out)&&out.strength==33&&!out.limitCatchup&&out.profiles[0].microMs==0);
    assert(!tuning::equal(c,out));
    std::puts("PASS: real cJSON import/export, strict complete schema, duplicate/type/range rejection, nesting/size/NUL limits and schema2 conversion");
}
