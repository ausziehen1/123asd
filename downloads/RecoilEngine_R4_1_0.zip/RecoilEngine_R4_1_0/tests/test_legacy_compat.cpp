// Golden fixtures generated from published R4.0.0 ZIP SHA256 06541db946b6627e1b4f99eccaf6e303f4771429101ac6118d7a713122e00394.
#include "../firmware/RecoilEngine/RecoilEngine.ino"
#include "stubs/EngineeringStubs.h"
#include <cassert>
#include <cstdio>
#include <cinttypes>
void reset(uint64_t end){
 fake::now=0;fake::end=end;fake::wake=0;fake::rng=7;fake::reports.clear();fake::isReady=fake::isMounted=true;fake::isSuspended=fake::rejectReports=false;
 fake::step=[](uint64_t){};fake::onDelay=[](){};
 g_tasksReady.store(true);g_engineFault.store(false);g_flashSaveRequested.store(false);g_flashSaveGranted.store(false);
 engineering::pauseRequested.store(false);engineering::pauseGranted.store(false);
 g_atomicState.packed.store(packControl(150,MODE_CLOSE,true));engineWakeTimer=(void*)1;r32InitDynamics();
 fake::calibration[0]=tuning::Profile{};fake::calibration[1]=tuning::Profile{};
 fake::calibration[0].microMs=fake::calibration[1].microMs=0;
 fake::options=tuning::legacyConfig(fake::calibration,150);
}
uint64_t digest(){uint64_t hash=14695981039346656037ULL;auto add=[&](uint64_t n,unsigned count){for(unsigned i=0;i<count;++i){hash^=uint8_t(n>>(8*i));hash*=1099511628211ULL;}};
 for(auto r:fake::reports){add(r.at,8);add(uint16_t(r.x),2);add(uint16_t(r.y),2);}return hash;}
int main(){for(int scenario=0;scenario<5;++scenario){
 reset(scenario>=3?4200000:600000);
 if(scenario==0)fake::trigger=[](uint64_t t){return t>=10000&&t<200000;};
 if(scenario==1)fake::trigger=[](uint64_t t){return t>=10000&&t<54000;};
 if(scenario==2)fake::trigger=[](uint64_t t){return(t>=10000&&t<200000)||(t>=300000&&t<500000);};
 if(scenario>=3)fake::trigger=[](uint64_t t){return t>=10000&&t<4000000;};
 if(scenario==4){g_atomicState.packed.store(packControl(73,MODE_LONG,true));auto& p=fake::calibration[1];p.horizontal=45;p.vertical=60;p.start=25;p.body=-50;p.tail=90;}
 try{EngineTask(nullptr);}catch(const fake::Stop&){}
 const size_t counts[]={56,2,114,895,675};
 const uint64_t expected[]={0x63946491c3d36b1aULL,0x172d74444ae4e524ULL,0x8e171ff50c008ba4ULL,0x81723a888cef58b2ULL,0x988ec7bb12603a95ULL};
 assert(fake::reports.size()==counts[scenario]&&digest()==expected[scenario]);
}
std::puts("PASS: 5 exact deterministic HID-trace fixtures match published R4.0.0 in legacy mode");
}
