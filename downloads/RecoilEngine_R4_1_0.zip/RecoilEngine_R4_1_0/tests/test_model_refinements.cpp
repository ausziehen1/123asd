#include "../firmware/RecoilEngine/TuningConfig.h"
#include "../firmware/RecoilEngine/MotionReport.h"
#include <cassert>
#include <cstdio>
#include <cmath>
int main(){
    tuning::Config c;assert(tuning::valid(c));
    c.strength=73;c.profiles[0].noise=155;c.profiles[1].microMs=38;
    uint8_t blob[tuning::CONFIG_BLOB_SIZE];tuning::encodeConfig(c,0xffffffffu,blob);
    tuning::Config restored;uint32_t generation=0;assert(tuning::decodeConfig(blob,sizeof(blob),restored,generation));
    assert(tuning::equal(c,restored)&&generation==0xffffffffu);
    for(size_t i=0;i<sizeof(blob);++i){blob[i]^=1;assert(!tuning::decodeConfig(blob,sizeof(blob),restored,generation));blob[i]^=1;}
    tuning::put16(blob+6,151);tuning::put32(blob+60,tuning::crc32(blob,60));assert(!tuning::decodeConfig(blob,sizeof(blob),restored,generation));
    assert(tuning::generationNewer(0,0xffffffffu)&&!tuning::generationNewer(0xffffffffu,0));
    tuning::Profile p;p.start=100;p.body=-50;p.tail=40;
    assert(tuning::sectionGain(p,5.0f,40)==2.0f);assert(tuning::sectionGain(p,7.0f,40)==.5f);
    float previous=2;
    for(unsigned i=0;i<=1000;++i){float phase=5.8f+float(i)*.0004f;float g=tuning::sectionGain(p,phase,40);assert(g<=2.00001f&&g>=.49999f&&g<=previous+.00001f);previous=g;}
    p.body=-100;
    for(unsigned i=0;i<1200;++i)assert(tuning::sectionGain(p,6.0f+float(i)*.01f,100)==0);
    assert(tuning::sectionGain(p,5.99f,100)<.001f&&tuning::sectionGain(p,18.01f,100)<.001f);
    p.start=p.body=p.tail=0;
    for(unsigned i=0;i<3000;++i)assert(tuning::sectionGain(p,float(i)*.01f,40)==1);
    float last=24.75f;
    for(unsigned us=0;us<=320000;us+=100){const float phase=tuning::cooledPhase(24.75f,us,320000);assert(phase>=0&&phase<=last+.00001f);last=phase;}
    assert(tuning::cooledPhase(24.75f,320000,320000)==0&&tuning::cooledPhase(24.75f,319000,320000)<.001f);
    float state=0;
    for(int i=0;i<1000;++i){float v=tuning::microSample(i%2?-1.0f:1.0f,1000,12,state);assert(fabsf(v)<=1);}
    assert(tuning::microSample(.75f,1000,0,state)==.75f);
    assert(tuning::catchupStep(100,1,0,2,50)==1);
    assert(tuning::catchupStep(-100,1,0,-2,50)==-1);
    assert(tuning::catchupStep(100,1,0,0,50)==0);
    assert(tuning::catchupStep(100,1,0,2,0)==0);
    p.noise=100;c.noiseFollowStrength=true;assert(tuning::noiseGain(p,c,1.5f)==.5f);
    c.noiseFollowStrength=false;assert(tuning::noiseGain(p,c,1.5f)==1);
    motion::Recorder r;r.start(1,100,0,73);r.tick(999,60,2);r.tick(1500,0,0);r.queued(2,-3,1100);r.queued(1,4,2600);
    const auto m=r.finish(3000,motion::EndReason::RELEASE);
    assert(m.ticks==2&&m.minDtUs==999&&m.maxDtUs==1500&&m.dtSumUs==2499&&m.lateTicks==1&&m.missedSlots==2);
    assert(m.histogram[2]==1&&m.histogram[6]==1&&m.queuedX==3&&m.queuedY==1&&m.maxQueueGapUs==1500);
    std::puts("PASS: schema3 CRC/bounds, generation rollover, smooth gains/strict zero, continuous cooldown, bounded correlated noise, catch-up cap and motion accounting");
}
