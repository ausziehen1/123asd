// The embedded JS runs against a minimal DOM and asynchronous HTTP model.
// This validates behavior, not browser layout or actual RF/TCP.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source=fs.readFileSync(new URL('../firmware/RecoilEngine/EngineeringPage.h',import.meta.url),'utf8');
const html=source.match(/R"rawliteral\(([\s\S]*)\)rawliteral"/)[1];
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const profile=()=>({horizontal:100,vertical:100,start:0,body:0,tail:0,noise:100,microMs:12});
const defaults=()=>({strength:150,transitionMs:40,catchupMaxPct:50,idleTimeoutSec:300,noiseFollowStrength:true,limitCatchup:true,continuousWarm:true,profiles:[profile(),profile()]});
const clone=v=>structuredClone(v);
const initial=()=>({version:'4.1.0',schema:3,phase:'tuning',revision:0,savedRevision:0,storageError:false,errorCode:'none',recovered:false,migrated:false,generation:0,workingMode:1,token:'session-token',config:defaults(),lastHold:{sequence:0}});
let state=initial(),hold=[],inFlight=0,maxInFlight=0,staleGet=false,getCount=0,downloads=[],persist=new Map(),previewHold=null;
class Element{
 constructor(tag='div'){this.tag=tag;this.value='';this.disabled=true;this.checked=false;this.textContent='';this.children=[];this.listeners={};this.attrs={};this.files=[];this.classList={toggle(){}};}
 get firstChild(){return this.children[0]||null;}
 appendChild(c){this.children.push(c);if(this.tag==='select'&&this.value==='')this.value=c.value;return c;}
 removeChild(c){this.children.splice(this.children.indexOf(c),1);return c;}
 setAttribute(k,v){this.attrs[k]=v;}
 addEventListener(type,fn){this.listeners[type]=fn;}
 click(){if(!this.disabled&&this.listeners.click)return this.listeners.click();}
}
function harness(){
 const elements={},controls=[];
 for(const match of html.matchAll(/\bid="([^"\s]+)"/g))elements[match[1]]=new Element();
 for(const m of html.matchAll(/<(input|button|select)\b([^>]*\bid="([^"]+)"[^>]*)>/g)){
  const e=elements[m[3]];e.tag=m[1];const value=m[2].match(/\bvalue="([^"]*)"/);if(value)e.value=value[1];controls.push(e);
 }
 const timers=new Map(),intervals=[];let next=0;
 const context=vm.createContext({
  document:{getElementById:id=>{assert(elements[id],id);return elements[id];},querySelectorAll:()=>controls,createElement:tag=>{const e=new Element(tag);e.disabled=false;return e;},createElementNS:(ns,tag)=>new Element(tag)},
  window:{addEventListener(){},confirm:()=>true},
  localStorage:{getItem:k=>persist.get(k)||null,setItem:(k,v)=>persist.set(k,v)},
  Blob,URL:{createObjectURL:b=>{downloads.push(b);return 'blob:test';},revokeObjectURL(){}},AbortController,URLSearchParams,
  setTimeout:(fn,ms)=>{timers.set(++next,{fn,ms});return next;},clearTimeout:id=>timers.delete(id),setInterval:fn=>intervals.push(fn),
  fetch:async(url,options)=>{
   if(url==='/api/config'){++getCount;const s=clone(state);if(staleGet)s.revision=0;return {ok:true,json:async()=>s};}
   if(url==='/export')return {ok:true,json:async()=>({schema:3,config:clone(state.config)})};
   if(url.startsWith('/preview?')){const data={revision:state.revision,points:[[0,0,0,0],[1,10,2,20]]};if(previewHold)return await new Promise(resolve=>previewHold.resolve=()=>resolve({ok:true,json:async()=>data}));return {ok:true,json:async()=>data};}
   assert(['/update','/import','/reset'].includes(url));assert.equal(options.method,'POST');assert.equal(options.headers['X-Tune-Token'],state.token);
   ++inFlight;maxInFlight=Math.max(maxInFlight,inFlight);
   return await new Promise(resolve=>hold.push(()=>{
    --inFlight;const p=options.body;
    if(Number(p.get('revision'))!==state.revision){resolve({ok:false,status:409,json:async()=>({error:'conflict'})});return;}
    let config;
    if(url==='/reset')config=defaults();else{
     const doc=JSON.parse(p.get('document'));
     if(doc.schema!==3||!doc.config){resolve({ok:false,status:400,json:async()=>({error:'invalid schema'})});return;}
     config=clone(doc.config);
    }
    state.config=config;++state.revision;resolve({ok:true,json:async()=>clone(state)});
   }));
  }
 });
 vm.runInContext(script,context);
 return {elements,context,intervals,input:(id,value)=>{assert.equal(elements[id].disabled,false,id);elements[id].value=String(value);return elements[id].listeners.input();},click:id=>elements[id].click(),flush:async(ms)=>{for(const [id,t] of [...timers])if(t.ms===ms){timers.delete(id);await t.fn();}},change:id=>elements[id].listeners.change()};
}
async function settle(){for(let i=0;i<40;++i)await Promise.resolve();}
async function release(){assert.equal(hold.length,1);hold.shift()();await settle();}
let h=harness();await settle();assert.equal(h.elements.strength.value,150);assert.match(h.elements.meta.textContent,/Дальний/);assert.match(h.elements.editing.textContent,/Ближний/);
await h.flush(180);assert(h.elements.pathAfter.attrs.points);assert.match(h.elements.previewTotals.textContent,/С настройкой/);
h.input('horizontal',0);const sending=h.flush(60);await settle();assert.equal(hold.length,1);
h.input('strength',73);h.click('long');h.input('vertical',23);h.elements.noiseFollowStrength.checked=false;h.change('noiseFollowStrength');
await release();assert.equal(hold.length,1);await release();await sending;
assert.equal(inFlight,0);assert.equal(maxInFlight,1);assert.equal(state.revision,2);
assert.equal(state.config.profiles[0].horizontal,0);assert.equal(state.config.profiles[1].vertical,23);assert.equal(state.config.strength,73);assert.equal(state.config.noiseFollowStrength,false);
assert.equal(h.elements.export.disabled,false);
h.click('enableRefinements');const refining=h.flush(60);await settle();await release();await refining;
assert.equal(state.config.noiseFollowStrength,true);assert.equal(state.config.profiles[0].horizontal,0);assert.equal(state.config.profiles[1].vertical,23);assert.equal(state.config.strength,73);

await h.click('export');assert.equal(downloads.length,1);const saved=JSON.parse(await downloads[0].text());assert.equal(saved.schema,3);assert.equal(saved.config.strength,73);
h.elements.presetName.value='Test';h.click('saveLocal');assert(persist.get('RecoilEngine-presets-schema3').includes('Test'));
h.input('vertical',31);const another=h.flush(60);await settle();await release();await another;assert.equal(state.config.profiles[1].vertical,31);
const loading=h.click('loadLocal');await settle();assert.equal(h.elements.horizontal.disabled,true);await release();await loading;
assert.equal(state.config.profiles[1].vertical,23);assert.equal(h.elements.vertical.value,23);
const resetting=h.click('reset');await settle();await release();await resetting;assert.equal(state.config.strength,150);assert.equal(h.elements.vertical.value,100);
// A malformed imported document is rejected atomically without freezing a valid page.
h.elements.file.files=[{size:20,text:async()=>'{"schema":99}'}];const importing=h.change('file');await settle();await release();await importing;
assert.equal(h.elements.horizontal.disabled,false);assert.match(h.elements.status.textContent,/invalid schema/);
state.lastHold={sequence:7,mode:1,pattern:12,strength:73,startPhase:.25,endPhase:2.8,durationUs:100000,ticks:100,minDtUs:999,meanDtUs:1000,maxDtUs:1001,lateTicks:0,missedSlots:0,busy:1,rejected:0,drops:0,queued:60,queuedX:1,queuedY:70,maxQueueGapUs:2000,droppedCatchupX:0,droppedCatchupY:.5,reason:0,histogram:[0,0,1,99,0,0,0,0,0]};state.savedRevision=state.revision;state.generation=4;await h.intervals[0]();assert.match(h.elements.status.textContent,/Сохранено во флеш/);assert.equal(h.elements.histogram.children.length,9);assert.match(h.elements.diagnostics.textContent,/паттерн 12/);
staleGet=true;await h.intervals[0]();assert.equal(h.elements.horizontal.disabled,false);staleGet=false;
// A slow preview for an older selected pattern must cause a refresh.
previewHold={};const drawing=h.flush(180);await settle();h.elements.pattern.value='1';h.change('pattern');previewHold.resolve();await drawing;previewHold=null;await h.flush(180);
++state.revision;await h.intervals[0]();assert.equal(h.elements.horizontal.disabled,true);assert.match(h.elements.status.textContent,/другой вкладкой/);
state=initial();state.phase='saving';state.storageError=true;state.errorCode='nvs_write_a';
h=harness();await settle();assert.match(h.elements.status.textContent,/nvs_write_a/);const count=getCount;await h.intervals[0]();assert.equal(getCount,count+1);
console.log('PASS: embedded JS full-config queue, independent modes, noise options, preview/stale response, JSON export/import rejection, local presets/reset, CAS conflict and exit-error polling');
