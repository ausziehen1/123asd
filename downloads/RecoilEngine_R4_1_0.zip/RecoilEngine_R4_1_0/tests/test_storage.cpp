#include "../firmware/RecoilEngine/CalibrationStore.h"
#include <cassert>
using namespace tuning;
int main(){
    Preferences prefs;CalibrationStore store(prefs);Config c=store.load();assert(!store.loaded&&valid(c));
    c.strength=73;assert(store.save(c));assert(prefs.isKey("a")&&prefs.isKey("b"));
    CalibrationStore reboot(prefs);assert(equal(reboot.load(),c)&&reboot.loaded);
    Config newer=c;newer.profiles[1].tail=35;assert(reboot.save(newer));
    // Newest slot is B after the second write. Damage it; previous A stays valid.
    prefs.bytes["b"][30]^=1;
    CalibrationStore fallback(prefs);assert(equal(fallback.load(),c)&&fallback.recovered);
    fake::prefsWriteOk=false;assert(!fallback.save(newer));fake::prefsWriteOk=true;
    assert(fallback.save(newer));CalibrationStore repaired(prefs);assert(equal(repaired.load(),newer));
    // Readback corruption must not publish a bad slot as current.
    fake::onWrite=[&](){prefs.bytes["a"][29]^=1;};Config third=newer;third.strength=11;
    assert(!repaired.save(third));fake::onWrite=[](){};
    CalibrationStore afterFailure(prefs);assert(equal(afterFailure.load(),newer));
    Preferences fresh;CalibrationStore first(fresh);first.load();
    fake::onWrite=[](){fake::prefsWriteOk=false;};assert(!first.save(c));
    fake::prefsWriteOk=true;fake::onWrite=[](){};assert(first.save(c));
    Preferences legacy;Profile old[2];old[0].start=-23;uint8_t oldBlob[BLOB_SIZE];encode(old,oldBlob,93);legacy.putBytes("config",oldBlob,sizeof(oldBlob));
    CalibrationStore migration(legacy);Config imported=migration.load();
    assert(migration.loaded&&migration.migrated&&imported.strength==93&&imported.profiles[0].start==-23);
    assert(imported.profiles[0].microMs==0&&!imported.limitCatchup&&!imported.noiseFollowStrength&&!imported.continuousWarm&&imported.transitionMs==0);
    assert(migration.save(imported));assert(legacy.isKey("config"));
    Preferences rollover;uint8_t data[CONFIG_BLOB_SIZE];encodeConfig(c,0xffffffffu,data);rollover.putBytes("a",data,sizeof(data));
    encodeConfig(c,0xfffffffeu,data);rollover.putBytes("b",data,sizeof(data));CalibrationStore wrap(rollover);wrap.load();assert(wrap.save(newer));
    CalibrationStore wrapBoot(rollover);assert(equal(wrapBoot.load(),newer)&&wrapBoot.savedGeneration()==0);
    std::puts("PASS: two-slot NVS, first-save fallback, power/retry failures, corrupt-newest recovery, readback rejection, R4 migration and generation wrap");
}
