#include "../firmware/RecoilEngine/TuningModel.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <initializer_list>
using namespace tuning;
int main() {
    Profile p[2];
    assert(valid(p[0])&&equal(p[0],p[1]));
    for(int shot=0;shot<30;++shot)assert(sectionGain(p[0],shot)==1.0f);
    assert(patternY(8.0f,4.2f,p[0])==8.0f);
    for(int step=0;step<=STRENGTH_STEPS;++step)assert(std::fabs(strengthMultiplier(step)-float(step)/50.0f)<0.000001f);
    assert(strengthMultiplier(0)==0.0f&&strengthMultiplier(150)==3.0f);
    p[0].horizontal=0;p[0].vertical=0;p[0].start=-100;p[0].body=100;p[0].tail=-50;
    assert(sectionGain(p[0],0)==0&&sectionGain(p[0],5)==0);
    assert(sectionGain(p[0],6)==2&&sectionGain(p[0],17)==2);
    assert(sectionGain(p[0],18)==0.5f&&sectionGain(p[0],29)==0.5f);
    assert(patternY(8.0f,4.2f,p[0])==4.2f);
    assert(p[1].horizontal==100&&p[1].start==0);
    uint8_t blob[BLOB_SIZE];encode(p,blob,73);
    uint16_t strength=0;
    Profile restored[2];assert(decode(blob,sizeof(blob),restored,&strength)&&strength==73);
    assert(equal(p[0],restored[0])&&equal(p[1],restored[1]));
    for(size_t i=0;i<BLOB_SIZE;++i){blob[i]^=1;assert(!decode(blob,sizeof(blob),restored));blob[i]^=1;}
    assert(!decode(blob,BLOB_SIZE-1,restored));
    blob[8]=101; // invalid horizontal value with a deliberately valid checksum
    uint32_t crc=crc32(blob,28);for(unsigned b=0;b<4;++b)blob[28+b]=uint8_t(crc>>(8*b));
    assert(!decode(blob,BLOB_SIZE,restored));assert(equal(restored[0],p[0]));
    int value=9;
    assert(parseInt("-100",-100,100,value)&&value==-100);
    assert(parseInt("100",0,100,value)&&value==100);
    for(auto text:{"", "-", "+1", " 1", "1 ", "1.2", "NaN", "1a", "101", "999999999999999999"})
        assert(!parseInt(text,0,100,value));
    assert(!parseInt("-1",0,100,value));
    std::puts("PASS: tuning defaults, bounds, region gains, profile separation, NVS CRC/atomic decode, strict parser");
}
