#pragma once
#include <limits.h>
#include <stdint.h>

namespace motion {
struct ComputeTiming {
  uint64_t sumCycles = 0;
  uint32_t samples = 0, minCycles = UINT32_MAX, maxCycles = 0;
  uint32_t minSlackCycles = UINT32_MAX, overBudget = 0;
  uint32_t cpuMHz = 0;
  void add(uint32_t cycles, uint32_t budgetCycles) {
    if (samples == UINT32_MAX)
      return;
    ++samples;
    sumCycles += cycles;
    if (cycles < minCycles)
      minCycles = cycles;
    if (cycles > maxCycles)
      maxCycles = cycles;
    const uint32_t slack = cycles < budgetCycles ? budgetCycles - cycles : 0;
    if (slack < minSlackCycles)
      minSlackCycles = slack;
    if (cycles >= budgetCycles)
      ++overBudget;
  }
};

} // namespace motion
