#include "EngineeringMode.h"
#include "CalibrationStore.h"
#include "EngineeringPage.h"
#include "TuningJson.h"
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <WiFi.h>
#include <esp_attr.h>
#include <esp_random.h>
#include <esp_system.h>
#include <esp_wifi.h>
#include <lwip/tcp.h>
#include <memory>
#include <new>

namespace engineering {
std::atomic<bool> pauseRequested{false}, pauseGranted{false};
namespace {
std::atomic<Phase> current{Phase::PLAY};
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
tuning::Config runtime;
struct Draft {
  tuning::Config config;
  uint32_t revision = 0, savedRevision = 0, changedAt = 0;
  int workingMode = 0;
  bool storageError = false, baseStorageError = false, accepting = false,
       recovered = false, migrated = false;
  uint32_t generation = 0;
  tuning::StoreError storeError = tuning::StoreError::NONE;
} draft;
motion::Report lastMotion;
DRAM_ATTR motion::TraceCapture capturedTrace;
Preferences storage;
tuning::CalibrationStore calibrationStore(storage);
RTC_NOINIT_ATTR uint32_t resumeCookie;
RTC_NOINIT_ATTR uint32_t faultCookie;
RTC_NOINIT_ATTR uint32_t traceCookie;
static constexpr uint32_t TRACE_MAGIC = 0x54524342u;
static constexpr uint32_t RESUME_MAGIC = 0x53335400u;
static constexpr uint32_t FAULT_MAGIC = 0x45525200u;
const char *const faultNames[] = {"none",          "ap_start",
                                  "server_memory", "http_listen",
                                  "pause_timeout", "pause_lost"};
const char *lastBootError = "none";
bool enabledAtBoot = true, enabledBeforeTuning = true, attemptedSave = false,
     noClients = false;
uint32_t phaseAt = 0, lastSaveAttempt = 0, noClientsSince = 0;
char token[33] = {};
std::atomic<const char *> systemError{"none"};
class CheckedServer : public AsyncWebServer {
public:
  CheckedServer() : AsyncWebServer(80) {}
  bool listening() { return _server.status() == LISTEN; }
};
CheckedServer *server =
    nullptr; // never delete while callbacks may exist; reclaimed by reset
Draft snapshot() {
  portENTER_CRITICAL(&mux);
  const Draft s = draft;
  portEXIT_CRITICAL(&mux);
  return s;
}
motion::Report motionSnapshot() {
  portENTER_CRITICAL(&mux);
  const auto s = lastMotion;
  portEXIT_CRITICAL(&mux);
  return s;
}
const char *phaseName() {
  switch (current.load(std::memory_order_acquire)) {
  case Phase::TUNING:
    return "tuning";
  case Phase::SAVING_EXIT:
    return "saving";
  case Phase::FAULT:
    return "fault";
  default:
    return "transition";
  }
}
bool radioOff() {
  (void)WiFi.mode(WIFI_OFF);
  const auto a = esp_wifi_stop(), b = esp_wifi_deinit();
  wifi_mode_t mode;
  return (a == ESP_OK || a == ESP_ERR_WIFI_NOT_INIT) &&
         (b == ESP_OK || b == ESP_ERR_WIFI_NOT_INIT) &&
         esp_wifi_get_mode(&mode) == ESP_ERR_WIFI_NOT_INIT;
}
void headers(AsyncWebServerResponse *r) {
  r->addHeader("Cache-Control", "no-store");
  r->addHeader("X-Content-Type-Options", "nosniff");
  r->addHeader("Connection", "close");
  r->addHeader("Content-Security-Policy",
               "default-src 'none'; script-src 'unsafe-inline'; style-src "
               "'unsafe-inline'; connect-src "
               "'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri "
               "'none'; form-action 'self'");
}
void reply(AsyncWebServerRequest *r, int status, const String &body,
           const char *type = "application/json; charset=utf-8",
           const char *filename = nullptr) {
  auto *response = r->beginResponse(status, type, body);
  headers(response);
  if (filename)
    response->addHeader("Content-Disposition",
                        String("attachment; filename=\"") + filename + "\"");
  r->send(response);
}
bool hostAllowed(AsyncWebServerRequest *r) {
  return r->host() == "192.168.4.1" || r->host() == "192.168.4.1:80";
}
bool allowed(AsyncWebServerRequest *r, bool mutation = false) {
  if (!hostAllowed(r) ||
      (mutation && ((r->hasHeader("Origin") &&
                     r->getHeader("Origin")->value() != "http://192.168.4.1") ||
                    !r->hasHeader("X-Tune-Token") ||
                    r->getHeader("X-Tune-Token")->value() != token))) {
    reply(r, 403, "{\"error\":\"Доступ запрещён\"}");
    return false;
  }
  return true;
}
String computeJson(const motion::ComputeTiming &m) {
  char out[550];
  const double mhz = m.cpuMHz ? m.cpuMHz : 1;
  snprintf(out, sizeof(out),
           "{\"samples\":%lu,\"cpuMHz\":%lu,\"minUs\":%.3f,\"maxUs\":%.3f,"
           "\"meanUs\":%.3f,\"minSlackUs\":%.3f,\"overBudget\":%lu}",
           (unsigned long)m.samples, (unsigned long)m.cpuMHz,
           m.samples ? double(m.minCycles) / mhz : 0.0,
           double(m.maxCycles) / mhz,
           m.samples ? double(m.sumCycles) / m.samples / mhz : 0.0,
           m.samples ? double(m.minSlackCycles) / mhz : 0.0,
           (unsigned long)m.overBudget);
  return String(out);
}
String traceJson() {
  // No read of the single-writer buffer until Core 1 has acknowledged its
  // pause.
  if (!pauseGranted.load(std::memory_order_acquire))
    return "{\"available\":false}";
  const auto &t = capturedTrace;
  const char *names[] = {"off",  "armed", "recording",
                         "done", "full",  "time_limit"};
  bool pending;
  portENTER_CRITICAL(&mux);
  pending = traceCookie == TRACE_MAGIC;
  portEXIT_CRITICAL(&mux);
  char out[550];
  snprintf(
      out, sizeof(out),
      "{\"available\":true,\"status\":\"%s\",\"samples\":%lu,\"capacity\":%u,"
      "\"truncated\":%s,\"finished\":%s,\"pending\":%s,\"sequence\":%lu,"
      "\"mode\":%u,\"pattern\":%u,\"strength\":%u,\"reason\":%u}",
      names[unsigned(t.state)], (unsigned long)t.count,
      unsigned(ENGINE_TRACE_SAMPLES), t.truncated() ? "true" : "false",
      t.finished ? "true" : "false", pending ? "true" : "false",
      (unsigned long)t.report.sequence, t.report.mode, t.report.pattern,
      t.report.strength, unsigned(t.report.reason));
  return String(out);
}
String motionJson(const motion::Report &m) {
  char out[1200];
  snprintf(out, sizeof(out),
           "{\"sequence\":%lu,\"mode\":%u,\"pattern\":%u,\"strength\":%u,"
           "\"durationUs\":%llu,\"ticks\":%lu,"
           "\"minDtUs\":%"
           "lu,\"maxDtUs\":%lu,\"meanDtUs\":%.3f,\"lateTicks\":%lu,"
           "\"missedSlots\":%lu,\"busy\":%lu,"
           "\"rejected\":%lu,\"drops\":%lu,\"queued\":%lu,\"queuedX\":%lld,"
           "\"queuedY\":%lld,"
           "\"maxQueueGapUs\":%lu,\"droppedCatchupX\":%.5f,\"droppedCatchupY\":"
           "%.5f,\"reason\":%u,"
           "\"startPhase\":%.5f,\"endPhase\":%.5f,"
           "\"histogram\":[%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu]",
           (unsigned long)m.sequence, m.mode, m.pattern, m.strength,
           (unsigned long long)m.durationUs, (unsigned long)m.ticks,
           (unsigned long)(m.ticks ? m.minDtUs : 0), (unsigned long)m.maxDtUs,
           m.ticks ? double(m.dtSumUs) / m.ticks : 0.0,
           (unsigned long)m.lateTicks, (unsigned long)m.missedSlots,
           (unsigned long)m.busy, (unsigned long)m.rejected,
           (unsigned long)m.drops, (unsigned long)m.queued,
           (long long)m.queuedX, (long long)m.queuedY,
           (unsigned long)m.maxQueueGapUs, double(m.droppedCatchupX),
           double(m.droppedCatchupY), unsigned(m.reason), double(m.startPhase),
           double(m.endPhase), (unsigned long)m.histogram[0],
           (unsigned long)m.histogram[1], (unsigned long)m.histogram[2],
           (unsigned long)m.histogram[3], (unsigned long)m.histogram[4],
           (unsigned long)m.histogram[5], (unsigned long)m.histogram[6],
           (unsigned long)m.histogram[7], (unsigned long)m.histogram[8]);
  return String(out) + ",\"compute\":" + computeJson(m.compute) + "}";
}
void stateReply(AsyncWebServerRequest *r, const Draft &s) {
  char meta[700];
  snprintf(meta, sizeof(meta),
           "{\"version\":\"4.2.0\",\"schema\":3,\"phase\":\"%s\",\"revision\":%"
           "lu,\"savedRevision\":%lu,"
           "\"storageError\":%s,\"errorCode\":\"%s\",\"recovered\":%s,"
           "\"migrated\":%s,\"generation\":%lu,"
           "\"workingMode\":%d,\"lastBootError\":\"%s\",\"token\":\"%s\","
           "\"config\":",
           phaseName(), (unsigned long)s.revision,
           (unsigned long)s.savedRevision,
           (s.storageError || s.baseStorageError) ? "true" : "false",
           s.baseStorageError ? "nvs_fn_mode"
           : s.storageError   ? tuning::storeErrorName(s.storeError)
                              : systemError.load(std::memory_order_acquire),
           s.recovered ? "true" : "false", s.migrated ? "true" : "false",
           (unsigned long)s.generation, s.workingMode, lastBootError, token);
  reply(r, 200,
        String(meta) + tuning::configJson(s.config) + ",\"lastHold\":" +
            motionJson(motionSnapshot()) + ",\"trace\":" + traceJson() + "}");
}
bool revisionParam(AsyncWebServerRequest *r, int &revision) {
  const auto *p = r->getParam("revision", true);
  return p && tuning::parseInt(p->value().c_str(), 0, 1000000000, revision);
}
void acceptConfig(AsyncWebServerRequest *r, const tuning::Config &c,
                  int revision) {
  const uint32_t now = millis();
  int error = 0;
  Draft accepted;
  portENTER_CRITICAL(&mux);
  if (!draft.accepting)
    error = 503;
  else if (draft.revision != uint32_t(revision))
    error = 409;
  else if (!tuning::equal(c, draft.config)) {
    if (draft.revision >= 1000000000u)
      error = 409;
    else {
      draft.config = c;
      ++draft.revision;
      draft.changedAt = now;
    }
  }
  accepted = draft;
  portEXIT_CRITICAL(&mux);
  if (error) {
    reply(r, error,
          error == 409
              ? "{\"error\":\"Конфликт версии; перечитайте настройки\"}"
              : "{\"error\":\"Режим настройки завершается\"}");
    return;
  }
  stateReply(r, accepted);
}
void update(AsyncWebServerRequest *r) {
  if (!allowed(r, true))
    return;
  int revision;
  const auto *document = r->getParam("document", true);
  tuning::Config staged;
  if (r->contentLength() > 8192 || r->params() != 2 ||
      !revisionParam(r, revision) || !document ||
      !tuning::parseDocument(document->value(), staged)) {
    reply(r, 400,
          "{\"error\":\"Некорректный JSON, версия или диапазон настройки\"}");
    return;
  }
  acceptConfig(r, staged, revision);
}
void resetConfig(AsyncWebServerRequest *r) {
  if (!allowed(r, true))
    return;
  int revision;
  if (r->contentLength() > 64 || r->params() != 1 ||
      !revisionParam(r, revision)) {
    reply(r, 400, "{\"error\":\"Некорректная редакция\"}");
    return;
  }
  acceptConfig(r, tuning::Config{}, revision);
}
void diagnostics(AsyncWebServerRequest *r) {
  if (!allowed(r))
    return;
  const auto m = motionSnapshot();
  char text[1800];
  snprintf(text, sizeof(text),
           "metric,value,unit\nsequence,%lu,id\nmode,%u,index\npattern,%u,"
           "index\nstrength,%u,"
           "step\nduration,%llu,us\nticks,%"
           "lu,count\nmin_dt,%lu,us\nmax_dt,%lu,us\nmean_dt,%.3f,us\nlate_"
           "ticks,%lu,count\nmissed_slots,%"
           "lu,count\nbusy,%lu,count\nrejected,%lu,count\ndrops,%lu,"
           "count\nqueued,%lu,count\nqueued_x,%lld,"
           "HID_counts\nqueued_y,%lld,HID_counts\nmax_queue_gap,%lu,"
           "us\ndropped_catchup_x,%.5f,HID_"
           "counts\ndropped_catchup_y,%.5f,HID_counts\nend_reason,%u,index\n",
           (unsigned long)m.sequence, m.mode, m.pattern, m.strength,
           (unsigned long long)m.durationUs, (unsigned long)m.ticks,
           (unsigned long)(m.ticks ? m.minDtUs : 0), (unsigned long)m.maxDtUs,
           m.ticks ? double(m.dtSumUs) / m.ticks : 0.0,
           (unsigned long)m.lateTicks, (unsigned long)m.missedSlots,
           (unsigned long)m.busy, (unsigned long)m.rejected,
           (unsigned long)m.drops, (unsigned long)m.queued,
           (long long)m.queuedX, (long long)m.queuedY,
           (unsigned long)m.maxQueueGapUs, double(m.droppedCatchupX),
           double(m.droppedCatchupY), unsigned(m.reason));
  String csv(text);
  const char *bins[] = {"dt_lt_900",    "dt_900_949",   "dt_950_999",
                        "dt_1000_1049", "dt_1050_1099", "dt_1100_1249",
                        "dt_1250_1999", "dt_2000_4999", "dt_ge_5000"};
  for (unsigned i = 0; i < 9; ++i) {
    snprintf(text, sizeof(text), "%s,%lu,count\n", bins[i],
             (unsigned long)m.histogram[i]);
    csv += text;
  }
  const auto &c = m.compute;
  const double mhz = c.cpuMHz ? c.cpuMHz : 1;
  snprintf(
      text, sizeof(text),
      "compute_samples,%lu,count\ncpu_frequency,%lu,MHz\ncompute_min,%.3f,us\n"
      "compute_mean,%.3f,us\ncompute_max,%.3f,us\nminimum_slack,%.3f,us\n"
      "compute_over_budget,%lu,count\n",
      (unsigned long)c.samples, (unsigned long)c.cpuMHz,
      c.samples ? double(c.minCycles) / mhz : 0.0,
      c.samples ? double(c.sumCycles) / c.samples / mhz : 0.0,
      double(c.maxCycles) / mhz,
      c.samples ? double(c.minSlackCycles) / mhz : 0.0,
      (unsigned long)c.overBudget);
  csv += text;
  reply(r, 200, csv, "text/csv; charset=utf-8", "RecoilEngine-last-hold.csv");
}
bool traceReadAllowed(AsyncWebServerRequest *r) {
  if (!allowed(r))
    return false;
  if (phase() != Phase::TUNING ||
      !pauseGranted.load(std::memory_order_acquire)) {
    reply(r, 503, "{\"error\":\"Движок не остановлен\"}");
    return false;
  }
  return true;
}
void armTrace(AsyncWebServerRequest *r, bool enabled) {
  if (!allowed(r, true) || !traceReadAllowed(r))
    return;
  if (r->contentLength() || r->params()) {
    reply(r, 400, "{\"error\":\"Запрос не должен содержать параметры\"}");
    return;
  }
  bool accepted;
  portENTER_CRITICAL(&mux);
  accepted = draft.accepting;
  if (accepted)
    traceCookie = enabled ? TRACE_MAGIC : 0;
  portEXIT_CRITICAL(&mux);
  if (!accepted) {
    reply(r, 503, "{\"error\":\"Выполняется выход\"}");
    return;
  }
  stateReply(r, snapshot());
}
void traceInfo(AsyncWebServerRequest *r) {
  if (!traceReadAllowed(r))
    return;
  reply(r, 200,
        String("{\"trace\":") + traceJson() +
            ",\"record\":" + motionJson(capturedTrace.report) +
            ",\"config\":" + tuning::configJson(capturedTrace.config) + "}");
}
void traceCsv(AsyncWebServerRequest *r) {
  if (!traceReadAllowed(r))
    return;
  if (!capturedTrace.finished) {
    reply(r, 409, "{\"error\":\"Завершённой записи пока нет\"}");
    return;
  }
  // No full-file String or JSON allocation: stream directly from frozen RAM.
  auto *response = r->beginResponse(
      "text/csv; charset=utf-8", motion::traceCsvSize(capturedTrace),
      [](uint8_t *buffer, size_t maxLen, size_t index) {
        return motion::traceCsvRead(capturedTrace, buffer, maxLen, index);
      });
  headers(response);
  response->addHeader("Content-Disposition",
                      "attachment; filename=\"RecoilEngine-trace.csv\"");
  r->send(response);
}
void preview(AsyncWebServerRequest *r) {
  if (!allowed(r))
    return;
  if (phase() != Phase::TUNING ||
      !pauseGranted.load(std::memory_order_acquire)) {
    reply(r, 503, "{\"error\":\"Движок не остановлен\"}");
    return;
  }
  const auto *mode = r->getParam("mode");
  const auto *pattern = r->getParam("pattern");
  int index = 0;
  if (!mode || (mode->value() != "close" && mode->value() != "long") ||
      (pattern && !tuning::parseInt(pattern->value().c_str(), 0, 79, index))) {
    reply(r, 400, "{\"error\":\"Некорректный режим или паттерн\"}");
    return;
  }
  std::unique_ptr<Preview> data(new (std::nothrow) Preview);
  if (!data) {
    reply(r, 503, "{\"error\":\"Недостаточно памяти\"}");
    return;
  }
  const Draft s = snapshot();
  buildPreview(mode->value() == "long", index, s.config, *data);
  auto *response = r->beginResponseStream("application/json; charset=utf-8");
  headers(response);
  response->printf("{\"revision\":%lu,\"points\":[", (unsigned long)s.revision);
  for (unsigned i = 0; i < Preview::COUNT; ++i) {
    const auto &p = data->points[i];
    response->printf("%s[%.4f,%.4f,%.4f,%.4f]", i ? "," : "", double(p.beforeX),
                     double(p.beforeY), double(p.afterX), double(p.afterY));
  }
  response->print("]}");
  r->send(response);
}
bool startAP() {
  WiFi.persistent(false);
  const IPAddress ip(192, 168, 4, 1), mask(255, 255, 255, 0);
  if (!WiFi.mode(WIFI_AP) || !WiFi.softAPConfig(ip, ip, mask) ||
      !WiFi.softAP(ENGINEERING_AP_SSID, ENGINEERING_AP_PASSWORD, 1, false, 2)) {
    systemError = "ap_start";
    return false;
  }
  for (unsigned i = 0; i < 4; ++i)
    snprintf(token + i * 8, 9, "%08lx", (unsigned long)esp_random());
  server = new (std::nothrow) CheckedServer();
  if (!server) {
    systemError = "server_memory";
    return false;
  }
  server->on("/", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (!allowed(r))
      return;
    auto *response =
        r->beginResponse(200, "text/html; charset=utf-8",
                         reinterpret_cast<const uint8_t *>(ENGINEERING_HTML),
                         sizeof(ENGINEERING_HTML) - 1);
    headers(response);
    r->send(response);
  });
  server->on("/api/config", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (allowed(r))
      stateReply(r, snapshot());
  });
  server->on("/update", HTTP_POST, update);
  server->on("/import", HTTP_POST, update);
  server->on("/reset", HTTP_POST, resetConfig);
  server->on("/export", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (allowed(r))
      reply(r, 200, tuning::documentJson(snapshot().config),
            "application/json; charset=utf-8", "RecoilEngine-R4.1.0.json");
  });
  server->on("/diagnostics.csv", HTTP_GET, diagnostics);
  server->on("/preview", HTTP_GET, preview);
  server->on("/trace", HTTP_GET, traceInfo);
  server->on("/trace.csv", HTTP_GET, traceCsv);
  server->on("/trace/arm", HTTP_POST,
             [](AsyncWebServerRequest *r) { armTrace(r, true); });
  server->on("/trace/disarm", HTTP_POST,
             [](AsyncWebServerRequest *r) { armTrace(r, false); });
  server->onNotFound([](AsyncWebServerRequest *r) {
    reply(r, 404, "{\"error\":\"Не найдено\"}");
  });
  server->begin();
  if (!server->listening()) {
    systemError = "http_listen";
    return false;
  }
  return true;
}
bool saveDraft(const Draft &s) {
  const bool ok = calibrationStore.save(s.config);
  portENTER_CRITICAL(&mux);
  draft.storageError = !ok;
  draft.storeError = calibrationStore.error;
  draft.recovered = calibrationStore.recovered;
  draft.migrated = calibrationStore.migrated;
  draft.generation = calibrationStore.savedGeneration();
  if (ok)
    draft.savedRevision = s.revision;
  portEXIT_CRITICAL(&mux);
  return ok;
}
void fault() {
  const char *why = systemError.load(std::memory_order_acquire);
  for (unsigned i = 1; i < sizeof(faultNames) / sizeof(faultNames[0]); ++i) {
    if (!strcmp(why, faultNames[i]))
      faultCookie = FAULT_MAGIC | i;
  }
  portENTER_CRITICAL(&mux);
  draft.accepting = false;
  portEXIT_CRITICAL(&mux);
  current.store(Phase::FAULT, std::memory_order_release);
  if (server)
    server->end();
  (void)radioOff();
}
void requestExit() {
  portENTER_CRITICAL(&mux);
  draft.accepting = false;
  portEXIT_CRITICAL(&mux);
  current.store(Phase::SAVING_EXIT, std::memory_order_release);
  attemptedSave = false;
}
} // namespace

bool begin() {
  const bool armed =
      esp_reset_reason() == ESP_RST_SW && traceCookie == TRACE_MAGIC;
  traceCookie = 0; // consume once; a future exit cannot silently re-arm capture
  capturedTrace.arm(armed);
  const uint32_t cookie = resumeCookie;
  resumeCookie = 0;
  const uint32_t previousFault = faultCookie;
  faultCookie = 0;
  if (esp_reset_reason() == ESP_RST_SW &&
      (previousFault & 0xffffff00u) == FAULT_MAGIC &&
      (previousFault & 0xffu) < sizeof(faultNames) / sizeof(faultNames[0]))
    lastBootError = faultNames[previousFault & 0xffu];
  if (esp_reset_reason() == ESP_RST_SW && (cookie & ~1u) == RESUME_MAGIC)
    enabledAtBoot = (cookie & 1u) != 0;
  if (!radioOff())
    return false;
  runtime = calibrationStore.load();
  draft.config = runtime;
  draft.storageError = calibrationStore.error != tuning::StoreError::NONE;
  draft.storeError = calibrationStore.error;
  draft.recovered = calibrationStore.recovered;
  draft.migrated = calibrationStore.migrated;
  draft.generation = calibrationStore.savedGeneration();
  return true;
}
int adoptLegacyStrength(int fallback) {
  if (!calibrationStore.loaded)
    runtime.strength = draft.config.strength =
        uint16_t(fallback < 0     ? 0
                 : fallback > 150 ? 150
                                  : fallback);
  return runtime.strength;
}
bool bootEnabled() { return enabledAtBoot; }
const tuning::Profile &runtimeProfile(bool longMode) {
  return runtime.profiles[longMode ? 1 : 0];
}
const tuning::Config &runtimeConfig() { return runtime; }
motion::TraceCapture &traceCapture() { return capturedTrace; }
void publishMotion(const motion::Report &report) {
  portENTER_CRITICAL(&mux);
  lastMotion = report;
  portEXIT_CRITICAL(&mux);
}
Phase phase() { return current.load(std::memory_order_acquire); }
bool active() { return phase() != Phase::PLAY; }
bool storageFault() {
  const auto s = snapshot();
  return s.storageError || s.baseStorageError;
}
void buttonPressed(uint32_t now, bool enabled) {
  if (phase() == Phase::PLAY) {
    enabledBeforeTuning = enabled;
    phaseAt = now;
    current.store(Phase::WAIT_PAUSE, std::memory_order_release);
    pauseRequested.store(true, std::memory_order_release);
  } else if (phase() == Phase::TUNING)
    requestExit();
  else if (phase() == Phase::FAULT) {
    resumeCookie = RESUME_MAGIC | (enabledBeforeTuning ? 1u : 0u);
    ESP.restart();
  }
}
void service(uint32_t now, bool baseSettingsSaved, int workingMode) {
  const Phase state = phase();
  if (state == Phase::PLAY || state == Phase::FAULT)
    return;
  if (state == Phase::WAIT_PAUSE) {
    if (pauseGranted.load(std::memory_order_acquire)) {
      portENTER_CRITICAL(&mux);
      draft.baseStorageError = !baseSettingsSaved;
      draft.workingMode = workingMode;
      portEXIT_CRITICAL(&mux);
      if (!baseSettingsSaved)
        return;
      current.store(Phase::TUNING, std::memory_order_release);
      portENTER_CRITICAL(&mux);
      draft.accepting = true;
      portEXIT_CRITICAL(&mux);
      noClients = true;
      noClientsSince = now;
      if (!startAP())
        fault();
    } else if (uint32_t(now - phaseAt) >= 2000) {
      systemError = "pause_timeout";
      fault();
    }
    return;
  }
  if (state == Phase::STOPPING) {
    if (uint32_t(now - phaseAt) >= 200) {
      resumeCookie = RESUME_MAGIC | (enabledBeforeTuning ? 1u : 0u);
      ESP.restart();
    }
    return;
  }
  if (!pauseGranted.load(std::memory_order_acquire)) {
    systemError = "pause_lost";
    fault();
    return;
  }
  portENTER_CRITICAL(&mux);
  draft.baseStorageError = !baseSettingsSaved;
  draft.workingMode = workingMode;
  portEXIT_CRITICAL(&mux);
  Draft s = snapshot();
  if (state == Phase::TUNING) {
    if (WiFi.softAPgetStationNum()) {
      noClients = false;
    } else {
      if (!noClients) {
        noClients = true;
        noClientsSince = now;
      }
      if (s.config.idleTimeoutSec &&
          uint32_t(now - noClientsSince) >=
              uint32_t(s.config.idleTimeoutSec) * 1000u) {
        requestExit();
        return;
      }
    }
  }
  const bool due = !attemptedSave || uint32_t(now - lastSaveAttempt) >= 2000;
  if (s.revision != s.savedRevision && due &&
      (state == Phase::SAVING_EXIT || uint32_t(now - s.changedAt) >= 600)) {
    attemptedSave = true;
    lastSaveAttempt = now;
    (void)saveDraft(s);
    s = snapshot();
  }
  if (state == Phase::SAVING_EXIT && s.revision == s.savedRevision &&
      baseSettingsSaved) {
    if (server)
      server->end();
    calibrationStore.close();
    (void)radioOff();
    current.store(Phase::STOPPING, std::memory_order_release);
    phaseAt = now;
  }
}
} // namespace engineering
