#pragma once
#include <limits.h>
#include <stdint.h>
#include "ComputeTiming.h"
namespace motion {
enum class EndReason : uint8_t { RELEASE, ENGINEERING, USB_LOSS, SWITCHED_OFF };
struct Report {
    ComputeTiming compute;
    uint32_t sequence = 0;
    uint64_t startUs = 0, durationUs = 0, dtSumUs = 0;
    uint32_t ticks = 0, minDtUs = UINT32_MAX, maxDtUs = 0, lateTicks = 0, missedSlots = 0;
    uint32_t busy = 0, rejected = 0, drops = 0, queued = 0, maxQueueGapUs = 0;
    uint32_t histogram[9] = {};
    int64_t queuedX = 0, queuedY = 0;
    float droppedCatchupX = 0, droppedCatchupY = 0;
    float startPhase = 0, endPhase = 0;
    uint16_t strength = 0;
    uint8_t mode = 0, pattern = 0;
    EndReason reason = EndReason::RELEASE;
};
struct Recorder {
    Report report;
    uint64_t lastQueueUs = 0;
    void start(uint32_t seq, uint64_t at, uint8_t mode, uint16_t strength) {
        report = Report{};
        report.sequence = seq;
        report.startUs = at;
        report.mode = mode;
        report.strength = strength;
        lastQueueUs = 0;
    }
    void tick(uint64_t dt, uint32_t late, uint32_t missed) {
        const uint32_t d = dt > UINT32_MAX ? UINT32_MAX : uint32_t(dt);
        ++report.ticks;
        report.dtSumUs += d;
        if (d < report.minDtUs)
            report.minDtUs = d;
        if (d > report.maxDtUs)
            report.maxDtUs = d;
        if (late >= 50)
            ++report.lateTicks;
        report.missedSlots += missed;
        const uint32_t bounds[] = {900, 950, 1000, 1050, 1100, 1250, 2000, 5000};
        unsigned b = 0;
        while (b < 8 && d >= bounds[b])
            ++b;
        ++report.histogram[b];
    }
    void queued(int16_t x, int16_t y, uint64_t at) {
        ++report.queued;
        report.queuedX += x;
        report.queuedY += y;
        if (lastQueueUs) {
            const uint64_t d = at - lastQueueUs;
            const uint32_t gap = d > UINT32_MAX ? UINT32_MAX : uint32_t(d);
            if (gap > report.maxQueueGapUs)
                report.maxQueueGapUs = gap;
        }
        lastQueueUs = at;
    }
    Report finish(uint64_t at, EndReason why) {
        report.durationUs = at - report.startUs;
        report.reason = why;
        if (!report.ticks)
            report.minDtUs = 0;
        return report;
    }
};
} // namespace motion
