// ESP32-S3 HID Recoil Engine — R4.2.0 cached math, cycle timing and bounded one-shot trace.
// Банки траекторий и HID REPORT сохранены; сила и калибровка вынесены в веб.
// НЕ проверено в физической сборке: сначала испытания на отключенном от игры стенде.
// Примечание: USB VID/PID/строки ниже сохранены как в исходнике; используйте свои
// выделенные идентификаторы при выпуске собственного оборудования.

#include <Arduino.h>
#include "USB.h"
#include "USBHID.h"
#include "tusb.h"  // Native TinyUSB queue API: avoids the 100 ms blocking SendReport() wrapper
#include <Preferences.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_random.h"
#include "esp_rom_sys.h"
#include "esp_task_wdt.h"
#include "esp_attr.h"
#include <atomic>
#include <cmath>
#include <stdint.h>
#include "EngineSafety.h"
#include "EngineeringMode.h"
#include "TickMathCache.h"
#include "TickTimer.h"

#if !defined(CONFIG_IDF_TARGET_ESP32S3) || ARDUINO_USB_MODE != 0
#error "Requires ESP32-S3 native USB OTG (USB Mode: USB-OTG / TinyUSB)"
#endif
#if CONFIG_FREERTOS_UNICORE
#error "This firmware requires both ESP32-S3 cores"
#endif

// R3.2: selected deep optimizations with switchable math changes.
// R3.1 remains the calibration reference. Hardware validation required.
// --- АППАРАТНЫЕ ПИНЫ (Все замыкаются на GND) ---
#define TRIGGER_PIN        5   // Сигнал с микрика ЛКМ (Детектор удержания, без отправки клика)
#define FN_BUTTON_PIN      6   // Кнопка функций: Двойной клик (ON/OFF), Зажатие (Вариация 1/2)
#define RGB_LED_PIN        48  // Встроенный RGB светодиод WS2812
static_assert(ENGINEERING_BUTTON_PIN != TRIGGER_PIN && ENGINEERING_BUTTON_PIN != FN_BUTTON_PIN &&
              ENGINEERING_BUTTON_PIN != RGB_LED_PIN && ENGINEERING_BUTTON_PIN != 19 && ENGINEERING_BUTTON_PIN != 20,
              "Engineering button must use a free GPIO, not native USB D-/D+");

// ================= ЕДИНЫЙ БЛОК ТОНКОЙ КАЛИБРОВКИ =================
// 1. Разделение Тап / Зажим:
#define TAP_WINDOW_US            50000ULL // Длительность окна одиночного клика (40000..65000 мкс)
#define TAP_CURVE_POWER          3        // Крутизна подавления тапа: 2 (квадрат), 3 (куб), 4 (жесткий отсев)
#define TAP_AUTO_CATCHUP         1        // 1 = Авто-компенсация потери высоты на 2-й половине 1-й пули, 0 = Выкл
#define TAP_SPRINGBACK_ENABLE    1        // 1 = Возвращать курсор назад, если кнопка отпущена во время тапа
#define TAP_SPRINGBACK_TIME_US  15000ULL // Плавный возврат за 15 мс, без ожидания
#define COOLDOWN_STEP_MS        45ULL    // Исходный темп восстановления: один шаг за 45 мс
#define HID_BUSY_DROP_US        25000ULL // Не отдавать накопленную историю после долгой USB-паузы

// Ревизия R2: надёжность без изменения математической модели.
#define ENGINE_DIAGNOSTICS       1        // 1 = статистика в RAM (без печати в Core 1)
#define ENGINE_LATE_THRESHOLD_US 50ULL    // Считать существенным опоздание >= 50 мкс
#define ENGINE_DIAG_UART         0        // 1 = печать из Core 0 через UART0, НЕ USB CDC
#define ENGINE_TASK_WDT         1        // 1 = попытка подписки EngineTask на уже запущенный TWDT
#define CONTROL_DEBOUNCE_MS     25UL     // FN and engineering button: stable state for 25 ms
#define FN_HOLD_MS             600UL    // FN long hold: CLOSE / LONG
#define FN_MIN_CLICK_MS        30UL     // Shorter FN taps are not commands
#define FN_DOUBLE_WINDOW_MS   250UL    // Double FN: ON / OFF
// Для эксперимента можно отключить Spring-Back на warm-start (1 сохраняет поведение R1).
#define SPRINGBACK_ON_WARM_TAP  1

// R3.2 options: disable any independent experiment to compare with R3.1.
#ifndef R32_SPLINE_CACHE
#define R32_SPLINE_CACHE          1   // polynomial coefficients once per segment
#endif
#ifndef R32_ABSOLUTE_SCHEDULER
#define R32_ABSOLUTE_SCHEDULER    1   // anchored deadlines; timer wake + short spin tail
#endif
#ifndef R32_TIME_NORMALIZATION
#define R32_TIME_NORMALIZATION   1   // time-scaled EMA/drift/mirror/micro noise
#endif
#ifndef R32_WRAP_TANGENT_FIX
#define R32_WRAP_TANGENT_FIX     1   // in sustain loop, preceding node of 18 = 29
#endif
#ifndef R32_DETERMINISTIC_RNG
#define R32_DETERMINISTIC_RNG     0   // 1 for isolated bench replay ONLY, not normal usage
#endif
#ifndef R32_RNG_TEST_SEED
#define R32_RNG_TEST_SEED        0xC001CAFEu
#endif
#ifndef R32_USB_COMPLETION_HOOK
#define R32_USB_COMPLETION_HOOK  0   // 1 ONLY with an external Arduino-core hook adapter
#endif
#ifndef R32_AVOID_CONSECUTIVE_PATTERN
#define R32_AVOID_CONSECUTIVE_PATTERN 1 // new cold start differs from previous cold pattern
#endif

// 2. Инерция остывания отдачи при быстрых прокликах (Burst Cooldown):
#define SPRAY_COOLDOWN_MS        320      // Время полного остывания прицела после очереди (мс)

// 3. Баланс геометрии ("Подкид - Основа - Хвост"):
#define PATTERN_COMPRESSION      0.38f    // 0.25f = почти прямая, 0.38f = баланс, 1.0f = оригинал

// --- ТАЙМИНГИ И ЧАСТОТА ДВИЖКА ---
#define SHOTS_PER_SPRAY          30
#define LOOP_START_SHOT          18
static_assert(LOOP_START_SHOT == tuning::TAIL_FIRST, "Tuning tail must match sustain loop");
#define NUM_PATTERNS             80
#define BASE_SHOT_INTERVAL_US    100000ULL // Базовый интервал сегмента: 100 мс
#define INTERVAL_JITTER_US       6000.0f   // Девиация интервала сегмента: +-6 мс

#define BASE_TICK_US             1000ULL   // Базовый период опроса USB HID: 1000 мкс (1000 Гц)
#define USB_POLL_JITTER_US       0.0f      // R4: fixed nominal 1 ms calculation deadlines

#define DEBOUNCE_TRIGGER_US      3000ULL   // Симметричный антидребезг входа триггера: 3 мс

// --- СКАЛЯРЫ БАЛЛИСТИКИ ---
#define BASE_PIXEL_SCALE_X       1.20f 
#define BASE_PIXEL_SCALE_Y       1.68f 

#define CORE_ANCHOR_CLOSE_Y      4.20f 
#define CORE_ANCHOR_LONG_Y       4.85f 

static_assert((BASE_SHOT_INTERVAL_US - (uint64_t)INTERVAL_JITTER_US) > TAP_WINDOW_US,
              "TAP_WINDOW_US must be shorter than the shortest shot interval");
static_assert(TAP_SPRINGBACK_TIME_US > 0, "Spring-back duration must be >0");
static_assert(LOOP_START_SHOT > 0 && LOOP_START_SHOT < SHOTS_PER_SPRAY, "Invalid sustain loop");
static_assert(BASE_TICK_US == 1000ULL, "R3.2 normalization table is calibrated for 1ms nominal ticks");
static_assert(ENGINE_DIAG_UART == 0 || ENGINE_DIAGNOSTICS == 1,
              "ENGINE_DIAG_UART needs ENGINE_DIAGNOSTICS");
static_assert(TAP_CURVE_POWER == 2 || TAP_CURVE_POWER == 3 || TAP_CURVE_POWER == 4,
              "TAP_CURVE_POWER must be 2, 3, or 4");

// --- КАЛИБРОВКА ТРЕМОРА И УСТАЛОСТИ ---
#define JITTER_MICRO_AMP_PX      0.10f 
#define JITTER_DRIFT_AMP_PX      0.08f 
#define JITTER_DRIFT_ALPHA       0.06f 
#define EMA_SMOOTH_ALPHA         0.30f
static_assert(EMA_SMOOTH_ALPHA > 0.0f && EMA_SMOOTH_ALPHA <= 1.0f,
              "EMA alpha must be in (0,1]"); 

#define FATIGUE_FRESH_MULT       0.60f 
#define FATIGUE_MAX_MULT         1.40f 


// ================= 16-БИТНЫЙ ДЕСКРИПТОР И КЛАСС HID =================
#define REPORT_ID_MOUSE 1

static const uint8_t report_descriptor[] = {
    0x05, 0x01,                    // Usage Page (Generic Desktop Ctrls)
    0x09, 0x02,                    // Usage (Mouse)
    0xA1, 0x01,                    // Collection (Application)
    0x85, REPORT_ID_MOUSE,         //   Report ID (1)
    0x09, 0x01,                    //   Usage (Pointer)
    0xA1, 0x00,                    //   Collection (Physical)
    0x05, 0x09,                    //     Usage Page (Button)
    0x19, 0x01,                    //     Usage Minimum (0x01)
    0x29, 0x05,                    //     Usage Maximum (0x05)
    0x15, 0x00,                    //     Logical Minimum (0)
    0x25, 0x01,                    //     Logical Maximum (1)
    0x95, 0x05,                    //     Report Count (5)
    0x75, 0x01,                    //     Report Size (1)
    0x81, 0x02,                    //     Input (Data,Var,Abs)
    0x95, 0x01,                    //     Report Count (1)
    0x75, 0x03,                    //     Report Size (3)
    0x81, 0x03,                    //     Input (Const,Var,Abs)
    0x05, 0x01,                    //     Usage Page (Generic Desktop Ctrls)
    0x09, 0x30,                    //     Usage (X)
    0x09, 0x31,                    //     Usage (Y)
    0x16, 0x01, 0x80,              //     Logical Minimum (-32767)
    0x26, 0xFF, 0x7F,              //     Logical Maximum (32767)
    0x75, 0x10,                    //     Report Size (16)
    0x95, 0x02,                    //     Report Count (2)
    0x81, 0x06,                    //     Input (Data,Var,Rel)
    0x09, 0x38,                    //     Usage (Wheel)
    0x15, 0x81,                    //     Logical Minimum (-127)
    0x25, 0x7F,                    //     Logical Maximum (127)
    0x75, 0x08,                    //     Report Size (8)
    0x95, 0x01,                    //     Report Count (1)
    0x81, 0x06,                    //     Input (Data,Var,Rel)
    0xC0,                          //   End Collection
    0xC0                           // End Collection
};

#pragma pack(push, 1)
struct MouseReport16 {
    uint8_t buttons;
    int16_t x;
    int16_t y;
    int8_t  wheel;
};
#pragma pack(pop)
static_assert(sizeof(MouseReport16) == 6, "HID report layout mismatch");

USBHID hid;

class CustomMouse16 : public USBHIDDevice {
public:
    CustomMouse16() {
        hid.addDevice(this, sizeof(report_descriptor));
    }

    void begin() {
        hid.begin();
    }

    uint16_t _onGetDescriptor(uint8_t* dst) override {
        memcpy(dst, report_descriptor, sizeof(report_descriptor));
        return sizeof(report_descriptor);
    }

    // Единственный отправитель HID — EngineTask. Передача не блокирует ядро ожиданием
    // завершения USB IN-пакета; true = отчет поставлен в TinyUSB, НЕ гарантия приема ОС.
    bool mounted() const {
        return tud_mounted();
    }
    bool ready() const {
        return tud_hid_n_ready(0);
    }
    bool sendMove(int16_t x, int16_t y) {
        if (!ready()) return false;
        MouseReport16 report = {0, x, y, 0};
        return tud_hid_n_report(0, REPORT_ID_MOUSE, &report, sizeof(report));
    }
};

CustomMouse16 Mouse16;

// ================= БАНКИ ТРАЕКТОРИЙ ВО ВНУТРЕННЕЙ SRAM (DRAM_ATTR) =================
#include "PatternBanks80.h"

// R3 table retained only to migrate the saved coarse profile to the new strength scale.
DRAM_ATTR const float MULTIPLIERS[15] = {
    0.00f, 0.21f, 0.43f, 0.64f, 0.86f,
    1.07f, 1.29f, 1.50f, 1.71f, 1.93f,
    2.14f, 2.36f, 2.57f, 2.79f, 3.00f
};


// Один 32-битный атомарный снимок: нет смешивания старого MODE и нового PROFILE.
// Только Core 0 записывает настройки (в setup() до старта задач и затем в ControlTask).
// Core 1 читает целое слово одним load(std::memory_order_relaxed).
// Bits 0..7: strength step 0..150; bit 8: mode; bit 9: enabled.
static constexpr uint32_t CFG_PROFILE_MASK = 0xFFu;
static constexpr uint32_t CFG_MODE_MASK = 0x100u;
static constexpr uint32_t CFG_ENABLED_MASK = 0x200u;
static_assert(ATOMIC_INT_LOCK_FREE == 2, "ESP32-S3 requires lock-free 32-bit atomics");


static inline uint32_t packControl(int strength, CombatMode mode, bool enabled) {
    strength = strength < 0 ? 0 : strength > tuning::STRENGTH_STEPS ? tuning::STRENGTH_STEPS : strength;
    return (uint32_t)strength |
           ((mode == MODE_LONG) ? CFG_MODE_MASK : 0u) |
           (enabled ? CFG_ENABLED_MASK : 0u);
}

struct AtomicAppState {
    std::atomic<uint32_t> packed{tuning::STRENGTH_STEPS | CFG_ENABLED_MASK};
};
DRAM_ATTR AtomicAppState g_atomicState;

static inline ControlSnapshot readControl() {
    const uint32_t word = g_atomicState.packed.load(std::memory_order_relaxed);
    return { (int)(word & CFG_PROFILE_MASK),
             ((word & CFG_MODE_MASK) != 0u) ? MODE_LONG : MODE_CLOSE,
             (word & CFG_ENABLED_MASK) != 0u };
}

// Управляющие операции только с Core 0: RMW не конкурирует с другими писателями.
static inline void setControlStrength(int strength) {
    strength = strength < 0 ? 0 : strength > tuning::STRENGTH_STEPS ? tuning::STRENGTH_STEPS : strength;
    const uint32_t old = g_atomicState.packed.load(std::memory_order_relaxed);
    const uint32_t next = (old & ~CFG_PROFILE_MASK) | (uint32_t)strength;
    g_atomicState.packed.store(next, std::memory_order_relaxed);
}
static inline void setControlMode(CombatMode mode) {
    const uint32_t old = g_atomicState.packed.load(std::memory_order_relaxed);
    const uint32_t next = (old & ~CFG_MODE_MASK) |
                          ((mode == MODE_LONG) ? CFG_MODE_MASK : 0u);
    g_atomicState.packed.store(next, std::memory_order_relaxed);
}
static inline void setControlEnabled(bool enabled) {
    const uint32_t old = g_atomicState.packed.load(std::memory_order_relaxed);
    const uint32_t next = (old & ~CFG_ENABLED_MASK) | (enabled ? CFG_ENABLED_MASK : 0u);
    g_atomicState.packed.store(next, std::memory_order_relaxed);
}

// Диагностика публикуется одним словом на метрику раз в ~1 секунду.
// Все счётчики собираются локально Core 1 без атомарных RMW в горячем цикле.
struct EngineDiagnosticCounters {
    std::atomic<uint32_t> ticks{0};
    std::atomic<uint32_t> minDtUs{0};
    std::atomic<uint32_t> maxDtUs{0};
    std::atomic<uint32_t> lateTicks{0};
    std::atomic<uint32_t> maxLatenessUs{0};
    std::atomic<uint32_t> hidQueued{0};
    std::atomic<uint32_t> hidBusy{0};
    std::atomic<uint32_t> hidRejected{0};
    std::atomic<uint32_t> hidDrops{0};
    std::atomic<uint32_t> hidUnmountedTicks{0};
    std::atomic<uint32_t> hidMaxBusyStreak{0};
    std::atomic<uint32_t> hidMaxPendingAgeUs{0};
    std::atomic<uint32_t> hidMaxPendingAbs{0};
    std::atomic<uint32_t> hidMaxQueuedAgeUs{0}; // interval between queued reports, NOT completion
    std::atomic<uint32_t> hidReadyAfterBusy{0}; // readiness recovery, NOT completion
    std::atomic<uint32_t> hidTransferCompleted{0}; // valid ONLY with optional Arduino-core hook
    std::atomic<uint32_t> hidTransferFailed{0};    // valid ONLY with optional Arduino-core hook
    std::atomic<uint32_t> schedulerMissedSlots{0};
    std::atomic<uint32_t> warmStarts{0};
    std::atomic<uint32_t> springStarts{0};
    std::atomic<uint32_t> watchdogActive{0};
};
DRAM_ATTR EngineDiagnosticCounters g_engineDiag;
// Consistent per-second diagnostic snapshot. All payload values are atomic;
// sequence marks an in-progress publication. Core 0 retries on concurrent write.
static std::atomic<uint32_t> g_r32DiagSequence{0};

static bool r32ReadDiagSnapshot(R32DiagSnapshot& s) {
    for (unsigned attempt=0; attempt<4; ++attempt) {
        const uint32_t seq0 = g_r32DiagSequence.load(std::memory_order_acquire);
        if (seq0 & 1u) continue;
        s.ticks=g_engineDiag.ticks.load(std::memory_order_relaxed);
        s.minDtUs=g_engineDiag.minDtUs.load(std::memory_order_relaxed);
        s.maxDtUs=g_engineDiag.maxDtUs.load(std::memory_order_relaxed);
        s.lateTicks=g_engineDiag.lateTicks.load(std::memory_order_relaxed);
        s.maxLatenessUs=g_engineDiag.maxLatenessUs.load(std::memory_order_relaxed);
        s.hidQueued=g_engineDiag.hidQueued.load(std::memory_order_relaxed);
        s.hidBusy=g_engineDiag.hidBusy.load(std::memory_order_relaxed);
        s.hidRejected=g_engineDiag.hidRejected.load(std::memory_order_relaxed);
        s.hidDrops=g_engineDiag.hidDrops.load(std::memory_order_relaxed);
        s.hidUnmountedTicks=g_engineDiag.hidUnmountedTicks.load(std::memory_order_relaxed);
        s.hidMaxBusyStreak=g_engineDiag.hidMaxBusyStreak.load(std::memory_order_relaxed);
        s.hidMaxPendingAgeUs=g_engineDiag.hidMaxPendingAgeUs.load(std::memory_order_relaxed);
        s.hidMaxPendingAbs=g_engineDiag.hidMaxPendingAbs.load(std::memory_order_relaxed);
        s.warmStarts=g_engineDiag.warmStarts.load(std::memory_order_relaxed);
        s.springStarts=g_engineDiag.springStarts.load(std::memory_order_relaxed);
        s.watchdogActive=g_engineDiag.watchdogActive.load(std::memory_order_relaxed);
        s.schedulerMissedSlots=g_engineDiag.schedulerMissedSlots.load(std::memory_order_relaxed);
        s.hidReadyAfterBusy=g_engineDiag.hidReadyAfterBusy.load(std::memory_order_relaxed);
        s.hidMaxQueuedAgeUs=g_engineDiag.hidMaxQueuedAgeUs.load(std::memory_order_relaxed);
        // callback hook (optional): cumulative, not part of the 1-second window
        s.hidTransferCompleted=g_engineDiag.hidTransferCompleted.load(std::memory_order_relaxed);
        s.hidTransferFailed=g_engineDiag.hidTransferFailed.load(std::memory_order_relaxed);
        std::atomic_thread_fence(std::memory_order_acquire);
        if (seq0 == g_r32DiagSequence.load(std::memory_order_acquire)) return true;
    }
    return false;
}

// The stock Arduino-ESP32 USBHID.cpp owns tud_hid_report_complete_cb() itself.
// Defining that callback here causes duplicate symbols. Optional core adapter is
// not supplied here; leave disabled unless installing a compatible core adapter.
#if R32_USB_COMPLETION_HOOK
extern "C" void recoil_hid_transfer_complete(uint8_t instance, uint8_t const* report, uint16_t len) {
    if (instance == 0 && report && len == sizeof(MouseReport16) + 1 && report[0] == REPORT_ID_MOUSE)
        g_engineDiag.hidTransferCompleted.fetch_add(1, std::memory_order_relaxed);
}
extern "C" void recoil_hid_transfer_failed(uint8_t instance) {
    if (instance == 0) g_engineDiag.hidTransferFailed.fetch_add(1, std::memory_order_relaxed);
}
#endif

// Engine emits the CURRENT indication state, not a lossy mailbox of past events.
// Core 0 alone owns WS2812 and chooses the highest-priority visible indication.
enum EngineLedState : uint8_t {
    ENGINE_LED_IDLE = 0,
    ENGINE_LED_CLOSE = 1,
    ENGINE_LED_LONG = 2
};
DRAM_ATTR std::atomic<uint8_t> g_engineLedState{ENGINE_LED_IDLE};
// The engine waits for both FreeRTOS tasks to exist before starting GPIO/HID work.
DRAM_ATTR std::atomic<bool> g_tasksReady{false};

TaskHandle_t engineTaskHandle  = NULL;
TaskHandle_t controlTaskHandle = NULL;
esp_timer_handle_t engineWakeTimer = nullptr;
std::atomic<bool> g_engineFault{false};
std::atomic<bool> g_flashSaveRequested{false};
std::atomic<bool> g_flashSaveGranted{false};

// Timer service runs on Core 0 in the pinned build; this callback never sends HID.
void engineWakeCallback(void*) {
    if (engineTaskHandle != nullptr) xTaskNotifyGive(engineTaskHandle);
}

// Only a short final tail is busy-waited. The engine blocks between ticks so
// Core 1 idle/system tasks remain schedulable and its idle watchdog stays enabled.
void waitForEngineDeadline(uint64_t deadlineUs) {
    uint64_t now = esp_timer_get_time();
    if (deadlineUs > now + 75ULL) {
        (void)ulTaskNotifyTake(pdTRUE, 0); // discard an obsolete wake notification
        const esp_err_t armed = esp_timer_start_once(engineWakeTimer, deadlineUs - now - 50ULL);
        if (armed != ESP_OK) {
            g_engineLedState.store(ENGINE_LED_IDLE, std::memory_order_relaxed);
            g_engineFault.store(true, std::memory_order_release);
            vTaskSuspend(nullptr); // fail closed; ControlTask displays the fault
            return;
        }
        (void)ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
    }
    while ((now = esp_timer_get_time()) < deadlineUs) {
        if (deadlineUs - now > 4ULL) esp_rom_delay_us(1);
    }
}

Preferences prefs;
bool settingsStoreReady = false;
bool settingsSaveFailed = false;
bool needSaveMode = false;
unsigned long saveSettingsTime = 0;

struct BlinkController {
    bool active;
    uint8_t count;
    uint8_t maxBlinks;
    uint8_t r, g, b;
    unsigned long nextToggle;
    bool stateOn;
} blinker = {false, 0, 0, 0, 0, 0, 0, false};

// ================= МАТЕМАТИЧЕСКОЕ ЯДРО =================

static inline float __attribute__((always_inline)) fastClampF(float val, float low, float high) {
    return (val < low) ? low : ((val > high) ? high : val);
}

static inline int __attribute__((always_inline)) fastClampI(int val, int low, int high) {
    return (val < low) ? low : ((val > high) ? high : val);
}

// Default: original ESP hardware RNG. Optional reproducible stream for host/bench tests.
// Single writer: all calls are from EngineTask, not ControlTask.
static inline uint32_t recoilRandomBits() {
#if R32_DETERMINISTIC_RNG
    static uint32_t state = R32_RNG_TEST_SEED;
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
#else
    return esp_random();
#endif
}

static inline int r32ChooseColdPattern(int lastPattern) {
#if R32_AVOID_CONSECUTIVE_PATTERN
    if (lastPattern >= 0 && lastPattern < NUM_PATTERNS) {
        const int candidate = (int)(recoilRandomBits() % (NUM_PATTERNS - 1));
        return candidate + (candidate >= lastPattern ? 1 : 0);
    }
#endif
    return (int)(recoilRandomBits() % NUM_PATTERNS);
}

static inline float __attribute__((always_inline)) randomCenteredFloat() {
    uint32_t rnd = recoilRandomBits() & 0x00FFFFFF;
    return ((float)rnd * (1.0f / 8388607.5f)) - 1.0f;
}

static inline uint64_t __attribute__((always_inline)) generateNextIntervalUs() {
    int32_t jitterUs = (int32_t)(randomCenteredFloat() * INTERVAL_JITTER_US);
    return (uint64_t)((int64_t)BASE_SHOT_INTERVAL_US + jitterUs);
}

static inline uint64_t __attribute__((always_inline)) generateNextTickDurationUs() {
    if (USB_POLL_JITTER_US == 0.0f) return BASE_TICK_US; // do not call RNG for disabled jitter
    int32_t pollJitterUs = (int32_t)(randomCenteredFloat() * USB_POLL_JITTER_US);
    return (uint64_t)((int64_t)BASE_TICK_US + pollJitterUs);
}

static inline float __attribute__((always_inline)) computeMuscleFatigueFactor(int currentShot, float t, bool inSustainLoop) {
    if (inSustainLoop) {
        return FATIGUE_MAX_MULT;
    }
    float pos = (float)currentShot + fastClampF(t, 0.0f, 1.0f);
    if (pos < 4.0f) {
        return FATIGUE_FRESH_MULT;
    }
    float progress = fastClampF((pos - 4.0f) * (1.0f / (float)(SHOTS_PER_SPRAY - 1 - 4)), 0.0f, 1.0f);
    return FATIGUE_FRESH_MULT + progress * (FATIGUE_MAX_MULT - FATIGUE_FRESH_MULT);
}

static inline int __attribute__((always_inline)) getCycleShotIndex(int baseShot, int offset) {
    int idx = baseShot + offset;
    if (idx < 0) {
        return 0;
    }
    if (idx >= SHOTS_PER_SPRAY) {
        int loopLen = SHOTS_PER_SPRAY - LOOP_START_SHOT;
        idx = LOOP_START_SHOT + ((idx - LOOP_START_SHOT) % loopLen);
    }
    return fastClampI(idx, 0, SHOTS_PER_SPRAY - 1);
}

static inline BulletTarget __attribute__((always_inline)) getBalancedNode(
        const BulletTarget (*bank)[SHOTS_PER_SPRAY],
        int patternIdx,
        int shotIdx,
        float coreAnchorY) {
    BulletTarget pt = bank[patternIdx][shotIdx];

    float rawY = pt.y;
    if (shotIdx == 0) {
        rawY = 0.5f * (pt.y + bank[patternIdx][1].y);
    }

    pt.y = coreAnchorY + (rawY - coreAnchorY) * PATTERN_COMPRESSION;
    return pt;
}

static inline BulletTarget __attribute__((always_inline)) evalCatmullRom(
        const BulletTarget& p0,
        const BulletTarget& p1,
        const BulletTarget& p2,
        const BulletTarget& p3,
        float t) {
    t = fastClampF(t, 0.0f, 1.0f);
    float t2 = t * t;
    float t3 = t2 * t;

    BulletTarget out;
    out.x = 0.5f * ((2.0f * p1.x) +
                    (-p0.x + p2.x) * t +
                    (2.0f * p0.x - 5.0f * p1.x + 4.0f * p2.x - p3.x) * t2 +
                    (-p0.x + 3.0f * p1.x - 3.0f * p2.x + p3.x) * t3);

    out.y = 0.5f * ((2.0f * p1.y) +
                    (-p0.y + p2.y) * t +
                    (2.0f * p0.y - 5.0f * p1.y + 4.0f * p2.y - p3.y) * t2 +
                    (-p0.y + 3.0f * p1.y - 3.0f * p2.y + p3.y) * t3);
    return out;
}


// C1-непрерывное распределение возвратного смещения по времени.

// -------- R3.2: time domain normalization --------
// At EXACTLY 1000 us all coefficients equal R3.1, including noise amplitude.
// OU drift: rho(dt)=(1-a)^(dt/1000); stationary variance kept by scaling innovation.
// This preserves drift-state variance/correlation, NOT exact bitwise HID output.
static constexpr uint32_t R32_DT_TABLE_MIN_US = 750;
static constexpr uint32_t R32_DT_TABLE_MAX_US = 1250;
static constexpr uint32_t R32_DT_TABLE_STEP_US = 25;
static constexpr size_t R32_DT_TABLE_LEN =
    (R32_DT_TABLE_MAX_US - R32_DT_TABLE_MIN_US) / R32_DT_TABLE_STEP_US + 1;
static R32TimeDynamics g_r32DynamicsTable[R32_DT_TABLE_LEN];

static inline R32TimeDynamics r32TimeDynamicsRaw(uint32_t dtUs) {
    const float ratio = (float)dtUs / (float)BASE_TICK_US;
    const float emaRho = powf(1.0f - EMA_SMOOTH_ALPHA, ratio);
    const float mirrorRho = powf(1.0f - 0.02f, ratio);
    const float driftRho = powf(1.0f - JITTER_DRIFT_ALPHA, ratio);
    const float stationaryVarFactor = JITTER_DRIFT_ALPHA / (2.0f - JITTER_DRIFT_ALPHA);
    R32TimeDynamics out;
    out.emaAlpha = 1.0f - emaRho;
    out.mirrorAlpha = 1.0f - mirrorRho;
    out.driftRho = driftRho;
    out.driftInnovation = sqrtf(fmaxf(0.0f, stationaryVarFactor * (1.0f - driftRho * driftRho)));
    out.microScale = sqrtf(ratio); // micro jitter is an increment per tick, scale like diffusion
    return out;
}

static void r32InitDynamics() {
#if R32_TIME_NORMALIZATION
    for (size_t i=0;i<R32_DT_TABLE_LEN;++i)
        g_r32DynamicsTable[i] = r32TimeDynamicsRaw(R32_DT_TABLE_MIN_US + (uint32_t)i * R32_DT_TABLE_STEP_US);
#endif
}

static inline R32TimeDynamics r32TimeDynamics(uint32_t dtUs) {
#if R32_TIME_NORMALIZATION
    if (dtUs == BASE_TICK_US) return {EMA_SMOOTH_ALPHA, 0.02f,
        1.0f - JITTER_DRIFT_ALPHA, JITTER_DRIFT_ALPHA, 1.0f};
    if (dtUs >= R32_DT_TABLE_MIN_US && dtUs <= R32_DT_TABLE_MAX_US) {
        const uint32_t offset = dtUs - R32_DT_TABLE_MIN_US;
        const uint32_t idx = offset / R32_DT_TABLE_STEP_US;
        const float weight = (float)(offset % R32_DT_TABLE_STEP_US) / (float)R32_DT_TABLE_STEP_US;
        if (idx >= R32_DT_TABLE_LEN - 1 || weight == 0.0f) return g_r32DynamicsTable[idx];
        const auto &a = g_r32DynamicsTable[idx], &b = g_r32DynamicsTable[idx+1];
        return { a.emaAlpha + (b.emaAlpha-a.emaAlpha)*weight,
                 a.mirrorAlpha + (b.mirrorAlpha-a.mirrorAlpha)*weight,
                 a.driftRho + (b.driftRho-a.driftRho)*weight,
                 a.driftInnovation + (b.driftInnovation-a.driftInnovation)*weight,
                 a.microScale + (b.microScale-a.microScale)*weight };
    }
    // Large timing interruptions are already capped at 5000us in the engine.
    return r32TimeDynamicsRaw(dtUs);
#else
    (void)dtUs;
    return {EMA_SMOOTH_ALPHA, 0.02f, 1.0f - JITTER_DRIFT_ALPHA, JITTER_DRIFT_ALPHA, 1.0f};
#endif
}

// -------- R3.2: Catmull-Rom polynomial cached per shot, no change to pattern data --------

static inline int r32NeighborIndex(int shot, int offset, bool sustain) {
#if R32_WRAP_TANGENT_FIX
    if (sustain && shot == LOOP_START_SHOT && offset == -1)
        return SHOTS_PER_SPRAY - 1;
#else
    (void)sustain;
#endif
    return getCycleShotIndex(shot, offset);
}

static inline void r32PrepareSpline(R32CachedSpline &cache, int shot, int pattern,
                                    CombatMode mode, bool sustain,
                                    const BulletTarget (*bank)[SHOTS_PER_SPRAY], float anchorY) {
    if (cache.shot==shot && cache.pattern==pattern && cache.mode==(int)mode && cache.sustain==sustain)
        return;
    const BulletTarget p0=getBalancedNode(bank,pattern,r32NeighborIndex(shot,-1,sustain),anchorY);
    const BulletTarget p1=getBalancedNode(bank,pattern,r32NeighborIndex(shot, 0,sustain),anchorY);
    const BulletTarget p2=getBalancedNode(bank,pattern,r32NeighborIndex(shot,+1,sustain),anchorY);
    const BulletTarget p3=getBalancedNode(bank,pattern,r32NeighborIndex(shot,+2,sustain),anchorY);
    cache.a = p1;
    cache.b = {0.5f*(-p0.x+p2.x), 0.5f*(-p0.y+p2.y)};
    cache.c = {0.5f*(2.0f*p0.x-5.0f*p1.x+4.0f*p2.x-p3.x),
               0.5f*(2.0f*p0.y-5.0f*p1.y+4.0f*p2.y-p3.y)};
    cache.d = {0.5f*(-p0.x+3.0f*p1.x-3.0f*p2.x+p3.x),
               0.5f*(-p0.y+3.0f*p1.y-3.0f*p2.y+p3.y)};
    cache.shot=shot; cache.pattern=pattern; cache.mode=(int)mode; cache.sustain=sustain;
}

static inline BulletTarget r32EvalSpline(const R32CachedSpline &c, float t) {
    t = fastClampF(t,0.0f,1.0f);
    // Horner polynomial, 3 multiplies per coordinate; tiny IEEE754 rounding differences.
    return {((c.d.x*t+c.c.x)*t+c.b.x)*t+c.a.x,
            ((c.d.y*t+c.c.y)*t+c.b.y)*t+c.a.y};
}

static inline float easeCubic(float t) {
    t = fastClampF(t, 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

// ================= УПРАВЛЕНИЕ LED И NVS (CORE 0) =================

// ============== LED arbitration (only Core 0 can write WS2812) ==============
// Priority: command confirmation blink > globally OFF > active engine >
// idle. Strength-change indication was removed in R4.
uint8_t ledLastR = 255, ledLastG = 255, ledLastB = 255;
void writeLedIfChanged(uint8_t r, uint8_t g, uint8_t b) {
    if (r == ledLastR && g == ledLastG && b == ledLastB) return;
    ledLastR = r; ledLastG = g; ledLastB = b;
    neopixelWrite(RGB_LED_PIN, r, g, b);
}

void startBlink(uint8_t r, uint8_t g, uint8_t b, uint8_t blinks) {
    blinker.active = true;
    blinker.r = r; blinker.g = g; blinker.b = b;
    blinker.maxBlinks = blinks;
    blinker.count = 0;
    blinker.stateOn = true;
    blinker.nextToggle = millis() + 90UL;
    writeLedIfChanged(r, g, b);
}

void updateBlinker(unsigned long now) {
    if (!blinker.active) return;
    if ((int32_t)(now - blinker.nextToggle) < 0) return;
    if (blinker.stateOn) {
        writeLedIfChanged(0, 0, 0);
        blinker.stateOn = false;
        blinker.count++;
        if (blinker.count >= blinker.maxBlinks) {
            blinker.active = false;
            // Return to current state; no stale shoot LED events survive here.
            return;
        }
    } else {
        writeLedIfChanged(blinker.r, blinker.g, blinker.b);
        blinker.stateOn = true;
    }
    blinker.nextToggle = now + 90UL;
}

void renderLed(unsigned long now) {
    const uint8_t engineState = g_engineLedState.load(std::memory_order_relaxed);
    if (engineering::active()) {
        const auto phase = engineering::phase();
        if (phase == engineering::Phase::FAULT) {
            writeLedIfChanged(((now / 150UL) & 1u) ? 80 : 0, 0, 0);
        } else if (engineering::storageFault()) {
            const bool on = ((now / 250UL) & 1u) != 0;
            writeLedIfChanged(on ? 60 : 0, on ? 20 : 0, 0);
        } else {
            const bool on = phase == engineering::Phase::TUNING || ((now / 250UL) & 1u);
            writeLedIfChanged(0, on ? 45 : 0, on ? 60 : 0);
        }
        return;
    }
    if (g_engineFault.load(std::memory_order_acquire)) {
        writeLedIfChanged(((now / 150UL) & 1u) ? 80 : 0, 0, 0);
        return;
    }
    // Highest priority: deliberate feedback for the physical FN command.
    if (blinker.active) return;
    if (settingsSaveFailed || engineering::storageFault()) {
        const bool on = ((now / 250UL) & 1u) != 0;
        writeLedIfChanged(on ? 60 : 0, on ? 20 : 0, 0);
    } else if (!readControl().enabled) {
        writeLedIfChanged(0, 0, 0);
    } else if (engineState == ENGINE_LED_CLOSE) {
        writeLedIfChanged(0, 0, 70);
    } else if (engineState == ENGINE_LED_LONG) {
        writeLedIfChanged(60, 0, 70);
    } else {
        writeLedIfChanged(0, 0, 0);
    }
}

// A stable-edge debouncer shared by FN and engineering mode. Only an actual stable
// HIGH -> LOW transition produces pressed. A key held during boot must first
// be released stably before its first command is accepted.
struct DebouncedControlButton {
    bool rawPressed = false;
    bool pressed = false;
    bool armed = true;
    unsigned long lastRawChangeMs = 0;

    void init(bool initialPressed, unsigned long now) {
        rawPressed = pressed = initialPressed;
        armed = !initialPressed;
        lastRawChangeMs = now;
    }
    // bit 0=confirmed press, bit 1=confirmed release
    uint8_t update(bool readingPressed, unsigned long now) {
        if (readingPressed != rawPressed) {
            rawPressed = readingPressed;
            lastRawChangeMs = now;
        }
        if (rawPressed == pressed || (unsigned long)(now - lastRawChangeMs) < CONTROL_DEBOUNCE_MS)
            return 0;
        pressed = rawPressed;
        if (!pressed) {
            const bool wasArmed = armed;
            armed = true;
            return wasArmed ? 2u : 0u; // ignore release of a key held during boot
        }
        return armed ? 1u : 0u;
    }
};

// Called only after EngineTask grants an idle flash window. Keep failed writes
// pending, show a visible warning, and retry later without writing on every loop.
bool saveConfigSafely() {
    if (!settingsStoreReady)
        settingsStoreReady = prefs.begin("recoil_cfg", false);
    if (!settingsStoreReady) {
        settingsSaveFailed = true;
        return false;
    }
    const ControlSnapshot saved = readControl();
    if (needSaveMode) {
        const int mode = saved.mode;
        if (prefs.getInt("mode_idx", -1) == mode || prefs.putInt("mode_idx", mode) == sizeof(int32_t))
            needSaveMode = false;
    }
    settingsSaveFailed = needSaveMode;
    return !settingsSaveFailed;
}

// ================= МОНОПОЛЬНАЯ ЗАДАЧА ДВИЖКА НА CORE 1 =================
void EngineTask(void *pvParameters) {
    // A failed ControlTask creation must never leave a live HID engine running.
    while (!g_tasksReady.load(std::memory_order_acquire)) {
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    int cachedStrengthStep = tuning::STRENGTH_STEPS;
    CombatMode activeMode = MODE_CLOSE; // режим зафиксирован на текущее удержание
    bool cachedEnabled = true;
    uint8_t syncCounter = 0;
    const tuning::Config &tuneConfig = engineering::runtimeConfig();
    motion::Recorder holdStats;
    bool holdStatsRunning = false;
    uint32_t holdSequence = 0;
    const uint32_t engineCpuMHz = getCpuFrequencyMhz();
    motion::TickTimer tickTimer;
    tuning::TickMathCache tickMath;
    motion::TraceCapture &trace = engineering::traceCapture();

    bool rawLastReading = false;
    bool debouncedTrigger = false;
    uint64_t lastDebounceChangeUs = esp_timer_get_time();

    bool buttonPhysicallyHeld = false;
    // На старте уже замкнутый GPIO5 не должен запускать движение.
    bool requireStartupRelease = (gpio_get_level((gpio_num_t)TRIGGER_PIN) == 0);
    bool isRecoilActive = false;
    bool inSustainLoop = false;
    bool startedFromColdBarrel = true;
    float tapColdWeight = 1.0f;
    uint64_t tapWindowForPressUs = TAP_WINDOW_US;
    uint64_t initialSegmentRemainingUs = BASE_SHOT_INTERVAL_US;
    bool shootLedSignaled = false;
    uint64_t pressStartTimeUs = 0;
    uint64_t lastReleaseTimeUs = 0;

    // Cooldown: отдельный снимок на отпускании, не затираемый при сбросе currentShot.
    bool warmStateValid = false;
    int savedShotOnRelease = 0;
    float savedPhaseOnRelease = 0;
    bool savedSustainOnRelease = false;
    CombatMode savedModeOnRelease = MODE_CLOSE;

    int activePatternIndex = 0;
    int lastColdPatternIndex = -1;
    float targetMirrorX = 1.0f;
    float smoothMirrorX = 1.0f;
    int currentShot = 0;
    R32CachedSpline splineCache;

    uint64_t shotStartTimeUs = 0;
    uint64_t lastTickTimeUs = esp_timer_get_time();
    uint64_t nextWakeTimeUs = lastTickTimeUs + BASE_TICK_US;
    uint64_t currentShotIntervalUs = BASE_SHOT_INTERVAL_US;
    float currentInvInterval = 1.0f / float(BASE_SHOT_INTERVAL_US);

    // rem_* = неотправленный остаток с субпиксельной точностью.
    float rem_x = 0.0f;
    float rem_y = 0.0f;
    float smooth_x = 0.0f;
    float smooth_y = 0.0f;
    float drift_x = 0.0f;
    float drift_y = 0.0f;
    float microStateX = 0.0f, microStateY = 0.0f;
    recoil::HidBacklogGuard hidBacklog(HID_BUSY_DROP_US);
#if (ENGINE_DIAGNOSTICS == 1)
    uint32_t consecutiveHidBusyTicks = 0;
#endif

    // Только успешно поставленные в очередь отчеты учитываются для Spring-Back.
    int32_t sentDuringPressX = 0;
    int32_t sentDuringPressY = 0;
    struct SpringBackState {
        bool active = false;
        uint64_t startUs = 0;
        int32_t totalX = 0, totalY = 0;
        int32_t queuedX = 0, queuedY = 0;
    } spring;

    // Долг первой пули: реально потерянное из-за tap-огибающей интегральное
    // движение, а не приближение из предположения о постоянном значении сплайна.
    float catchupDebtX = 0.0f;
    float catchupDebtY = 0.0f;
    float catchupProgress = 0.0f;
    float catchupCarryX = 0.0f;
    float catchupCarryY = 0.0f;
    float catchupPaidX = 0.0f, catchupPaidY = 0.0f;
    auto finishHold = [&](uint64_t at, motion::EndReason reason) {
        if (holdStatsRunning) {
            holdStats.report.endPhase =
                float(currentShot) +
                fastClampF(float(at - shotStartTimeUs) / float(currentShotIntervalUs), 0.0f, 0.999999f);
            tickTimer.finish(holdStats.report.compute, holdStatsRunning);
            const motion::Report completed = holdStats.finish(at, reason);
            trace.finish(completed);
            engineering::publishMotion(completed);
            holdStatsRunning = false;
        }
    };

#if (ENGINE_TASK_WDT == 1)
    // Подписываем именно EngineTask. Если TWDT не инициализирован в SDK,
    // add() вернёт ошибку; не пытаемся менять глобальную конфигурацию WDT.
    const bool engineWdtRegistered = (esp_task_wdt_add(NULL) == ESP_OK);
#elif (ENGINE_DIAGNOSTICS == 1)
    const bool engineWdtRegistered = false;
#endif

#if (ENGINE_DIAGNOSTICS == 1)
    uint64_t diagWindowStartUs = lastTickTimeUs;
    uint32_t diagTicks = 0, diagMinDt = UINT32_MAX, diagMaxDt = 0;
    uint32_t diagLate = 0, diagMaxLateUs = 0;
    uint32_t diagHidQueued = 0, diagHidBusy = 0, diagHidRejected = 0;
    uint32_t diagDrops = 0, diagWarmStarts = 0, diagSpringStarts = 0;
    uint32_t diagUnmounted = 0, diagMaxBusyStreak = 0;
    uint32_t diagMaxPendingAgeUs = 0, diagMaxPendingAbs = 0;
    uint32_t diagMissedSlots = 0, diagReadyAfterBusy = 0, diagMaxQueueGapUs = 0;
    uint64_t lastQueuedReportUs = 0;
    g_engineDiag.watchdogActive.store(engineWdtRegistered ? 1 : 0, std::memory_order_relaxed);
#endif

#if (ENGINE_DIAGNOSTICS == 1)
    // All peak calculations happen in Core 1's local counters.
    auto trackPending = [&](uint64_t now, float x, float y) {
        const float f = fmaxf(fabsf(x), fabsf(y));
        const uint32_t pendingAbs = (f > (float)UINT32_MAX) ? UINT32_MAX : (uint32_t)f;
        if (pendingAbs > diagMaxPendingAbs)
            diagMaxPendingAbs = pendingAbs;
        if (hidBacklog.blockedSinceUs > 0) {
            const uint64_t age = now - hidBacklog.blockedSinceUs;
            const uint32_t ageUs = (age > UINT32_MAX) ? UINT32_MAX : (uint32_t)age;
            if (ageUs > diagMaxPendingAgeUs)
                diagMaxPendingAgeUs = ageUs;
        }
    };
#endif

#if (ENGINE_TASK_WDT == 1)
    uint8_t wdtTickCounter = 0;
#endif
    for (;;) {
        // Hardware-only pause handshake. This is above every HID/spring-back path.
        // Core 0 cannot initialize networking until this task publishes the grant.
        if (engineering::pauseRequested.load(std::memory_order_acquire)) {
            finishHold(esp_timer_get_time(), motion::EndReason::ENGINEERING);
            isRecoilActive = spring.active = warmStateValid = false;
            buttonPhysicallyHeld = inSustainLoop = shootLedSignaled = false;
            rem_x = rem_y = smooth_x = smooth_y = drift_x = drift_y = 0.0f;
            catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = catchupProgress = 0.0f;
            sentDuringPressX = sentDuringPressY = 0;
            microStateX = microStateY = catchupPaidX = catchupPaidY = 0.0f;
            currentShot = 0;
            splineCache.shot = -1;
            hidBacklog.reset();
            g_engineLedState.store(ENGINE_LED_IDLE, std::memory_order_relaxed);
            engineering::pauseGranted.store(true, std::memory_order_release);
            while (engineering::pauseRequested.load(std::memory_order_acquire)) {
#if ENGINE_TASK_WDT
                if (engineWdtRegistered)
                    esp_task_wdt_reset();
#endif
                vTaskDelay(pdMS_TO_TICKS(10));
            }
            engineering::pauseGranted.store(false, std::memory_order_release);
            const uint64_t resumeUs = esp_timer_get_time();
            lastTickTimeUs = lastDebounceChangeUs = resumeUs;
            nextWakeTimeUs = resumeUs + BASE_TICK_US;
            rawLastReading = debouncedTrigger = gpio_get_level((gpio_num_t)TRIGGER_PIN) == 0;
            requireStartupRelease = true;
            continue;
        }
        uint64_t nowUs = esp_timer_get_time();
        waitForEngineDeadline(nextWakeTimeUs);

        nowUs = esp_timer_get_time();
        tickTimer.begin();
        motion::TickTimerGuard timerGuard(tickTimer, holdStats.report.compute, holdStatsRunning);
        const uint64_t lateUs = (nowUs > nextWakeTimeUs) ? (nowUs - nextWakeTimeUs) : 0ULL;
        uint32_t skipped = 0;
#if (ENGINE_DIAGNOSTICS == 1)
        if (lateUs >= ENGINE_LATE_THRESHOLD_US)
            ++diagLate;
        if (lateUs > diagMaxLateUs)
            diagMaxLateUs = (lateUs > UINT32_MAX) ? UINT32_MAX : (uint32_t)lateUs;
#endif
#if R32_ABSOLUTE_SCHEDULER
        // Deadlines are anchored to their own timeline; the timer releases Core 1.
        // A late tick cannot push every future tick late. Skip elapsed deadlines;
        // NEVER burst HID reports to "replay" missed polls.
        nextWakeTimeUs += generateNextTickDurationUs();
        while (nextWakeTimeUs <= nowUs && skipped < 16) {
            nextWakeTimeUs += generateNextTickDurationUs();
            ++skipped;
        }
        if (nextWakeTimeUs <= nowUs) {
            nextWakeTimeUs = nowUs + generateNextTickDurationUs();
            ++skipped; // long pause: resynchronize rather than spin endlessly
        }
#if ENGINE_DIAGNOSTICS
        diagMissedSlots += skipped;
#endif
#else
        nextWakeTimeUs = nowUs + generateNextTickDurationUs();
#endif

        tickTimer.budget(nextWakeTimeUs > nowUs ? nextWakeTimeUs - nowUs : 0, engineCpuMHz);
        uint64_t dtUs = nowUs - lastTickTimeUs;
        const uint64_t actualDtUs = dtUs;
        lastTickTimeUs = nowUs;
#if (ENGINE_DIAGNOSTICS == 1)
        ++diagTicks;
        const uint32_t rawDt = (dtUs > UINT32_MAX) ? UINT32_MAX : (uint32_t)dtUs;
        if (rawDt < diagMinDt)
            diagMinDt = rawDt;
        if (rawDt > diagMaxDt)
            diagMaxDt = rawDt;
        // Публикация только на границе секундного окна, без Serial/USB на Core 1.
        if (nowUs - diagWindowStartUs >= 1000000ULL) {
            g_r32DiagSequence.fetch_add(1u, std::memory_order_acq_rel); // odd: writer active
            g_engineDiag.ticks.store(diagTicks, std::memory_order_relaxed);
            g_engineDiag.minDtUs.store(diagTicks ? diagMinDt : 0u, std::memory_order_relaxed);
            g_engineDiag.maxDtUs.store(diagMaxDt, std::memory_order_relaxed);
            g_engineDiag.lateTicks.store(diagLate, std::memory_order_relaxed);
            g_engineDiag.maxLatenessUs.store(diagMaxLateUs, std::memory_order_relaxed);
            g_engineDiag.hidQueued.store(diagHidQueued, std::memory_order_relaxed);
            g_engineDiag.hidBusy.store(diagHidBusy, std::memory_order_relaxed);
            g_engineDiag.hidRejected.store(diagHidRejected, std::memory_order_relaxed);
            g_engineDiag.hidDrops.store(diagDrops, std::memory_order_relaxed);
            g_engineDiag.hidUnmountedTicks.store(diagUnmounted, std::memory_order_relaxed);
            g_engineDiag.hidMaxBusyStreak.store(diagMaxBusyStreak, std::memory_order_relaxed);
            g_engineDiag.hidMaxPendingAgeUs.store(diagMaxPendingAgeUs, std::memory_order_relaxed);
            g_engineDiag.hidMaxPendingAbs.store(diagMaxPendingAbs, std::memory_order_relaxed);
            g_engineDiag.schedulerMissedSlots.store(diagMissedSlots, std::memory_order_relaxed);
            g_engineDiag.hidReadyAfterBusy.store(diagReadyAfterBusy, std::memory_order_relaxed);
            g_engineDiag.hidMaxQueuedAgeUs.store(diagMaxQueueGapUs, std::memory_order_relaxed);
            g_engineDiag.warmStarts.store(diagWarmStarts, std::memory_order_relaxed);
            g_engineDiag.springStarts.store(diagSpringStarts, std::memory_order_relaxed);
            std::atomic_thread_fence(std::memory_order_release);
            g_r32DiagSequence.fetch_add(1u, std::memory_order_release); // even: complete
            diagTicks = 0;
            diagMinDt = UINT32_MAX;
            diagMaxDt = 0;
            diagLate = 0;
            diagMaxLateUs = 0;
            diagHidQueued = 0;
            diagHidBusy = 0;
            diagHidRejected = 0;
            diagDrops = 0;
            diagWarmStarts = 0;
            diagSpringStarts = 0;
            diagUnmounted = 0;
            diagMaxBusyStreak = 0;
            diagMaxPendingAgeUs = 0;
            diagMaxPendingAbs = 0;
            diagMissedSlots = 0;
            diagReadyAfterBusy = 0;
            diagMaxQueueGapUs = 0;
            diagWindowStartUs = nowUs;
        }
#endif
#if (ENGINE_TASK_WDT == 1)
        if (engineWdtRegistered && (++wdtTickCounter & 0x7F) == 0) {
            esp_task_wdt_reset();
        }
#endif
        // Длинный пропуск НЕ превращаем искусственно в ровно 1 мс.
        // Ограничение 5 мс защищает от большого одноразового скачка курсора.
        const bool longTimingPause = dtUs >= HID_BUSY_DROP_US;
        if (dtUs == 0ULL)
            dtUs = BASE_TICK_US;
        if (dtUs > 5000ULL)
            dtUs = 5000ULL;
        const R32TimeDynamics timeDynamics = r32TimeDynamics((uint32_t)dtUs);

        // OFF/ON every engine tick (no 16-tick safety latency).
        // Strength snapshot refresh remains bounded; HTTP edits apply only after reboot.
        const ControlSnapshot liveCfg = readControl();
        cachedEnabled = liveCfg.enabled;
        if ((++syncCounter & 0x0F) == 0) {
            cachedStrengthStep = fastClampI(liveCfg.strengthStep, 0, tuning::STRENGTH_STEPS);
        }

        // Исходный симметричный 3-мс антидребезг оставлен без изменений.
        const bool rawPressed = (gpio_get_level((gpio_num_t)TRIGGER_PIN) == 0);
        if (rawPressed != rawLastReading) {
            rawLastReading = rawPressed;
            lastDebounceChangeUs = nowUs;
        }
        if ((nowUs - lastDebounceChangeUs) >= DEBOUNCE_TRIGGER_US) {
            debouncedTrigger = rawPressed;
        }
        // Защита снимается только после СТАБИЛЬНОГО отпущенного контакта,
        // иначе 1-мс отскок мог бы разрешить запуск при удержании во время boot.
        if (requireStartupRelease && !rawPressed && !debouncedTrigger &&
            (nowUs - lastDebounceChangeUs >= DEBOUNCE_TRIGGER_US)) {
            requireStartupRelease = false;
        }

        if (longTimingPause) {
            // No old filter tail, debt, or return may survive a stalled engine.
            spring.active = false;
            rem_x = rem_y = smooth_x = smooth_y = 0.0f;
            catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = 0.0f;
            catchupPaidX = catchupPaidY = 0.0f;
            hidBacklog.reset();
        }

        // Core 0 requests NVS work; Core 1 acknowledges only when all motion,
        // including spring-back, has stopped. No engine work runs during the write.
        if (g_flashSaveRequested.load(std::memory_order_acquire) && !isRecoilActive && !spring.active &&
            !rawPressed && !debouncedTrigger) {
            g_flashSaveGranted.store(true, std::memory_order_release);
            while (g_flashSaveRequested.load(std::memory_order_acquire)) {
#if ENGINE_TASK_WDT
                if (engineWdtRegistered)
                    esp_task_wdt_reset();
#endif
                vTaskDelay(1);
            }
            g_flashSaveGranted.store(false, std::memory_order_release);
            nowUs = esp_timer_get_time();
            lastTickTimeUs = nowUs;
            nextWakeTimeUs = nowUs + BASE_TICK_US;
            rawLastReading = gpio_get_level((gpio_num_t)TRIGGER_PIN) == 0;
            debouncedTrigger = rawLastReading;
            buttonPhysicallyHeld = false;
            requireStartupRelease = rawLastReading;
            lastDebounceChangeUs = nowUs;
            continue;
        }

        // Never resume a held trigger after USB unplug/suspend/reconnect. Also
        // discard all filter/debt state so no old movement survives transport loss.
        if (!Mouse16.mounted() || tud_suspended()) {
            finishHold(nowUs, motion::EndReason::USB_LOSS);
#if ENGINE_DIAGNOSTICS
            ++diagUnmounted;
            consecutiveHidBusyTicks = 0;
#endif
            requireStartupRelease = true;
            buttonPhysicallyHeld = false;
            isRecoilActive = spring.active = warmStateValid = false;
            inSustainLoop = shootLedSignaled = false;
            rem_x = rem_y = smooth_x = smooth_y = 0.0f;
            catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = 0.0f;
            catchupPaidX = catchupPaidY = 0.0f;
            hidBacklog.reset();
            g_engineLedState.store(ENGINE_LED_IDLE, std::memory_order_relaxed);
            continue;
        }

        if (debouncedTrigger && !buttonPhysicallyHeld && !requireStartupRelease) {
            buttonPhysicallyHeld = true;
            pressStartTimeUs = nowUs;
            // При новом нажатии не продолжать предыдущий возврат поверх новой очереди.
            spring.active = false;

            const ControlSnapshot cfg = readControl();
            cachedStrengthStep = fastClampI(cfg.strengthStep, 0, tuning::STRENGTH_STEPS);
            activeMode = cfg.mode; // выбранный режим фиксируется на весь press/release
            cachedEnabled = cfg.enabled;

            if (cachedEnabled) {
                isRecoilActive = true;
                holdStats.start(++holdSequence, nowUs, uint8_t(activeMode), uint16_t(cachedStrengthStep));
                holdStats.report.compute.cpuMHz = engineCpuMHz;
                trace.begin(holdSequence, nowUs, tuneConfig, uint16_t(cachedStrengthStep));
                holdStatsRunning = true;
                shootLedSignaled = false;

                // Warm start: восстановить сохраненную позицию той же траектории.
                const uint64_t idleMs =
                    (lastReleaseTimeUs > 0) ? ((nowUs - lastReleaseTimeUs) / 1000ULL) : SPRAY_COOLDOWN_MS;
                const bool canResume =
                    warmStateValid && (activeMode == savedModeOnRelease) && (idleMs < SPRAY_COOLDOWN_MS);
                float resumeFraction = 0.0f;
                if (canResume) {
#if (ENGINE_DIAGNOSTICS == 1)
                    ++diagWarmStarts;
#endif
                    if (tuneConfig.continuousWarm) {
                        const float phase =
                            tuning::cooledPhase(savedPhaseOnRelease, nowUs - lastReleaseTimeUs,
                                                uint64_t(SPRAY_COOLDOWN_MS) * 1000ULL);
                        currentShot = fastClampI(int(phase), 0, SHOTS_PER_SPRAY - 1);
                        resumeFraction = phase - float(currentShot);
                        if (phase < 0.0001f)
                            resumeFraction = 0;
                    } else {
                        const int stepsBack = (int)(idleMs / COOLDOWN_STEP_MS);
                        currentShot = fastClampI(savedShotOnRelease - stepsBack, 0, SHOTS_PER_SPRAY - 1);
                    }
                    inSustainLoop = savedSustainOnRelease && (currentShot >= LOOP_START_SHOT);
                } else {
                    currentShot = 0;
                    inSustainLoop = false;
                    activePatternIndex = r32ChooseColdPattern(lastColdPatternIndex);
                    lastColdPatternIndex = activePatternIndex;
                    targetMirrorX = (recoilRandomBits() & 1) ? 1.0f : -1.0f;
                    smoothMirrorX = targetMirrorX;
                }
                startedFromColdBarrel = currentShot == 0 && resumeFraction == 0.0f;
                currentShotIntervalUs = generateNextIntervalUs();
                currentInvInterval = 1.0f / float(currentShotIntervalUs);
                shotStartTimeUs = nowUs - uint64_t(resumeFraction * float(currentShotIntervalUs));
                holdStats.report.startPhase = float(currentShot) + resumeFraction;
                holdStats.report.pattern = uint8_t(activePatternIndex);
                initialSegmentRemainingUs = currentShotIntervalUs - (nowUs - shotStartTimeUs);
                tapColdWeight = tuneConfig.continuousWarm
                                    ? 1.0f - tuning::smooth5(float(currentShot) + resumeFraction)
                                    : (startedFromColdBarrel ? 1.0f : 0.0f);
                tapWindowForPressUs = tuneConfig.continuousWarm
                                          ? uint64_t(float(TAP_WINDOW_US) * (1.0f - resumeFraction))
                                          : TAP_WINDOW_US;
                if (!tapWindowForPressUs)
                    tapWindowForPressUs = 1;

                rem_x = rem_y = 0.0f;
                smooth_x = smooth_y = 0.0f;
                drift_x = drift_y = 0.0f;
                microStateX = microStateY = catchupPaidX = catchupPaidY = 0.0f;
                hidBacklog.reset();
#if (ENGINE_DIAGNOSTICS == 1)
                consecutiveHidBusyTicks = 0;
#endif
                sentDuringPressX = sentDuringPressY = 0;
                microStateX = microStateY = catchupPaidX = catchupPaidY = 0.0f;
                catchupDebtX = catchupDebtY = 0.0f;
                catchupProgress = 0.0f;
                catchupCarryX = catchupCarryY = 0.0f;
            } else {
                warmStateValid = false;
            }
        } else if (!debouncedTrigger && buttonPhysicallyHeld) {
            buttonPhysicallyHeld = false;
            lastReleaseTimeUs = nowUs;

            if (isRecoilActive) {
                // Снимок до сброса: иначе всегда восстановится только 0-й сегмент.
                savedPhaseOnRelease = float(currentShot) + fastClampF(float(nowUs - shotStartTimeUs) /
                                                                          float(currentShotIntervalUs),
                                                                      0.0f, 0.999999f);
                holdStats.report.endPhase = savedPhaseOnRelease;
                savedShotOnRelease = currentShot;
                savedSustainOnRelease = inSustainLoop;
                savedModeOnRelease = activeMode;
                warmStateValid = true;
                finishHold(nowUs, motion::EndReason::RELEASE);
                isRecoilActive = false;
                inSustainLoop = false;
                currentShot = 0;

#if (TAP_SPRINGBACK_ENABLE == 1)
                if ((nowUs - pressStartTimeUs) < TAP_WINDOW_US &&
                    (sentDuringPressX != 0 || sentDuringPressY != 0) &&
                    (SPRINGBACK_ON_WARM_TAP || startedFromColdBarrel)) {
#if (ENGINE_DIAGNOSTICS == 1)
                    ++diagSpringStarts;
#endif
                    spring.active = true;
                    spring.startUs = nowUs;
                    spring.totalX = -sentDuringPressX;
                    spring.totalY = -sentDuringPressY;
                    spring.queuedX = spring.queuedY = 0;
                }
#endif

                // Неотправленные движения из завершенной очереди недопустимо
                // проталкивать позже: USB-девайс мог быть отключен/занят.
                rem_x = rem_y = 0.0f;
                g_engineLedState.store(ENGINE_LED_IDLE, std::memory_order_relaxed);
                shootLedSignaled = false;
            }
        }

        if (!cachedEnabled) {
            finishHold(nowUs, motion::EndReason::SWITCHED_OFF);
            warmStateValid = false;
            if (isRecoilActive || spring.active) {
                isRecoilActive = false;
                spring.active = false;
                inSustainLoop = false;
                warmStateValid = false;
                shootLedSignaled = false;
                rem_x = rem_y = 0.0f;
                g_engineLedState.store(ENGINE_LED_IDLE, std::memory_order_relaxed);
            }
            continue;
        }

        // Независимое состояние Spring-Back: отправляет инкременты ПОСЛЕ release.
        if (!isRecoilActive && spring.active) {
            if (!Mouse16.mounted()) {
                spring.active = false; // Отключен USB — не копим возврат до переподключения.
            } else if (recoil::springExpired(nowUs - spring.startUs, TAP_SPRINGBACK_TIME_US,
                                             HID_BUSY_DROP_US)) {
                spring.active = false; // check deadline BEFORE attempting any report
            } else {
                const uint64_t passed = nowUs - spring.startUs;
                const float u = (float)passed / (float)TAP_SPRINGBACK_TIME_US;
                const float fraction = easeCubic(u);
                const int desiredX = (int)__builtin_lrintf((float)spring.totalX * fraction);
                const int desiredY = (int)__builtin_lrintf((float)spring.totalY * fraction);
                const int stepX = desiredX - spring.queuedX;
                const int stepY = desiredY - spring.queuedY;
                if (stepX != 0 || stepY != 0) {
                    const int16_t dx = (int16_t)fastClampI(stepX, -32767, 32767);
                    const int16_t dy = (int16_t)fastClampI(stepY, -32767, 32767);
                    if (!Mouse16.ready()) {
#if (ENGINE_DIAGNOSTICS == 1)
                        ++diagHidBusy;
#endif
                    } else if (Mouse16.sendMove(dx, dy)) {
                        spring.queuedX += dx;
                        spring.queuedY += dy;
#if (ENGINE_DIAGNOSTICS == 1)
                        ++diagHidQueued;
#endif
                    } else {
#if (ENGINE_DIAGNOSTICS == 1)
                        ++diagHidRejected;
#endif
                    }
                }
                if ((passed >= TAP_SPRINGBACK_TIME_US && spring.queuedX == spring.totalX &&
                     spring.queuedY == spring.totalY) ||
                    recoil::springExpired(passed, TAP_SPRINGBACK_TIME_US, HID_BUSY_DROP_US)) {
                    spring.active = false;
                }
            }
        }

        if (!isRecoilActive)
            continue;
        holdStats.tick(actualDtUs, lateUs > UINT32_MAX ? UINT32_MAX : uint32_t(lateUs), skipped);

        // Абсолютное продвижение фазы: опоздание тика не суммируется со временем
        // следующего сегмента. Учитываем также пропуск нескольких границ.
        int crossed = 0;
        while ((nowUs - shotStartTimeUs) >= currentShotIntervalUs && crossed++ < 64) {
            // Хвост от дискретизации плавного catch-up отдаем первым тиком нового сегмента.
            if (tapColdWeight > 0.0f && currentShot == 0) {
#if (TAP_AUTO_CATCHUP == 1)
                if (tuneConfig.limitCatchup) {
                    holdStats.report.droppedCatchupX += catchupDebtX - catchupPaidX;
                    holdStats.report.droppedCatchupY += catchupDebtY - catchupPaidY;
                    catchupDebtX = catchupDebtY = catchupPaidX = catchupPaidY = 0.0f;
                } else {
                    catchupCarryX += catchupDebtX * (1.0f - catchupProgress);
                    catchupCarryY += catchupDebtY * (1.0f - catchupProgress);
                }
#endif
            }
            shotStartTimeUs += currentShotIntervalUs;
            currentShotIntervalUs = generateNextIntervalUs();
                currentInvInterval = 1.0f / float(currentShotIntervalUs);
            ++currentShot;
            if (currentShot >= SHOTS_PER_SPRAY) {
                currentShot = LOOP_START_SHOT;
                inSustainLoop = true;
                if (recoilRandomBits() & 1)
                    targetMirrorX = -targetMirrorX;
            }
        }
        if (crossed >= 64) {
            // Не пытаться отыграть огромный пропуск после зависания/остановки таймера.
            shotStartTimeUs = nowUs;
            currentShotIntervalUs = generateNextIntervalUs();
                currentInvInterval = 1.0f / float(currentShotIntervalUs);
            catchupCarryX = catchupCarryY = 0.0f;
        }

        smoothMirrorX += timeDynamics.mirrorAlpha * (targetMirrorX - smoothMirrorX);

        const int safePattern = fastClampI(activePatternIndex, 0, NUM_PATTERNS - 1);
        const int idx1 = currentShot;
        const BulletTarget(*bank)[SHOTS_PER_SPRAY] =
            (activeMode == MODE_CLOSE) ? PATTERN_CLOSE : PATTERN_LONG;
        const float coreAnchorY = (activeMode == MODE_CLOSE) ? CORE_ANCHOR_CLOSE_Y : CORE_ANCHOR_LONG_Y;
        const float invInterval = currentInvInterval;
        const float t = (float)(nowUs - shotStartTimeUs) * invInterval;
        BulletTarget splineVec;
#if R32_SPLINE_CACHE
        r32PrepareSpline(splineCache, currentShot, safePattern, activeMode, inSustainLoop, bank, coreAnchorY);
        splineVec = r32EvalSpline(splineCache, t);
#else
        const BulletTarget p0 =
            getBalancedNode(bank, safePattern, r32NeighborIndex(currentShot, -1, inSustainLoop), coreAnchorY);
        const BulletTarget p1 =
            getBalancedNode(bank, safePattern, r32NeighborIndex(currentShot, 0, inSustainLoop), coreAnchorY);
        const BulletTarget p2 =
            getBalancedNode(bank, safePattern, r32NeighborIndex(currentShot, +1, inSustainLoop), coreAnchorY);
        const BulletTarget p3 =
            getBalancedNode(bank, safePattern, r32NeighborIndex(currentShot, +2, inSustainLoop), coreAnchorY);
        splineVec = evalCatmullRom(p0, p1, p2, p3, t);
#endif

        const tuning::Profile &calibration = engineering::runtimeProfile(activeMode == MODE_LONG);
        splineVec.y = tuning::patternY(splineVec.y, coreAnchorY, calibration);
        const float sectionGain = tuning::sectionGain(
            calibration, float(currentShot) + fastClampF(t, 0.0f, 1.0f), tuneConfig.transitionMs);

        tickMath.prepareStrength(cachedStrengthStep, activeMode == MODE_LONG, calibration, tuneConfig);
        const float currentMultY = tickMath.strength;
        const float currentMultX = tickMath.horizontalStrength;
        const float dtWeight = (float)dtUs * invInterval;

        // Legacy mode preserves the original envelope. Continuous warm phase blends
        // into the cold envelope and shortens its window to the remaining segment.
        const uint64_t holdTimeUs = nowUs - pressStartTimeUs;
        float tapEnvelope = 1.0f;
        if (tapColdWeight > 0.0f && currentShot == 0 && holdTimeUs < tapWindowForPressUs) {
            const float u = float(holdTimeUs) / float(tapWindowForPressUs);
            if (TAP_CURVE_POWER == 2)
                tapEnvelope = u * u;
            else if (TAP_CURVE_POWER == 3)
                tapEnvelope = u * u * u;
            else {
                const float u2 = u * u;
                tapEnvelope = u2 * u2;
            }
            tapEnvelope = 1.0f - tapColdWeight * (1.0f - tapEnvelope);
        }

        const float baseX =
            (splineVec.x * smoothMirrorX) * dtWeight * BASE_PIXEL_SCALE_X * currentMultX * sectionGain;
        const float baseY = splineVec.y * dtWeight * BASE_PIXEL_SCALE_Y * currentMultY * sectionGain;
        float spline_x = baseX * tapEnvelope;
        float spline_y = baseY * tapEnvelope;

#if (TAP_AUTO_CATCHUP == 1)
        if (tapColdWeight > 0.0f && currentShot == 0) {
            if (holdTimeUs < tapWindowForPressUs) {
                catchupDebtX += baseX - spline_x;
                catchupDebtY += baseY - spline_y;
            } else {
                // Долг от первой половины распределяется кубической плавной функцией.
                // Начало и конец добавки: нулевая скорость (нет ступеньки 1.0 -> 1.75).
                const float repaymentUs =
                    fmaxf(1.0f, float(initialSegmentRemainingUs) - float(tapWindowForPressUs));
                const float progress =
                    easeCubic((float(holdTimeUs) - float(tapWindowForPressUs)) / repaymentUs);
                const float stepProgress = fastClampF(progress - catchupProgress, 0.0f, 1.0f);
                if (tuneConfig.limitCatchup) {
                    const float extraX = tuning::catchupStep(catchupDebtX, progress, catchupPaidX, baseX,
                                                             tuneConfig.catchupMaxPct);
                    const float extraY = tuning::catchupStep(catchupDebtY, progress, catchupPaidY, baseY,
                                                             tuneConfig.catchupMaxPct);
                    spline_x += extraX;
                    spline_y += extraY;
                    catchupPaidX += extraX;
                    catchupPaidY += extraY;
                } else {
                    spline_x += catchupDebtX * stepProgress;
                    spline_y += catchupDebtY * stepProgress;
                }
                catchupProgress = progress;
            }
        }
        spline_x += catchupCarryX;
        spline_y += catchupCarryY;
        catchupCarryX = catchupCarryY = 0.0f;
#endif

        if (!shootLedSignaled && (!startedFromColdBarrel || holdTimeUs >= TAP_WINDOW_US)) {
            shootLedSignaled = true;
            g_engineLedState.store((activeMode == MODE_CLOSE) ? ENGINE_LED_CLOSE : ENGINE_LED_LONG,
                                   std::memory_order_relaxed);
        }

        // Noise/fatigue parameters are preserved; variable-dt smoothing is
        // displacement-conserving and matches the original EMA at nominal dt.
        const float jitterActive = (currentMultY > 0.001f) ? tapEnvelope : 0.0f;
        const float fatigueFactor = computeMuscleFatigueFactor(idx1, t, inSustainLoop);
        const float dynamicMicroAmp = JITTER_MICRO_AMP_PX * fatigueFactor;
        // Variable-dt Ornstein-Uhlenbeck scaling: same stationary variance as R3.1
        // and the same coefficients at exactly 1000us. Random draw count unchanged.
        drift_x = timeDynamics.driftRho * drift_x +
                  timeDynamics.driftInnovation * randomCenteredFloat() * JITTER_DRIFT_AMP_PX;
        drift_y = timeDynamics.driftRho * drift_y +
                  timeDynamics.driftInnovation * randomCenteredFloat() * JITTER_DRIFT_AMP_PX;
        tickMath.prepareMicro(uint32_t(dtUs), calibration.microMs);
        const float micro_x =
            tickMath.micro(randomCenteredFloat(), microStateX) *
            dynamicMicroAmp * timeDynamics.microScale;
        const float micro_y =
            tickMath.micro(randomCenteredFloat(), microStateY) *
            dynamicMicroAmp * timeDynamics.microScale;
        const float noiseScale = tickMath.noise;

        if (currentMultY <= 0.001f || sectionGain == 0.0f) {
            // Zero profile means zero new motion, including an old EMA/backlog tail.
            rem_x = rem_y = smooth_x = smooth_y = 0.0f;
            catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = 0.0f;
            catchupPaidX = catchupPaidY = 0.0f;
            hidBacklog.reset();
            continue;
        }
        const float raw_x = (spline_x + (drift_x + micro_x) * jitterActive * sectionGain * noiseScale) *
                            (float(calibration.horizontal) * 0.01f);
        const float raw_y = spline_y + (drift_y + micro_y) * jitterActive * sectionGain * noiseScale;
        const float dtInTicks = (float)dtUs / (float)BASE_TICK_US;
        const float increment_x =
            recoil::filterIncrement(raw_x, dtInTicks, timeDynamics.emaAlpha, EMA_SMOOTH_ALPHA, smooth_x);
        const float increment_y =
            recoil::filterIncrement(raw_y, dtInTicks, timeDynamics.emaAlpha, EMA_SMOOTH_ALPHA, smooth_y);

        // Субпиксельная арифметика: при сбое очереди HID сохраняем необслуженный
        // инкремент. При долгой занятости >25 мс сбрасываем его, чтобы не было рывка.
        rem_x += increment_x;
        rem_y += increment_y;
        if (!Mouse16.mounted()) {
            // Только полное отключение USB стирает старый долг немедленно.
            rem_x = rem_y = 0.0f;
            hidBacklog.reset();
#if (ENGINE_DIAGNOSTICS == 1)
            consecutiveHidBusyTicks = 0;
            ++diagUnmounted;
#endif
            continue;
        }
        if (!Mouse16.ready()) {
            ++holdStats.report.busy;
#if (ENGINE_DIAGNOSTICS == 1)
            ++diagHidBusy;
            if (++consecutiveHidBusyTicks > diagMaxBusyStreak)
                diagMaxBusyStreak = consecutiveHidBusyTicks;
#endif
            // Endpoint занят штатным предыдущим пакетом — сохранить остаток до
            // следующего тика, не превращая это в потерянное движение.
            const bool backlogExpired = hidBacklog.onBlocked(nowUs);
#if (ENGINE_DIAGNOSTICS == 1)
            trackPending(nowUs, rem_x, rem_y);
#endif
            if (backlogExpired) {
                ++holdStats.report.drops;
                rem_x = rem_y = smooth_x = smooth_y = 0.0f;
                catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = 0.0f;
                catchupPaidX = catchupPaidY = 0.0f;
#if (ENGINE_DIAGNOSTICS == 1)
                ++diagDrops;
#endif
            }
            continue;
        }
#if (ENGINE_DIAGNOSTICS == 1)
        if (consecutiveHidBusyTicks > 0)
            ++diagReadyAfterBusy; // proxy, not USB completion!
        consecutiveHidBusyTicks = 0;
#endif
        // Ready may have returned only after a long scheduling/USB pause.
        // Reject stale history even on the ready path, before rounding or sending.
        if (hidBacklog.expired(nowUs)) {
            ++holdStats.report.drops;
            rem_x = rem_y = smooth_x = smooth_y = 0.0f;
            catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = 0.0f;
            catchupPaidX = catchupPaidY = 0.0f;
            // Ready is only a hint; a zero-motion probe must actually enter
            // the queue before a stale/rejected transport is considered recovered.
            // A failed probe leaves the stale state latched, never re-accumulating.
            if (Mouse16.sendMove(0, 0)) {
                holdStats.queued(0, 0, nowUs);
                trace.queued(0, 0, nowUs);
                hidBacklog.reset();
#if ENGINE_DIAGNOSTICS
                ++diagHidQueued;
#endif
            } else {
                ++holdStats.report.rejected;
                (void)hidBacklog.onBlocked(nowUs);
#if ENGINE_DIAGNOSTICS
                ++diagHidRejected;
#endif
            }
#if ENGINE_DIAGNOSTICS
            ++diagDrops;
#endif
            continue;
        }
        const int send_x = (int)__builtin_lrintf(rem_x);
        const int send_y = (int)__builtin_lrintf(rem_y);
        if (send_x != 0 || send_y != 0) {
            const int16_t out_x = (int16_t)fastClampI(send_x, -32767, 32767);
            const int16_t out_y = (int16_t)fastClampI(send_y, -32767, 32767);
            if (Mouse16.sendMove(out_x, out_y)) {
#if (ENGINE_DIAGNOSTICS == 1)
                ++diagHidQueued;
                if (lastQueuedReportUs > 0) {
                    const uint64_t since = nowUs - lastQueuedReportUs;
                    if (since > diagMaxQueueGapUs)
                        diagMaxQueueGapUs = since > UINT32_MAX ? UINT32_MAX : (uint32_t)since;
                }
                lastQueuedReportUs = nowUs;
#endif
                holdStats.queued(out_x, out_y, nowUs);
                trace.queued(out_x, out_y, nowUs);
                rem_x -= (float)out_x;
                rem_y -= (float)out_y;
                // Only a tap can request a return. Bound counters even if the
                // trigger remains held for days (avoid signed integer overflow).
                if (nowUs - pressStartTimeUs < TAP_WINDOW_US) {
                    sentDuringPressX += out_x;
                    sentDuringPressY += out_y;
                }
                hidBacklog.reset();
            } else {
#if (ENGINE_DIAGNOSTICS == 1)
                ++diagHidRejected;
#endif
                ++holdStats.report.rejected;
                const bool backlogExpired = hidBacklog.onBlocked(nowUs);
#if (ENGINE_DIAGNOSTICS == 1)
                trackPending(nowUs, rem_x, rem_y);
#endif
                if (backlogExpired) {
                    ++holdStats.report.drops;
                    rem_x = rem_y = smooth_x = smooth_y = 0.0f;
                    catchupDebtX = catchupDebtY = catchupCarryX = catchupCarryY = 0.0f;
                    catchupPaidX = catchupPaidY = 0.0f;
#if (ENGINE_DIAGNOSTICS == 1)
                    ++diagDrops;
#endif
                }
            }
        }
    }
}

// ================= ЗАДАЧА ПЕРИФЕРИИ, КНОПОК И NVS НА CORE 0 =================
void ControlTask(void *pvParameters) {
    DebouncedControlButton fn, tune;
    unsigned long now = millis();
    fn.init(digitalRead(FN_BUTTON_PIN) == LOW, now);
    tune.init(digitalRead(ENGINEERING_BUTTON_PIN) == LOW, now);

    recoil::FnGesture fnGesture(FN_HOLD_MS, FN_MIN_CLICK_MS, FN_DOUBLE_WINDOW_MS);

    for (;;) {
        now = millis();
        const uint8_t tuneEdge = tune.update(digitalRead(ENGINEERING_BUTTON_PIN) == LOW, now);
        if ((tuneEdge & 1u) && (!g_engineFault.load(std::memory_order_acquire) ||
                                engineering::phase() == engineering::Phase::FAULT)) {
            // Release any earlier flash handshake so it cannot block the mode pause.
            g_flashSaveRequested.store(false, std::memory_order_release);
            engineering::buttonPressed(uint32_t(now), readControl().enabled);
        }
        if (engineering::active()) {
            if (engineering::pauseGranted.load(std::memory_order_acquire) && needSaveMode &&
                (int32_t)(now - saveSettingsTime) >= 0) {
                saveConfigSafely();
                saveSettingsTime = millis() + 2000UL;
            }
            engineering::service(uint32_t(now), !needSaveMode, int(readControl().mode));
            renderLed(now);
            vTaskDelay(pdMS_TO_TICKS(10));
            continue; // FN button cannot alter state while tuning
        }
        updateBlinker(now);
        const uint8_t fnEdge = fn.update(digitalRead(FN_BUTTON_PIN) == LOW, now);
        const auto event = fnGesture.update(fnEdge & 1u, fnEdge & 2u, fn.pressed, now);
        if (event == recoil::FnGesture::LONG_HOLD) {
            const CombatMode newMode = (readControl().mode == MODE_CLOSE) ? MODE_LONG : MODE_CLOSE;
            setControlMode(newMode);
            needSaveMode = true;
            saveSettingsTime = now + 2000UL;
            if (newMode == MODE_CLOSE)
                startBlink(0, 20, 80, 3);
            else
                startBlink(80, 0, 80, 3);
        } else if (event == recoil::FnGesture::DOUBLE_CLICK) {
            const bool enabled = !readControl().enabled;
            setControlEnabled(enabled);
            if (enabled)
                startBlink(0, 60, 0, 2);
            else
                startBlink(60, 0, 0, 2);
        }

        const bool physicallyShooting = gpio_get_level((gpio_num_t)TRIGGER_PIN) == 0;
        if (needSaveMode && (int32_t)(now - saveSettingsTime) >= 0 && !physicallyShooting &&
            !g_engineFault.load(std::memory_order_acquire)) {
            g_flashSaveRequested.store(true, std::memory_order_release);
        }
        if (g_flashSaveGranted.load(std::memory_order_acquire) &&
            g_flashSaveRequested.load(std::memory_order_acquire)) {
            saveConfigSafely();
            saveSettingsTime = millis() + 2000UL;
            g_flashSaveRequested.store(false, std::memory_order_release);
        }

        // Compute one authoritative LED color after updating all button states.
        renderLed(now);

#if (ENGINE_DIAG_UART == 1)
        static unsigned long lastDiagPrintMs = 0;
        if ((unsigned long)(now - lastDiagPrintMs) >= 1000UL) {
            lastDiagPrintMs = now;
            R32DiagSnapshot diag;
            if (r32ReadDiagSnapshot(diag))
                Serial0.printf(
                    "[engine] ticks=%lu dt=%lu..%lu us late=%lu maxlate=%lu us hidQ=%lu busy=%lu "
                    "rejected=%lu drops=%lu unmounted=%lu busyPeak=%lu pendingAgeUs=%lu pendingAbs=%lu "
                    "warm=%lu spring=%lu twdt=%lu missedSlots=%lu readyAfterBusy=%lu queueGapUs=%lu done=%lu "
                    "failed=%lu\n",
                    (unsigned long)diag.ticks, (unsigned long)diag.minDtUs, (unsigned long)diag.maxDtUs,
                    (unsigned long)diag.lateTicks, (unsigned long)diag.maxLatenessUs,
                    (unsigned long)diag.hidQueued, (unsigned long)diag.hidBusy,
                    (unsigned long)diag.hidRejected, (unsigned long)diag.hidDrops,
                    (unsigned long)diag.hidUnmountedTicks, (unsigned long)diag.hidMaxBusyStreak,
                    (unsigned long)diag.hidMaxPendingAgeUs, (unsigned long)diag.hidMaxPendingAbs,
                    (unsigned long)diag.warmStarts, (unsigned long)diag.springStarts,
                    (unsigned long)diag.watchdogActive, (unsigned long)diag.schedulerMissedSlots,
                    (unsigned long)diag.hidReadyAfterBusy, (unsigned long)diag.hidMaxQueuedAgeUs,
                    (unsigned long)diag.hidTransferCompleted, (unsigned long)diag.hidTransferFailed);
        }
#endif
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void failStartup() {
    setControlEnabled(false);
    g_engineFault.store(true, std::memory_order_release);
    for (;;) {
        writeLedIfChanged(80, 0, 0);
        delay(150);
        writeLedIfChanged(0, 0, 0);
        delay(150);
    }
}

void setup() {
#if (ENGINE_DIAG_UART == 1)
    Serial0.begin(115200);
#endif
    pinMode(TRIGGER_PIN, INPUT_PULLUP);
    pinMode(FN_BUTTON_PIN, INPUT_PULLUP);
    pinMode(ENGINEERING_BUTTON_PIN, INPUT_PULLUP);

    writeLedIfChanged(20, 20, 20);
    if (!engineering::begin())
        failStartup(); // Wi-Fi stays uninitialized in play mode

    // USB ID сохранен из исходника для совместимости; это не полная эмуляция G502.
    // Для своего устройства используйте законно выделенные VID/PID и собственные строки.
    USB.VID(0x046D);
    USB.PID(0xC08B);
    USB.usbVersion(0x0200);
    USB.usbPower(300);
    USB.usbAttributes(0xA0);
    USB.productName("G502 HERO Gaming Mouse");
    USB.manufacturerName("Logitech");
    USB.serialNumber("2543ZE1SMTL9");

    r32InitDynamics();
    Mouse16.begin();
    if (!USB.begin())
        failStartup();

    settingsStoreReady = prefs.begin("recoil_cfg", false);
    settingsSaveFailed = !settingsStoreReady;
    // Migrate R3's coarse profile only when no valid R4 calibration blob exists.
    const int legacyProfile = settingsStoreReady ? constrain(prefs.getInt("prof_idx", 14), 0, 14) : 14;
    const int initStrength =
        engineering::adoptLegacyStrength(int(lroundf(MULTIPLIERS[legacyProfile] * 50.0f)));

    int rawMode = settingsStoreReady ? prefs.getInt("mode_idx", MODE_CLOSE) : MODE_CLOSE;
    CombatMode initMode = (rawMode == MODE_LONG) ? MODE_LONG : MODE_CLOSE;

    // Одна атомарная публикация согласованной стартовой конфигурации.
    g_atomicState.packed.store(packControl(initStrength, initMode, engineering::bootEnabled()),
                               std::memory_order_relaxed);

    // Timer-notification wait keeps Core 1 schedulable. Do not disable Idle WDT.
    esp_timer_create_args_t timerArgs = {};
    timerArgs.callback = engineWakeCallback;
    timerArgs.dispatch_method = ESP_TIMER_TASK;
    timerArgs.name = "engine-wake";
    if (esp_timer_create(&timerArgs, &engineWakeTimer) != ESP_OK) {
        failStartup();
    }

    // Create Engine first: it waits on g_tasksReady and cannot emit HID reports
    // until BOTH tasks were successfully created. Failure is visible on the LED.
    const BaseType_t engineCreated =
        xTaskCreatePinnedToCore(EngineTask, "EngineTask", 4096, NULL, 4, &engineTaskHandle, 1);
    BaseType_t controlCreated = pdFAIL;
    if (engineCreated == pdPASS && engineTaskHandle != NULL) {
        controlCreated =
            xTaskCreatePinnedToCore(ControlTask, "ControlTask", 8192, NULL, 1, &controlTaskHandle, 0);
    }
    if (engineCreated != pdPASS || engineTaskHandle == NULL || controlCreated != pdPASS ||
        controlTaskHandle == NULL) {
        // An error must not leave a working-looking HID engine with no buttons.
        failStartup();
    }
    g_tasksReady.store(true, std::memory_order_release);
}

void loop() { vTaskDelete(NULL); }

// Geometric preview: actual banks + spline + calibration, without tap/catch-up,
// stochastic noise, mirror changes, EMA, quantization, USB timing or host processing.
void engineering::buildPreview(bool longMode, int pattern, const tuning::Config &config,
                               engineering::Preview &out) {
    const auto *bank = longMode ? PATTERN_LONG : PATTERN_CLOSE;
    const float anchor = longMode ? CORE_ANCHOR_LONG_Y : CORE_ANCHOR_CLOSE_Y;
    const float ky = tuning::strengthMultiplier(config.strength), kx = ky * (longMode ? 0.20f : 0.70f);
    const auto &p = config.profiles[longMode ? 1 : 0];
    engineering::PreviewPoint point = {0, 0, 0, 0};
    out.points[0] = point;
    for (unsigned i = 1; i < engineering::Preview::COUNT; ++i) {
        const int shot = int((i - 1) / 8);
        const float t = (float((i - 1) % 8) + .5f) / 8.0f;
        const auto p0 = getBalancedNode(bank, pattern, r32NeighborIndex(shot, -1, false), anchor);
        const auto p1 = getBalancedNode(bank, pattern, r32NeighborIndex(shot, 0, false), anchor);
        const auto p2 = getBalancedNode(bank, pattern, r32NeighborIndex(shot, 1, false), anchor);
        const auto p3 = getBalancedNode(bank, pattern, r32NeighborIndex(shot, 2, false), anchor);
        const auto v = evalCatmullRom(p0, p1, p2, p3, t);
        const float g = tuning::sectionGain(p, float(shot) + t, config.transitionMs);
        point.beforeX += v.x * BASE_PIXEL_SCALE_X * kx / 8.0f;
        point.beforeY += v.y * BASE_PIXEL_SCALE_Y * ky / 8.0f;
        point.afterX += v.x * BASE_PIXEL_SCALE_X * kx * g * (float(p.horizontal) * .01f) / 8.0f;
        point.afterY += tuning::patternY(v.y, anchor, p) * BASE_PIXEL_SCALE_Y * ky * g / 8.0f;
        out.points[i] = point;
    }
}
