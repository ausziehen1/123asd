#pragma once
#include "TuningConfig.h"

namespace tuning {
// EngineTask owns this cache. Runtime calibration is immutable until reboot.
struct TickMathCache {
  uint32_t lastDt = 0;
  int lastMicroMs = -1, lastStrength = -1;
  bool lastLong = false;
  float microAlpha = 1, strength = 0, horizontalStrength = 0, noise = 1;

  float prepareMicro(uint32_t dtUs, int microMs) {
    if (lastDt != dtUs || lastMicroMs != microMs) {
      lastDt = dtUs;
      lastMicroMs = microMs;
      microAlpha = microMs == 0
                       ? 1.0f
                       : float(dtUs) / (float(microMs) * 1000.0f + float(dtUs));
    }
    return microAlpha;
  }
  float micro(float white, float &state) const {
    if (lastMicroMs == 0) {
      state = white;
      return white;
    }
    state += microAlpha * (white - state);
    return state;
  }
  void prepareStrength(int step, bool longMode, const Profile &p,
                       const Config &c) {
    if (lastStrength != step || lastLong != longMode) {
      lastStrength = step;
      lastLong = longMode;
      strength = strengthMultiplier(step);
      horizontalStrength = strength * (longMode ? .20f : .70f);
      noise = noiseGain(p, c, strength);
    }
  }
};
} // namespace tuning
