#pragma once
#include "ComputeTiming.h"
#ifndef ENGINE_COMPUTE_TIMING
#define ENGINE_COMPUTE_TIMING 1
#endif
#if ENGINE_COMPUTE_TIMING
#include <hal/cpu_hal.h>
#endif

namespace motion {
class TickTimer {
  uint32_t started = 0, available = 0;
  bool pending = false;

public:
  void begin() {
#if ENGINE_COMPUTE_TIMING
    started = cpu_hal_get_cycle_count();
    pending = true;
#endif
  }
  void budget(uint64_t us, uint32_t cpuMHz) {
    available = !cpuMHz || us > UINT32_MAX / cpuMHz ? UINT32_MAX
                                                    : uint32_t(us) * cpuMHz;
  }
  void finish(ComputeTiming &out, bool holding) {
#if ENGINE_COMPUTE_TIMING
    if (!pending)
      return;
    pending = false;
    if (holding)
      out.add(uint32_t(cpu_hal_get_cycle_count() - started), available);
#else
    (void)out;
    (void)holding;
#endif
  }
};

// Finish all continue/exit paths. finishHold() can close a tick before
// publishing; the destructor is then a no-op. No allocation, locking,
// formatting, or clock API.
struct TickTimerGuard {
  TickTimer &timer;
  ComputeTiming &out;
  bool &holding;
  TickTimerGuard(TickTimer &t, ComputeTiming &o, bool &h)
      : timer(t), out(o), holding(h) {}
  ~TickTimerGuard() { timer.finish(out, holding); }
};
} // namespace motion
