#pragma once
#include "MotionReport.h"
#include "TuningConfig.h"
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#ifndef ENGINE_TRACE_SAMPLES
#define ENGINE_TRACE_SAMPLES 4096
#endif
static_assert(ENGINE_TRACE_SAMPLES >= 128 && ENGINE_TRACE_SAMPLES <= 8192,
              "Trace capacity must be 128..8192 samples in internal RAM");

namespace motion {
struct TraceSample {
  uint32_t tickUs;
  int16_t x, y;
};
static_assert(sizeof(TraceSample) == 8,
              "Trace sample must occupy exactly 8 bytes");
enum class TraceState : uint8_t {
  OFF,
  ARMED,
  RECORDING,
  DONE,
  FULL,
  TIME_LIMIT
};

// Single writer (EngineTask); readers are allowed only after the pause
// handshake. Exactly one next hold is captured. Further holds never overwrite a
// frozen trace.
struct TraceCapture {
  TraceSample samples[ENGINE_TRACE_SAMPLES];
  tuning::Config config;
  Report report;
  uint64_t startedUs = 0;
  uint32_t count = 0;
  TraceState state = TraceState::OFF;
  bool finished = false;

  void arm(bool enabled) {
    state = enabled ? TraceState::ARMED : TraceState::OFF;
  }
  void begin(uint32_t sequence, uint64_t at, const tuning::Config &c,
             uint16_t strength) {
    if (state != TraceState::ARMED)
      return;
    config = c;
    config.strength = strength;
    report = Report{};
    report.sequence = sequence;
    startedUs = at;
    count = 0;
    finished = false;
    state = TraceState::RECORDING;
  }
  void queued(int16_t x, int16_t y, uint64_t tickUs) {
    if (state != TraceState::RECORDING)
      return;
    if (count == ENGINE_TRACE_SAMPLES) {
      state = TraceState::FULL;
      return; // freeze: no overwrite, wrap, allocation, or delay
    }
    if (tickUs < startedUs || tickUs - startedUs > UINT32_MAX) {
      state = TraceState::TIME_LIMIT;
      return;
    }
    samples[count++] = {uint32_t(tickUs - startedUs), x, y};
  }
  void finish(const Report &r) {
    if (!finished && report.sequence && r.sequence == report.sequence &&
        state != TraceState::OFF && state != TraceState::ARMED) {
      report = r;
      if (state == TraceState::RECORDING)
        state = TraceState::DONE;
      finished = true;
    }
  }
  bool truncated() const {
    return state == TraceState::FULL || state == TraceState::TIME_LIMIT;
  }
};

// Fixed-size CSV records permit stateless, bounded-memory HTTP streaming,
// including callbacks with a buffer smaller than one row. Values are decimal,
// signed X/Y.
static constexpr size_t TRACE_CSV_ROW_BYTES = 25;
static constexpr char TRACE_CSV_HEADER[] = "t_us,dx,dy\n";
inline size_t traceCsvSize(const TraceCapture &t) {
  return sizeof(TRACE_CSV_HEADER) - 1 + size_t(t.count) * TRACE_CSV_ROW_BYTES;
}
inline size_t traceCsvRead(const TraceCapture &t, uint8_t *buffer,
                           size_t maxLen, size_t index) {
  const size_t total = traceCsvSize(t);
  if (index >= total)
    return 0;
  size_t written = 0;
  while (written < maxLen && index < total) {
    const char *text;
    size_t length, offset;
    char row[TRACE_CSV_ROW_BYTES + 1];
    if (index < sizeof(TRACE_CSV_HEADER) - 1) {
      text = TRACE_CSV_HEADER;
      length = sizeof(TRACE_CSV_HEADER) - 1;
      offset = index;
    } else {
      const size_t at = index - (sizeof(TRACE_CSV_HEADER) - 1);
      const auto &s = t.samples[at / TRACE_CSV_ROW_BYTES];
      snprintf(row, sizeof(row), "%010lu,%+06d,%+06d\n",
               (unsigned long)s.tickUs, int(s.x), int(s.y));
      text = row;
      length = TRACE_CSV_ROW_BYTES;
      offset = at % TRACE_CSV_ROW_BYTES;
    }
    size_t take = length - offset;
    if (take > maxLen - written)
      take = maxLen - written;
    memcpy(buffer + written, text + offset, take);
    written += take;
    index += take;
  }
  return written;
}
} // namespace motion
