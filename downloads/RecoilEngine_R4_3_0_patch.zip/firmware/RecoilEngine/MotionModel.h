#pragma once
#include "EngineSafety.h"
#include "TuningConfig.h"

namespace movement {
struct Pair {
  float x, y;
};

// A separate non-cryptographic stream for motion noise. Hardware entropy seeds
// it once per hold; preview uses a fixed seed for stable slider comparisons.
struct Noise {
  uint32_t rng = 1, lastDt = 0;
  float driftX = 0, driftY = 0, microX = 0, microY = 0, alpha = 0;
  void reset(uint32_t seed) {
    rng = seed ? seed : 1;
    lastDt = 0;
    driftX = driftY = microX = microY = 0;
  }
  float white() {
    rng ^= rng << 13;
    rng ^= rng >> 17;
    rng ^= rng << 5;
    return float(rng & 0x00ffffffu) * (1.0f / 8388607.5f) - 1.0f;
  }
  Pair step(uint32_t dtUs, const R32TimeDynamics &d, int percent) {
    if (lastDt != dtUs) {
      lastDt = dtUs;
      alpha = float(dtUs) / (12000.0f + float(dtUs));
    }
    driftX = d.driftRho * driftX + d.driftInnovation * white() * .08f;
    driftY = d.driftRho * driftY + d.driftInnovation * white() * .08f;
    microX += alpha * (white() - microX);
    microY += alpha * (white() - microY);
    const float gain = float(percent) * .01f;
    return {(driftX + microX * .10f * d.microScale) * gain,
            (driftY + microY * .10f * d.microScale) * gain};
  }
};

// Both the engine and preview call this function. Independent noise is added
// AFTER all geometry scales and geometry filtering. Vertical=0 bypasses the
// entire original Y envelope/filter and uses a constant per-time basis instead.
inline Pair compose(float patternX, float patternY, float flatY,
                    const tuning::Profile &p, Pair noise, float dtTicks,
                    float alpha, float nominalAlpha, float &filteredX,
                    float &filteredY) {
  if (patternX == 0 && patternY == 0 && flatY == 0) {
    filteredX = filteredY = 0;
    return noise;
  }
  float x = 0, y = 0;
  if (p.horizontal)
    x = recoil::filterIncrement(patternX * (float(p.horizontal) * .01f),
                                dtTicks, alpha, nominalAlpha, filteredX);
  else
    filteredX = 0;
  if (p.vertical)
    y = recoil::filterIncrement(patternY, dtTicks, alpha, nominalAlpha,
                                filteredY);
  else
    filteredY = 0;
  const float original = float(p.vertical) * .01f;
  return {x + noise.x, flatY + (y - flatY) * original + noise.y};
}
} // namespace movement
