#pragma once
#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace tuning {
// Counts are zero based: start 0..5, body 6..17, tail 18..29 (also on first
// pass).
static constexpr int BODY_FIRST = 6;
static constexpr int TAIL_FIRST = 18;
static constexpr int STRENGTH_STEPS =
    150; // 150 intervals, positions 0..150 inclusive
inline float strengthMultiplier(int step) { return float(step) * 0.02f; }
struct Profile {
  int16_t horizontal = 100;
  int16_t vertical = 100;
  int16_t start = 0;
  int16_t body = 0;
  int16_t tail = 0;
  int16_t noise = 100; // amplitude relative to the R4 noise constants, 0..200%
  int16_t microMs =
      12; // legacy schema3 import only; runtime noise uses fixed 12 ms
};
inline bool valid(const Profile &p) {
  return p.horizontal >= 0 && p.horizontal <= 100 && p.vertical >= 0 &&
         p.vertical <= 100 && p.start >= -100 && p.start <= 100 &&
         p.body >= -100 && p.body <= 100 && p.tail >= -100 && p.tail <= 100 &&
         p.noise >= 0 && p.noise <= 200 && p.microMs >= 0 && p.microMs <= 100;
}
inline bool equal(const Profile &a, const Profile &b) {
  return a.horizontal == b.horizontal && a.vertical == b.vertical &&
         a.start == b.start && a.body == b.body && a.tail == b.tail &&
         a.noise == b.noise && a.microMs == b.microMs;
}
inline float sectionGain(const Profile &p, int shot) {
  const int percent = shot < BODY_FIRST   ? p.start
                      : shot < TAIL_FIRST ? p.body
                                          : p.tail;
  return float(100 + percent) *
         0.01f; // -100 => 0, 0 => 1, +100 => 2; never divide by gain
}
inline float patternY(float presetY, float anchorY, const Profile &p) {
  if (p.vertical == 100)
    return presetY;
  return anchorY + (presetY - anchorY) * (float(p.vertical) * 0.01f);
}
// Strict ASCII decimal, bounded before multiply; rejects whitespace, floats,
// NaN, suffixes.
inline bool parseInt(const char *s, int min, int max, int &out) {
  if (!s || !*s)
    return false;
  const bool neg = *s == '-';
  if (neg && !*++s)
    return false;
  unsigned n = 0;
  do {
    if (*s < '0' || *s > '9' || n > 100000000u)
      return false;
    n = n * 10u + unsigned(*s - '0');
    if (n > 1000000000u)
      return false;
  } while (*++s);
  const int value = neg ? -int(n) : int(n);
  if (value < min || value > max)
    return false;
  out = value;
  return true;
}

// One NVS blob for both modes: explicit endian/layout, schema tag and CRC32.
// No compiler struct padding is persisted. NVS putBytes commits one key
// atomically.
static constexpr size_t BLOB_SIZE = 32;
inline uint32_t crc32(const uint8_t *data, size_t n) {
  uint32_t crc = 0xffffffffu;
  while (n--) {
    crc ^= *data++;
    for (unsigned b = 0; b < 8; ++b)
      crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
  }
  return ~crc;
}
inline void encode(const Profile (&p)[2], uint8_t (&out)[BLOB_SIZE],
                   uint16_t strength = STRENGTH_STEPS) {
  memset(out, 0, BLOB_SIZE);
  memcpy(out, "S3T4", 4);
  out[4] = 2;
  out[5] = uint8_t(strength);
  out[6] = uint8_t(strength >> 8);
  size_t at = 8;
  for (const auto &mode : p) {
    const int16_t fields[] = {mode.horizontal, mode.vertical, mode.start,
                              mode.body, mode.tail};
    for (int16_t value : fields) {
      const uint16_t word = uint16_t(value);
      out[at++] = uint8_t(word);
      out[at++] = uint8_t(word >> 8);
    }
  }
  const uint32_t crc = crc32(out, 28);
  for (unsigned b = 0; b < 4; ++b)
    out[28 + b] = uint8_t(crc >> (8 * b));
}
inline bool decode(const uint8_t *in, size_t n, Profile (&out)[2],
                   uint16_t *strength = nullptr) {
  if (n != BLOB_SIZE || memcmp(in, "S3T4", 4) || in[4] != 2 || in[7])
    return false;
  const uint16_t storedStrength = uint16_t(in[5]) | (uint16_t(in[6]) << 8);
  if (storedStrength > STRENGTH_STEPS)
    return false;
  uint32_t crc = 0;
  for (unsigned b = 0; b < 4; ++b)
    crc |= uint32_t(in[28 + b]) << (8 * b);
  if (crc != crc32(in, 28))
    return false;
  Profile staged[2];
  size_t at = 8;
  for (auto &p : staged) {
    int16_t *fields[] = {&p.horizontal, &p.vertical, &p.start, &p.body,
                         &p.tail};
    for (auto field : fields) {
      const uint16_t word = uint16_t(in[at]) | (uint16_t(in[at + 1]) << 8);
      at += 2;
      *field = int16_t(word < 32768u ? int(word) : int(word) - 65536);
    }
    if (!valid(p))
      return false;
  }
  out[0] = staged[0];
  out[1] = staged[1];
  if (strength)
    *strength = storedStrength;
  return true;
}
} // namespace tuning
