#pragma once
#include "EngineeringConfig.h"
#include "TuningConfig.h"
#include <atomic>
#include <stdint.h>

namespace engineering {
enum class Phase : uint8_t {
  PLAY,
  WAIT_PAUSE,
  TUNING,
  SAVING_EXIT,
  STOPPING,
  FAULT
};
extern std::atomic<bool> pauseRequested;
extern std::atomic<bool> pauseGranted;
// Called before creating either task; no AP/server/TCP initialization here.
bool begin();
// Setup migration, called only before task creation.
int adoptLegacyStrength(int fallbackStep);
bool bootEnabled();
// Single writer for these operations: ControlTask, Core 0.
void buttonPressed(uint32_t nowMs, bool enabled = true);
void service(uint32_t nowMs, bool baseSettingsSaved, int workingMode = 0);
Phase phase();
bool active();
bool storageFault();
// Immutable after begin(); HTTP only edits a separate draft, applied by reboot.
const tuning::Profile &runtimeProfile(bool longMode);
const tuning::Config &runtimeConfig();
void setLastPattern(bool longMode, uint8_t pattern);
uint8_t lastPattern(bool longMode);
struct PreviewPoint {
  float x, y, phase;
  uint32_t timeUs;
};
struct Preview {
  static constexpr unsigned COUNT = 1208;
  unsigned count = 0;
  int32_t minX = 0, maxX = 0, minY = 0, maxY = 0;
  uint32_t durationMs = 0, tapUs = 0, sampleMs = 0;
  float targetPercent[3] = {100, 100, 100};
  float autoPercent[3] = {100, 100, 100};
  PreviewPoint points[COUNT];
};
// Implemented by the sketch, reusing its actual banks/spline, called only while
// paused.
void buildPreview(bool longMode, int pattern, const tuning::Config &config,
                  Preview &out);
} // namespace engineering
