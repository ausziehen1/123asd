#pragma once
#include <Arduino.h>
static const char ENGINEERING_HTML[] PROGMEM = R"rawliteral(<!doctype html>
<html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RecoilEngine · Настройка</title>
<style>
:root{color-scheme:dark;font:15px/1.5 system-ui,sans-serif;background:#10141c;color:#e8edf5}*{box-sizing:border-box}body{max-width:1180px;margin:auto;padding:26px 20px}h1{font-size:26px;margin:0}p{margin:8px 0;color:#aab7ca}header{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:18px}.version{color:#87a6ca;font-size:12px;letter-spacing:.12em}.layout{display:grid;grid-template-columns:370px 1fr;gap:20px;align-items:start}.panel{background:#19212e;border:1px solid #303d51;border-radius:14px;padding:20px}nav{display:flex;gap:8px;margin:18px 0}button,.file{font:inherit;cursor:pointer;border:1px solid #43546d;border-radius:8px;padding:9px 14px;background:#23334a;color:#e8edf5}button[aria-selected=true]{background:#aacbf1;color:#112038}.row{padding:14px 0;border-bottom:1px solid #2d394c}.row:last-child{border:0}.line{display:flex;justify-content:space-between;gap:12px}output{color:#a9d5ff;font-variant-numeric:tabular-nums;white-space:nowrap}input[type=range]{width:100%;accent-color:#a9d5ff;margin:12px 0 4px}small{display:block;color:#99a9bf;font-size:12px;line-height:1.5}.section{font-size:13px;color:#9bb1ce;margin:22px 0 0}.start{color:#f2b66d}.body{color:#92c8ff}.tail{color:#92d8ad}.legend{display:flex;flex-wrap:wrap;gap:14px;margin:14px 0}.legend span:before{content:"● ";font-size:13px}#status{padding:12px 15px;border-left:3px solid #9bc9fb;background:#19212e;margin-bottom:20px;min-height:46px}.error{border-color:#ffac8b!important;color:#ffbc9e}svg{display:block;width:100%;height:auto;background:#101722;border-radius:10px;margin-top:16px}polyline{fill:none;stroke-width:2;stroke-linejoin:round;stroke-linecap:round;vector-effect:non-scaling-stroke}.gridline{stroke:#263347;stroke-width:1}svg text{fill:#8da1bc;font:11px system-ui}input[type=number]{font:inherit;background:#101722;border:1px solid #43546d;border-radius:7px;padding:7px;color:#e8edf5;width:80px}footer{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:20px 0}#file{max-width:230px}button:disabled,input:disabled{opacity:.45;cursor:default}.preview{position:sticky;top:20px}#previewInfo{min-height:23px;font-size:13px;color:#aac0dd}@media(max-width:820px){.layout{grid-template-columns:1fr}.preview{position:static}header{align-items:start;flex-direction:column}}
</style>
<body><header><div><div class="version">RECOILENGINE R4.4</div><h1>Настройка движения</h1></div><small id="workingMode"></small></header>
<div id="status" role="status" aria-live="polite">Подключение…</div>
<div class="layout"><section class="panel">
<div class="row"><div class="line"><label for="strength">Общая сила · темп</label><output id="strengthValue"></output></div><input id="strength" type="range" min="0" max="150" step="1" value="50" disabled><small>0,00–3,00×. 1× — исходный темп; больше — тот же паттерн быстрее. При 0× основа остановлена, независимый шум остаётся. Полное выключение — FN.</small></div>
<nav aria-label="Редактируемый режим"><button id="close" aria-selected="true" disabled>Ближний</button><button id="long" aria-selected="false" disabled>Дальний</button></nav>
<div class="row"><div class="line"><label for="horizontal">Горизонталь основы</label><output id="horizontalValue"></output></div><input id="horizontal" type="range" min="0" max="300" step="1" disabled><small>0% — основа X убрана; 100% — оригинал; 300% — ×3. Направление сохраняется. Шум по X независим.</small></div>
<div class="row"><div class="line"><label for="vertical">Сглаживание вертикали</label><output id="verticalValue"></output></div><input id="vertical" type="range" min="0" max="100" step="1" disabled><small>0% — оригинальная форма; 100% — равномерная вертикальная основа. Три регулятора ниже пересчитываются автоматически; ручная доводка сохраняется отдельно.</small></div>
<div class="row"><div class="line"><label for="noise">Интенсивность шума</label><output id="noiseValue"></output></div><input id="noise" type="range" min="0" max="200" step="1" disabled><small>0% — выключен, 100% — базовый уровень. Не зависит от темпа, горизонтали, сглаживания и трёх участков. Только 0% здесь полностью отключает дополнительный шум.</small></div>
<p class="section">Вертикальное смещение участков</p>
<div class="row"><div class="line"><label for="start" class="start">Начало · 1–6</label><output id="startValue"></output></div><input id="start" type="range" min="0" max="300" step="1" disabled></div>
<div class="row"><div class="line"><label for="body" class="body">Тело · 7–18</label><output id="bodyValue"></output></div><input id="body" type="range" min="0" max="300" step="1" disabled></div>
<div class="row"><div class="line"><label for="tail" class="tail">Хвост · 19–30 и повторения</label><output id="tailValue"></output></div><input id="tail" type="range" min="0" max="300" step="1" disabled><small>100% — исходное смещение участка, 300% — ×3. Показано автоматическое значение плюс ваша поправка. Регуляторы относятся к вертикали; шум независим.</small></div>
<button id="resetTrims" disabled>Сбросить ручные поправки</button>
</section><section class="panel preview">
<div class="line"><strong>Траектория</strong><label for="pattern">Паттерн <input id="pattern" type="number" min="0" max="79" step="1" value="0" disabled></label></div>
<div class="legend"><span class="start">Начало</span><span class="body">Тело</span><span class="tail">Хвост</span></div>
<div id="previewInfo"></div>
<svg viewBox="0 0 700 480" role="img" aria-label="Предпросмотр паттерна с цветными участками">
<path d="M60 30H660M60 130H660M60 230H660M60 330H660M60 430H660M60 30V430M210 30V430M360 30V430M510 30V430M660 30V430" class="gridline" fill="none"/>
<polyline id="pathStart" stroke="#f2b66d"/><polyline id="pathBody" stroke="#92c8ff"/><polyline id="pathTail" stroke="#92d8ad"/>
<path id="timeMarks" fill="#dce7f5" opacity=".8"/>
<text id="xMin" x="60" y="454"></text><text id="xMax" x="660" y="454" text-anchor="end"></text>
<text id="yMin" x="52" y="34" text-anchor="end"></text><text id="yMax" x="52" y="434" text-anchor="end"></text><text x="360" y="474" text-anchor="middle">X · HID</text><text x="14" y="230">Y</text>
</svg>
<small>Одинаковый масштаб X/Y: небольшие отклонения не растягиваются отдельно. Координаты рассчитаны после округления HID. Полный расчёт — каждые 1 мс, на рисунке показана выборка точек. Метки времени равномерны с точностью до этой выборки. Шум воспроизводимый для сравнения настроек.</small>
<p><small>Сначала показан последний использованный паттерн режима. Номер можно изменить для просмотра. В работе выбор паттерна остаётся автоматическим; случайные значения могут отличаться. Показаны первый проход и один повтор хвоста; при темпе 0× — 3 секунды шума. Это выходные единицы HID, без чувствительности игры.</small></p>
</section></div>
<footer><button id="export" disabled>Экспорт настроек</button><label class="file" for="file">Импорт JSON <input id="file" type="file" accept=".json,application/json" disabled></label></footer>
<small>Настройка приостановила HID-движение. Изменения сохраняются автоматически. После сообщения «Сохранено» выйдите кнопкой GPIO9: устройство перезапустится и применит настройки.</small>
<script>
'use strict';
const $ = id => document.getElementById(id);
const clone = x => JSON.parse(JSON.stringify(x));
const profileKeys = ['horizontal','vertical','noise'];
const sectionKeys=['start','body','tail'];
let targets=[null,null];
const automaticPercent=(target,smoothing)=>100+Math.floor(((Math.round(target*100)-10000)*smoothing+5000)/10000);
let config=null,mode=0,revision=0,savedRevision=0,token='',ready=false,failed=false;
let busy=false,pending=false,exclusive=false,closing=false,previewBusy=false;
let timer,previewTimer,selected=[0,0],lastState=null,viewEpoch=0,lastPlotRevision=-1;
function message(text,error=false){$('status').textContent=text;$('status').classList.toggle('error',error);}
function enable(){
  for(const e of document.querySelectorAll('input,button')) e.disabled=!ready||failed||exclusive;
  for(const k of sectionKeys)$(k).disabled=!ready||failed||exclusive||!targets[mode];
  $('export').disabled=$('file').disabled=!ready||failed||busy||pending||exclusive;
}
function draw(){
  $('strength').value=config.strength;
  $('strengthValue').textContent=(config.strength*.02).toFixed(2).replace('.',',')+'×';
  const p=config.profiles[mode];
  for(const k of profileKeys){$(k).value=p[k];$(k+'Value').textContent=p[k]+'%';}
  for(let i=0;i<3;i++){
    const k=sectionKeys[i],automatic=automaticPercent((targets[mode]||[100,100,100])[i],p.vertical);
    const v=Math.round(Math.max(0,Math.min(300,automatic+p[k])));
    $(k).value=v;$(k+'Value').textContent=v+'%';
  }
  ['close','long'].forEach((id,i)=>$(id).setAttribute('aria-selected',String(i===mode)));
  $('pattern').value=selected[mode];enable();
}
async function api(url,options={}){
  const control=new AbortController(),timeout=setTimeout(()=>control.abort(),8000);
  try{
    const response=await fetch(url,{cache:'no-store',...options,signal:control.signal});
    const data=await response.json();
    if(!response.ok){const e=new Error(data.error||'HTTP '+response.status);e.status=response.status;throw e;}
    return data;
  }finally{clearTimeout(timeout);}
}
function fail(e){failed=true;ready=false;enable();message(e.message+' Подключитесь к точке доступа и обновите страницу.',true);}
function showState(s){
  if(s.revision<revision)return;
  lastState=s;savedRevision=s.savedRevision;
  $('workingMode').textContent='Рабочий режим FN: '+(s.workingMode===0?'Ближний':'Дальний');
  if(s.phase!=='tuning'){closing=true;ready=false;enable();message(s.storageError?'Выход задержан: '+s.errorCode:'Сохранение и выход…',s.storageError);return;}
  if(closing)return;
  if(s.storageError)message('Настройки ещё не сохранены: '+s.errorCode,true);
  else if(busy||pending)message('Отправка изменений…');
  else if(savedRevision!==revision)message('Принято · сохранение…');
  else message('Сохранено · выход кнопкой GPIO9'+(s.migrated?' · прежние настройки перенесены':''));
  enable();
}
function changed(){
  if(!ready)return;
  pending=true;draw();message('Отправка изменений…');
  queueSend();schedulePreview();
}
function queueSend(){if(timer==null)timer=setTimeout(()=>{timer=null;return pump();},60);}
async function pump(){
  if(!ready||failed||busy||exclusive||!pending)return;
  pending=false;busy=true;const sent=clone(config);enable();
  try{
    const s=await api('/update',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Tune-Token':token},
      body:new URLSearchParams({revision:String(revision),document:JSON.stringify({schema:5,config:sent})})});
    revision=s.revision;busy=false;showState(s);
    if(pending)queueSend();schedulePreview();
  }catch(e){busy=false;fail(e);}
}
for(const k of profileKeys)$(k).addEventListener('input',()=>{if(!ready)return;config.profiles[mode][k]=Number($(k).value);changed();});
for(let i=0;i<3;i++)$(sectionKeys[i]).addEventListener('input',()=>{
  if(!ready)return;
  const p=config.profiles[mode],automatic=automaticPercent((targets[mode]||[100,100,100])[i],p.vertical);
  p[sectionKeys[i]]=Math.round(Number($(sectionKeys[i]).value)-automatic);changed();
});
$('resetTrims').addEventListener('click',()=>{if(!ready)return;for(const k of sectionKeys)config.profiles[mode][k]=0;changed();});
$('strength').addEventListener('input',()=>{if(!ready)return;config.strength=Number($('strength').value);changed();});
['close','long'].forEach((id,i)=>$(id).addEventListener('click',()=>{mode=i;viewEpoch++;lastPlotRevision=-1;draw();schedulePreview();}));
$('pattern').addEventListener('change',()=>{
  const n=Number($('pattern').value);
  if(!Number.isInteger(n)||n<0||n>79){message('Номер паттерна: 0–79.',true);return;}
  selected[mode]=n;targets[mode]=null;draw();viewEpoch++;lastPlotRevision=-1;schedulePreview();
});
function schedulePreview(){if(previewTimer==null)previewTimer=setTimeout(()=>{previewTimer=null;return loadPreview();},120);}
function plot(data){
  if(!Array.isArray(data.points)||!data.points.length)return;
  const points=data.points,b=data.bounds;
  const xmin=Math.min(0,b[0]),xmax=Math.max(0,b[1]);
  const ymin=Math.min(0,b[2]),ymax=Math.max(0,b[3]);
  const scale=Math.min(600/Math.max(xmax-xmin,1),400/Math.max(ymax-ymin,1));
  const cx=(xmin+xmax)/2,cy=(ymin+ymax)/2;
  const xy=p=>(360+(p[0]-cx)*scale).toFixed(2)+','+(230+(p[1]-cy)*scale).toFixed(2);
  const groups=[[],[],[]];
  for(let i=0;i<points.length;i++){
    const p=points[i],group=p[2]<6?0:p[2]<18?1:2;
    if(i&&points[i-1][2]<(group===1?6:18)&&group>0)groups[group].push(points[i-1]);
    groups[group].push(p);
  }
  for(let i=0;i<3;i++)$('path'+['Start','Body','Tail'][i]).setAttribute('points',groups[i].map(xy).join(' '));
  const markMs=Math.max(100,Math.ceil(data.durationMs/3000)*100);
  let lastMark=-1;
  const marks=points.filter(p=>{const n=Math.floor(p[3]/(markMs*1000));if(n===lastMark)return false;lastMark=n;return true;});
  $('timeMarks').setAttribute('d',marks.map(p=>{const pos=xy(p).split(',');return 'M'+pos[0]+' '+pos[1]+'m-2,0a2,2 0 1,0 4,0a2,2 0 1,0 -4,0';}).join(' '));
  $('xMin').textContent=(cx-300/scale).toFixed(1);$('xMax').textContent=(cx+300/scale).toFixed(1);
  $('yMin').textContent=(cy-200/scale).toFixed(1);$('yMax').textContent=(cy+200/scale).toFixed(1);
  $('previewInfo').textContent=(data.mode===0?'Ближний':'Дальний')+' · паттерн '+data.pattern+' · '+(data.durationMs/1000).toFixed(2)+' с · метки '+markMs+' мс · старт '+(data.tapUs/1000).toFixed(1)+' мс';
}
async function loadPreview(){
  if(!ready||failed||exclusive||previewBusy)return;
  const m=mode,p=selected[mode],epoch=viewEpoch;previewBusy=true;
  try{
    const data=await api('/preview?mode='+(m===0?'close':'long')+'&pattern='+p);
    if(m===mode&&p===selected[mode]&&epoch===viewEpoch&&data.revision>=lastPlotRevision){targets[m]=data.targets;draw();plot(data);lastPlotRevision=data.revision;}
    else schedulePreview();
  }catch(e){if(!closing)message('Предпросмотр: '+e.message,true);}
  finally{previewBusy=false;if(ready&&(pending||busy||lastPlotRevision!==revision))schedulePreview();}
}
$('export').addEventListener('click',async()=>{
  if(!ready||busy||pending)return;
  try{
    const data=await api('/export');
    const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download='RecoilEngine-settings.json';a.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(e){message('Экспорт: '+e.message,true);}
});
$('file').addEventListener('change',async()=>{
  const f=$('file').files[0];if(!f||!ready||busy||pending||exclusive)return;
  try{
    if(f.size>8192)throw new Error('Файл больше 8 КБ.');
    const document=JSON.parse(await f.text());
    if(!window.confirm('Заменить настройки обоих режимов из файла?'))return;
    exclusive=true;enable();
    const s=await api('/import',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Tune-Token':token},
      body:new URLSearchParams({revision:String(revision),document:JSON.stringify(document)})});
    config=s.config;revision=s.revision;viewEpoch++;lastPlotRevision=-1;exclusive=false;draw();showState(s);schedulePreview();
  }catch(e){
    exclusive=false;
    if(e.status&&e.status!==400)fail(e);else{enable();message('Импорт: '+e.message,true);}
  }finally{$('file').value='';}
});
async function init(){
  try{
    const s=await api('/api/config');config=s.config;revision=s.revision;token=s.token;
    selected=Array.isArray(s.patterns)?s.patterns.slice():[0,0];
    ready=true;draw();showState(s);schedulePreview();
  }catch(e){fail(e);}
}
setInterval(async()=>{
  if(failed||exclusive)return;
  try{
    const s=await api('/api/config');
    if(s.revision>revision&&!busy&&!pending){fail(new Error('Настройки изменены другой вкладкой.'));return;}
    showState(s);
  }catch(e){if(closing){ready=false;enable();message('Настройка завершена. Для нового входа нажмите GPIO9 и обновите страницу.');}else fail(e);}
},1200);
init();
</script></body></html>)rawliteral";

