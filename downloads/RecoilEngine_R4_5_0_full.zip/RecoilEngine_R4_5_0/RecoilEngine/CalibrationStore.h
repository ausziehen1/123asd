#pragma once
#include "TuningConfig.h"
#include <Preferences.h>
namespace tuning {
enum class StoreError : uint8_t {
  NONE,
  OPEN,
  INVALID,
  WRITE_A,
  WRITE_B,
  VERIFY_A,
  VERIFY_B
};
class CalibrationStore {
  Preferences &prefs;
  bool opened = false, slots[2] = {false, false},
       legacySlots[2] = {false, false};
  int active = -1;
  uint32_t generation = 0;
  bool readSlot(int index, Config &c, uint32_t &g) {
    uint8_t blob[CONFIG_BLOB_SIZE];
    const char *key = index ? "b" : "a";
    const bool ok = prefs.getBytesLength(key) == sizeof(blob) &&
                    prefs.getBytes(key, blob, sizeof(blob)) == sizeof(blob) &&
                    decodeConfig(blob, sizeof(blob), c, g);
    legacySlots[index] = ok && blob[4] < 6;
    return ok;
  }
  bool writeSlot(int index, const Config &c, uint32_t gen) {
    uint8_t blob[CONFIG_BLOB_SIZE], readback[CONFIG_BLOB_SIZE];
    encodeConfig(c, gen, blob);
    const char *key = index ? "b" : "a";
    if (prefs.putBytes(key, blob, sizeof(blob)) != sizeof(blob)) {
      error = index ? StoreError::WRITE_B : StoreError::WRITE_A;
      return false;
    }
    if (prefs.getBytesLength(key) != sizeof(blob) ||
        prefs.getBytes(key, readback, sizeof(readback)) != sizeof(readback) ||
        memcmp(blob, readback, sizeof(blob))) {
      error = index ? StoreError::VERIFY_B : StoreError::VERIFY_A;
      return false;
    }
    slots[index] = true;
    return true;
  }

public:
  StoreError error = StoreError::NONE;
  bool recovered = false, migrated = false, loaded = false;
  explicit CalibrationStore(Preferences &p) : prefs(p) {}
  bool open() {
    if (!opened)
      opened = prefs.begin("recoil_tune", false);
    if (!opened)
      error = StoreError::OPEN;
    return opened;
  }
  void close() {
    if (opened)
      prefs.end();
    opened = false;
  }
  Config load() {
    Config result;
    if (!open())
      return result;
    Config a, b;
    uint32_t ga = 0, gb = 0;
    slots[0] = readSlot(0, a, ga);
    slots[1] = readSlot(1, b, gb);
    if (slots[0] || slots[1]) {
      active = slots[1] && (!slots[0] || generationNewer(gb, ga)) ? 1 : 0;
      result = active ? b : a;
      generation = active ? gb : ga;
      loaded = true;
      migrated = legacySlots[active];
      recovered =
          (prefs.isKey("a") && !slots[0]) || (prefs.isKey("b") && !slots[1]);
      return result;
    }
    if (prefs.isKey("config")) {
      uint8_t old[BLOB_SIZE];
      Profile p[2];
      uint16_t strength;
      if (prefs.getBytesLength("config") == sizeof(old) &&
          prefs.getBytes("config", old, sizeof(old)) == sizeof(old) &&
          decode(old, sizeof(old), p, &strength)) {
        result = legacyConfig(p, strength);
        loaded = migrated = true;
        recovered = prefs.isKey("a") || prefs.isKey("b");
        return result;
      }
    }
    if (prefs.isKey("a") || prefs.isKey("b") || prefs.isKey("config"))
      error = StoreError::INVALID;
    return result;
  }
  bool save(const Config &c) {
    if (!valid(c)) {
      error = StoreError::INVALID;
      return false;
    }
    if (!open())
      return false;
    const int target = active == 0 ? 1 : 0;
    const uint32_t next = generation + 1;
    if (!writeSlot(target, c, next))
      return false;
    active = target;
    generation = next;
    // First save/recovery creates a verified fallback too. If this fails,
    // keep the successful primary and retry later; never erase either key.
    if (!slots[1 - target] && !writeSlot(1 - target, c, next - 1))
      return false;
    error = StoreError::NONE;
    recovered = migrated = false;
    loaded = true;
    return true;
  }
  uint32_t savedGeneration() const { return generation; }
};
inline const char *storeErrorName(StoreError e) {
  switch (e) {
  case StoreError::OPEN:
    return "nvs_open";
  case StoreError::INVALID:
    return "nvs_invalid";
  case StoreError::WRITE_A:
    return "nvs_write_a";
  case StoreError::WRITE_B:
    return "nvs_write_b";
  case StoreError::VERIFY_A:
    return "nvs_verify_a";
  case StoreError::VERIFY_B:
    return "nvs_verify_b";
  default:
    return "none";
  }
}
} // namespace tuning
