#pragma once
// Momentary switch between GPIO9 and GND. Confirm GPIO9 is free on your board.
#ifndef ENGINEERING_BUTTON_PIN
#define ENGINEERING_BUTTON_PIN 9
#endif
#ifndef ENGINEERING_AP_SSID
#define ENGINEERING_AP_SSID "Keenetic-512"
#endif
// Set your own password before the first flash. WPA2-PSK, 8..63 characters.
#ifndef ENGINEERING_AP_PASSWORD
#define ENGINEERING_AP_PASSWORD "S3Tune-512!"
#endif
static_assert(sizeof(ENGINEERING_AP_PASSWORD) >= 9 && sizeof(ENGINEERING_AP_PASSWORD) <= 64,
              "AP password must contain 8..63 characters");
