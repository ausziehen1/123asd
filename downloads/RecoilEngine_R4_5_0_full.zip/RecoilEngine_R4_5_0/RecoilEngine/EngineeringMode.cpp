#include "EngineeringMode.h"
#include "CalibrationStore.h"
#include "EngineeringPage.h"
#include "PreviewWire.h"
#include "TuningJson.h"
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <WebResponseImpl.h>
#include <WiFi.h>
#include <algorithm>
#include <esp_attr.h>
#include <esp_random.h>
#include <esp_system.h>
#include <esp_wifi.h>
#include <lwip/tcp.h>
#include <memory>
#include <new>

namespace engineering {
std::atomic<bool> pauseRequested{false}, pauseGranted{false};
namespace {
std::atomic<Phase> current{Phase::PLAY};
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
std::atomic<uint8_t> viewedPattern[2]{{0}, {0}};
tuning::Config runtime;
struct Draft {
  tuning::Config config;
  uint32_t revision = 0, savedRevision = 0, changedAt = 0;
  int workingMode = 0;
  bool storageError = false, baseStorageError = false, accepting = false,
       recovered = false, migrated = false;
  uint32_t generation = 0;
  tuning::StoreError storeError = tuning::StoreError::NONE;
} draft;
Preferences storage;
tuning::CalibrationStore calibrationStore(storage);
RTC_NOINIT_ATTR uint32_t resumeCookie;
RTC_NOINIT_ATTR uint32_t faultCookie;
static constexpr uint32_t RESUME_MAGIC = 0x53335400u;
static constexpr uint32_t FAULT_MAGIC = 0x45525200u;
const char *const faultNames[] = {"none",          "ap_start",
                                  "server_memory", "http_listen",
                                  "pause_timeout", "pause_lost"};
const char *lastBootError = "none";
bool enabledAtBoot = true, enabledBeforeTuning = true, attemptedSave = false,
     noClients = false;
uint32_t phaseAt = 0, lastSaveAttempt = 0, noClientsSince = 0;
char token[33] = {};
std::atomic<const char *> systemError{"none"};
class CheckedServer : public AsyncWebServer {
public:
  CheckedServer() : AsyncWebServer(80) {}
  bool listening() { return _server.status() == LISTEN; }
};
CheckedServer *server =
    nullptr; // never delete while callbacks may exist; reclaimed by reset
Draft snapshot() {
  portENTER_CRITICAL(&mux);
  const Draft s = draft;
  portEXIT_CRITICAL(&mux);
  return s;
}
const char *phaseName() {
  switch (current.load(std::memory_order_acquire)) {
  case Phase::TUNING:
    return "tuning";
  case Phase::SAVING_EXIT:
    return "saving";
  case Phase::FAULT:
    return "fault";
  default:
    return "transition";
  }
}
bool radioOff() {
  (void)WiFi.mode(WIFI_OFF);
  const auto a = esp_wifi_stop(), b = esp_wifi_deinit();
  wifi_mode_t mode;
  return (a == ESP_OK || a == ESP_ERR_WIFI_NOT_INIT) &&
         (b == ESP_OK || b == ESP_ERR_WIFI_NOT_INIT) &&
         esp_wifi_get_mode(&mode) == ESP_ERR_WIFI_NOT_INIT;
}
void headers(AsyncWebServerResponse *r) {
  r->addHeader("Cache-Control", "no-store");
  r->addHeader("X-Content-Type-Options", "nosniff");
  r->addHeader("Connection", "close");
  r->addHeader("Content-Security-Policy",
               "default-src 'none'; script-src 'unsafe-inline'; style-src "
               "'unsafe-inline'; connect-src "
               "'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri "
               "'none'; form-action 'self'");
}
void reply(AsyncWebServerRequest *r, int status, const String &body,
           const char *type = "application/json; charset=utf-8",
           const char *filename = nullptr) {
  auto *response = r->beginResponse(status, type, body);
  headers(response);
  if (filename)
    response->addHeader("Content-Disposition",
                        String("attachment; filename=\"") + filename + "\"");
  r->send(response);
}
bool hostAllowed(AsyncWebServerRequest *r) {
  return r->host() == "192.168.4.1" || r->host() == "192.168.4.1:80";
}
bool allowed(AsyncWebServerRequest *r, bool mutation = false) {
  if (!hostAllowed(r) ||
      (mutation && ((r->hasHeader("Origin") &&
                     r->getHeader("Origin")->value() != "http://192.168.4.1") ||
                    !r->hasHeader("X-Tune-Token") ||
                    r->getHeader("X-Tune-Token")->value() != token))) {
    reply(r, 403, "{\"error\":\"Доступ запрещён\"}");
    return false;
  }
  return true;
}
void stateReply(AsyncWebServerRequest *r, const Draft &s) {
  char meta[750];
  snprintf(
      meta, sizeof(meta),
      "{\"version\":\"4.5.0\",\"schema\":6,\"phase\":\"%s\",\"revision\":%lu,"
      "\"savedRevision\":%lu,"
      "\"storageError\":%s,\"errorCode\":\"%s\",\"recovered\":%s,\"migrated\":%"
      "s,\"generation\":%lu,"
      "\"workingMode\":%d,\"token\":\"%s\",\"patterns\":[%u,%u],\"config\":",
      phaseName(), (unsigned long)s.revision, (unsigned long)s.savedRevision,
      (s.storageError || s.baseStorageError) ? "true" : "false",
      s.baseStorageError ? "nvs_fn_mode"
      : s.storageError   ? tuning::storeErrorName(s.storeError)
                         : systemError.load(),
      s.recovered ? "true" : "false", s.migrated ? "true" : "false",
      (unsigned long)s.generation, s.workingMode, token,
      unsigned(lastPattern(false)), unsigned(lastPattern(true)));
  reply(r, 200, String(meta) + tuning::configJson(s.config) + "}");
}
bool revisionParam(AsyncWebServerRequest *r, int &revision) {
  const auto *p = r->getParam("revision", true);
  return p && tuning::parseInt(p->value().c_str(), 0, 1000000000, revision);
}
void acceptConfig(AsyncWebServerRequest *r, const tuning::Config &c,
                  int revision) {
  const uint32_t now = millis();
  int error = 0;
  Draft accepted;
  portENTER_CRITICAL(&mux);
  if (!draft.accepting)
    error = 503;
  else if (draft.revision != uint32_t(revision))
    error = 409;
  else if (!tuning::equal(c, draft.config)) {
    if (draft.revision >= 1000000000u)
      error = 409;
    else {
      draft.config = c;
      ++draft.revision;
      draft.changedAt = now;
    }
  }
  accepted = draft;
  portEXIT_CRITICAL(&mux);
  if (error) {
    reply(r, error,
          error == 409
              ? "{\"error\":\"Конфликт версии; перечитайте настройки\"}"
              : "{\"error\":\"Режим настройки завершается\"}");
    return;
  }
  stateReply(r, accepted);
}
void update(AsyncWebServerRequest *r) {
  if (!allowed(r, true))
    return;
  int revision;
  const auto *document = r->getParam("document", true);
  tuning::Config staged;
  if (r->contentLength() > 8192 || r->params() != 2 ||
      !revisionParam(r, revision) || !document ||
      !tuning::parseDocument(document->value(), staged)) {
    reply(r, 400,
          "{\"error\":\"Некорректный JSON, версия или диапазон настройки\"}");
    return;
  }
  acceptConfig(r, staged, revision);
}
void resetConfig(AsyncWebServerRequest *r) {
  if (!allowed(r, true))
    return;
  int revision;
  if (r->contentLength() > 64 || r->params() != 1 ||
      !revisionParam(r, revision)) {
    reply(r, 400, "{\"error\":\"Некорректная редакция\"}");
    return;
  }
  acceptConfig(r, tuning::Config{}, revision);
}
// One buffer, allocated on demand. ControlTask may mutate it only when no
// response holds a lease. It is reclaimed by the engineering-exit reboot.
struct PreviewRequest {
  tuning::Config config;
  uint32_t revision = 0;
  bool longMode = false;
  int pattern = 0;
};
bool sameView(const PreviewRequest &a, const PreviewRequest &b) {
  return a.longMode == b.longMode && a.pattern == b.pattern;
}
bool sameRequest(const PreviewRequest &a, const PreviewRequest &b) {
  return sameView(a, b) && a.revision == b.revision;
}
PreviewRequest waitingPreview, workingPreview, completedPreview;
bool previewWaiting = false, previewReady = false, previewServed = false;
bool referencePass = false, referenceValid = false;
bool referenceLong = false;
int referencePattern = -1;
int32_t referenceBounds[4] = {0, 0, 0, 0};
uint32_t previewReadyAt = 0, previewRetryAt = 0;
std::atomic<bool> previewMemoryFault{false};
Preview *previewData = nullptr;
PreviewCursor *previewCursor = nullptr;
std::atomic<bool> previewLeased{false};

class PreviewResponse : public AsyncCallbackResponse {
  PreviewWire wire;

public:
  PreviewResponse(const Preview &data, const PreviewRequest &key)
      : AsyncCallbackResponse("application/json; charset=utf-8", 1,
                              [this](uint8_t *b, size_t n, size_t index) {
                                return wire.fill(b, n, index);
                              }),
        wire(data, key.revision, key.longMode, key.pattern) {
    _contentLength = wire.length();
  }
  ~PreviewResponse() override {
    previewLeased.store(false, std::memory_order_release);
  }
  bool valid() const { return wire.valid(); }
};

void deferPreview(const PreviewRequest &next) {
  portENTER_CRITICAL(&mux);
  if (!previewWaiting) {
    waitingPreview = next;
    previewWaiting = true;
  }
  portEXIT_CRITICAL(&mux);
}
// ControlTask only; bounded work followed by its ordinary FreeRTOS delay.
// Same-view edits are coalesced, while a running snapshot finishes so a long
// slider drag can still display intermediate acknowledged trajectories.
void servicePreview(uint32_t now) {
  if (previewLeased.load(std::memory_order_acquire))
    return;
  if (previewMemoryFault && uint32_t(now - previewRetryAt) < 1000)
    return;
  PreviewRequest next;
  bool queued = false;
  portENTER_CRITICAL(&mux);
  if (previewWaiting) {
    next = waitingPreview;
    previewWaiting = false;
    queued = true;
  }
  portEXIT_CRITICAL(&mux);
  if (queued) {
    if (previewCursor && sameView(next, workingPreview)) {
      if (!sameRequest(next, workingPreview))
        deferPreview(next);
    } else {
      bool start = true;
      portENTER_CRITICAL(&mux);
      if (previewLeased.load(std::memory_order_relaxed))
        start = false;
      else if (previewReady && sameRequest(next, completedPreview))
        start = false;
      else if (previewReady && sameView(next, completedPreview) &&
               !previewServed && uint32_t(now - previewReadyAt) < 500)
        start = false;
      if (start)
        previewReady = false;
      portEXIT_CRITICAL(&mux);
      if (!start) {
        if (!sameRequest(next, completedPreview))
          deferPreview(next);
        return;
      }
      destroyPreview(previewCursor);
      previewCursor = nullptr;
      workingPreview = next;
      if (!previewData)
        previewData = new (std::nothrow) Preview;
      if (!previewData) {
        previewMemoryFault = true;
        previewRetryAt = now;
        deferPreview(next);
        return;
      }
      referencePass = !referenceValid || referenceLong != next.longMode ||
                      referencePattern != next.pattern;
      tuning::Config config = next.config;
      if (referencePass) {
        config = tuning::Config{};
        config.profiles[0].noise = config.profiles[1].noise = 0;
      }
      previewCursor =
          createPreview(next.longMode, next.pattern, config, *previewData);
      if (!previewCursor) {
        previewMemoryFault = true;
        previewRetryAt = now;
        deferPreview(next);
        return;
      }
      previewMemoryFault = false;
    }
  }
  if (!previewCursor)
    return;
  if (!advancePreview(previewCursor, 256))
    return;
  destroyPreview(previewCursor);
  previewCursor = nullptr;
  if (referencePass) {
    referenceBounds[0] = previewData->minX;
    referenceBounds[1] = previewData->maxX;
    referenceBounds[2] = previewData->minY;
    referenceBounds[3] = previewData->maxY;
    referenceLong = workingPreview.longMode;
    referencePattern = workingPreview.pattern;
    referenceValid = true;
    referencePass = false;
    previewCursor =
        createPreview(workingPreview.longMode, workingPreview.pattern,
                      workingPreview.config, *previewData);
    if (!previewCursor) {
      previewMemoryFault = true;
      previewRetryAt = now;
      deferPreview(workingPreview);
    }
    return;
  }
  previewData->minX = std::min(previewData->minX, referenceBounds[0]);
  previewData->maxX = std::max(previewData->maxX, referenceBounds[1]);
  previewData->minY = std::min(previewData->minY, referenceBounds[2]);
  previewData->maxY = std::max(previewData->maxY, referenceBounds[3]);
  portENTER_CRITICAL(&mux);
  completedPreview = workingPreview;
  previewReady = true;
  previewServed = false;
  previewReadyAt = now;
  portEXIT_CRITICAL(&mux);
}
void preview(AsyncWebServerRequest *r) {
  if (!allowed(r))
    return;
  if (phase() != Phase::TUNING ||
      !pauseGranted.load(std::memory_order_acquire)) {
    reply(r, 503, "{\"error\":\"Движок не остановлен\"}");
    return;
  }
  const auto *mode = r->getParam("mode"), *pattern = r->getParam("pattern");
  if (!mode || (mode->value() != "close" && mode->value() != "long")) {
    reply(r, 400, "{\"error\":\"Некорректный режим\"}");
    return;
  }
  const bool isLong = mode->value() == "long";
  int index = lastPattern(isLong);
  if (pattern && !tuning::parseInt(pattern->value().c_str(), 0, 79, index)) {
    reply(r, 400, "{\"error\":\"Номер паттерна: 0–79\"}");
    return;
  }
  const Draft draft = snapshot();
  PreviewRequest requested;
  requested.config = draft.config;
  requested.revision = draft.revision;
  requested.longMode = isLong;
  requested.pattern = index;
  bool serve = false;
  PreviewRequest completed;
  portENTER_CRITICAL(&mux);
  if (!previewReady || !sameRequest(requested, completedPreview)) {
    waitingPreview = requested;
    previewWaiting = true;
  }
  if (previewReady && sameView(requested, completedPreview) &&
      !previewLeased.load(std::memory_order_relaxed)) {
    previewLeased.store(true, std::memory_order_release);
    previewServed = true;
    completed = completedPreview;
    serve = true;
  }
  portEXIT_CRITICAL(&mux);
  if (!serve) {
    if (previewMemoryFault)
      reply(r, 503,
            "{\"error\":\"Недостаточно памяти для предпросмотра; повторяем "
            "позже\"}");
    else
      reply(r, 202, "{\"pending\":true}");
    return;
  }
  auto *response = new (std::nothrow) PreviewResponse(*previewData, completed);
  if (!response) {
    previewLeased.store(false, std::memory_order_release);
    reply(r, 503, "{\"error\":\"Недостаточно памяти для ответа\"}");
    return;
  }
  if (!response->valid()) {
    delete response;
    reply(r, 503, "{\"error\":\"Предпросмотр не готов\"}");
    return;
  }
  headers(response);
  r->send(response);
}
bool startAP() {
  WiFi.persistent(false);
  const IPAddress ip(192, 168, 4, 1), mask(255, 255, 255, 0);
  if (!WiFi.mode(WIFI_AP) || !WiFi.softAPConfig(ip, ip, mask) ||
      !WiFi.softAP(ENGINEERING_AP_SSID, ENGINEERING_AP_PASSWORD, 1, false, 2)) {
    systemError = "ap_start";
    return false;
  }
  WiFi.setSleep(false);
  for (unsigned i = 0; i < 4; ++i)
    snprintf(token + i * 8, 9, "%08lx", (unsigned long)esp_random());
  server = new (std::nothrow) CheckedServer();
  if (!server) {
    systemError = "server_memory";
    return false;
  }
  server->on("/", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (!allowed(r))
      return;
    auto *response =
        r->beginResponse(200, "text/html; charset=utf-8",
                         reinterpret_cast<const uint8_t *>(ENGINEERING_HTML),
                         sizeof(ENGINEERING_HTML) - 1);
    headers(response);
    r->send(response);
  });
  server->on("/api/config", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (allowed(r))
      stateReply(r, snapshot());
  });
  server->on("/update", HTTP_POST, update);
  server->on("/import", HTTP_POST, update);
  server->on("/reset", HTTP_POST, resetConfig);
  server->on("/export", HTTP_GET, [](AsyncWebServerRequest *r) {
    if (allowed(r))
      reply(r, 200, tuning::documentJson(snapshot().config),
            "application/json; charset=utf-8", "RecoilEngine-R4.5.0.json");
  });
  server->on("/preview", HTTP_GET, preview);
  server->onNotFound([](AsyncWebServerRequest *r) {
    reply(r, 404, "{\"error\":\"Не найдено\"}");
  });
  server->begin();
  if (!server->listening()) {
    systemError = "http_listen";
    return false;
  }
  return true;
}
bool saveDraft(const Draft &s) {
  const bool ok = calibrationStore.save(s.config);
  portENTER_CRITICAL(&mux);
  draft.storageError = !ok;
  draft.storeError = calibrationStore.error;
  draft.recovered = calibrationStore.recovered;
  draft.migrated = calibrationStore.migrated;
  draft.generation = calibrationStore.savedGeneration();
  if (ok)
    draft.savedRevision = s.revision;
  portEXIT_CRITICAL(&mux);
  return ok;
}
void fault() {
  const char *why = systemError.load(std::memory_order_acquire);
  for (unsigned i = 1; i < sizeof(faultNames) / sizeof(faultNames[0]); ++i) {
    if (!strcmp(why, faultNames[i]))
      faultCookie = FAULT_MAGIC | i;
  }
  portENTER_CRITICAL(&mux);
  draft.accepting = false;
  portEXIT_CRITICAL(&mux);
  current.store(Phase::FAULT, std::memory_order_release);
  if (server)
    server->end();
  (void)radioOff();
}
void requestExit() {
  portENTER_CRITICAL(&mux);
  draft.accepting = false;
  portEXIT_CRITICAL(&mux);
  current.store(Phase::SAVING_EXIT, std::memory_order_release);
  attemptedSave = false;
}
} // namespace

bool begin() {
  const uint32_t cookie = resumeCookie;
  resumeCookie = 0;
  const uint32_t previousFault = faultCookie;
  faultCookie = 0;
  if (esp_reset_reason() == ESP_RST_SW &&
      (previousFault & 0xffffff00u) == FAULT_MAGIC &&
      (previousFault & 0xffu) < sizeof(faultNames) / sizeof(faultNames[0]))
    lastBootError = faultNames[previousFault & 0xffu];
  if (esp_reset_reason() == ESP_RST_SW && (cookie & ~1u) == RESUME_MAGIC)
    enabledAtBoot = (cookie & 1u) != 0;
  if (!radioOff())
    return false;
  runtime = calibrationStore.load();
  draft.config = runtime;
  draft.storageError = calibrationStore.error != tuning::StoreError::NONE;
  draft.storeError = calibrationStore.error;
  draft.recovered = calibrationStore.recovered;
  draft.migrated = calibrationStore.migrated;
  draft.generation = calibrationStore.savedGeneration();
  return true;
}
int adoptLegacyStrength(int fallback) {
  if (!calibrationStore.loaded)
    runtime.strength = draft.config.strength =
        uint16_t(fallback < 0     ? 0
                 : fallback > 150 ? 150
                                  : fallback);
  return runtime.strength;
}
void setLastPattern(bool longMode, uint8_t pattern) {
  if (pattern < 80)
    viewedPattern[longMode ? 1 : 0].store(pattern, std::memory_order_relaxed);
}
uint8_t lastPattern(bool longMode) {
  return viewedPattern[longMode ? 1 : 0].load(std::memory_order_relaxed);
}
bool bootEnabled() { return enabledAtBoot; }
const tuning::Profile &runtimeProfile(bool longMode) {
  return runtime.profiles[longMode ? 1 : 0];
}
const tuning::Config &runtimeConfig() { return runtime; }
Phase phase() { return current.load(std::memory_order_acquire); }
bool active() { return phase() != Phase::PLAY; }
bool storageFault() {
  const auto s = snapshot();
  return s.storageError || s.baseStorageError;
}
void buttonPressed(uint32_t now, bool enabled) {
  if (phase() == Phase::PLAY) {
    enabledBeforeTuning = enabled;
    phaseAt = now;
    current.store(Phase::WAIT_PAUSE, std::memory_order_release);
    pauseRequested.store(true, std::memory_order_release);
  } else if (phase() == Phase::TUNING)
    requestExit();
  else if (phase() == Phase::FAULT) {
    resumeCookie = RESUME_MAGIC | (enabledBeforeTuning ? 1u : 0u);
    ESP.restart();
  }
}
void service(uint32_t now, bool baseSettingsSaved, int workingMode) {
  const Phase state = phase();
  if (state == Phase::PLAY || state == Phase::FAULT)
    return;
  if (state == Phase::WAIT_PAUSE) {
    if (pauseGranted.load(std::memory_order_acquire)) {
      portENTER_CRITICAL(&mux);
      draft.baseStorageError = !baseSettingsSaved;
      draft.workingMode = workingMode;
      portEXIT_CRITICAL(&mux);
      if (!baseSettingsSaved)
        return;
      current.store(Phase::TUNING, std::memory_order_release);
      portENTER_CRITICAL(&mux);
      draft.accepting = true;
      portEXIT_CRITICAL(&mux);
      noClients = true;
      noClientsSince = now;
      if (!startAP())
        fault();
    } else if (uint32_t(now - phaseAt) >= 2000) {
      systemError = "pause_timeout";
      fault();
    }
    return;
  }
  if (state == Phase::STOPPING) {
    if (uint32_t(now - phaseAt) >= 200) {
      resumeCookie = RESUME_MAGIC | (enabledBeforeTuning ? 1u : 0u);
      ESP.restart();
    }
    return;
  }
  if (!pauseGranted.load(std::memory_order_acquire)) {
    systemError = "pause_lost";
    fault();
    return;
  }
  portENTER_CRITICAL(&mux);
  draft.baseStorageError = !baseSettingsSaved;
  draft.workingMode = workingMode;
  portEXIT_CRITICAL(&mux);
  Draft s = snapshot();
  if (state == Phase::TUNING) {
    if (WiFi.softAPgetStationNum()) {
      noClients = false;
    } else {
      if (!noClients) {
        noClients = true;
        noClientsSince = now;
      }
      if (s.config.idleTimeoutSec &&
          uint32_t(now - noClientsSince) >=
              uint32_t(s.config.idleTimeoutSec) * 1000u) {
        requestExit();
        return;
      }
    }
  }
  if (state == Phase::TUNING)
    servicePreview(now);
  const bool due = !attemptedSave || uint32_t(now - lastSaveAttempt) >= 2000;
  if (s.revision != s.savedRevision && due &&
      (state == Phase::SAVING_EXIT || uint32_t(now - s.changedAt) >= 600)) {
    attemptedSave = true;
    lastSaveAttempt = now;
    (void)saveDraft(s);
    s = snapshot();
  }
  if (state == Phase::SAVING_EXIT && s.revision == s.savedRevision &&
      baseSettingsSaved) {
    if (server)
      server->end();
    calibrationStore.close();
    (void)radioOff();
    current.store(Phase::STOPPING, std::memory_order_release);
    phaseAt = now;
  }
}
} // namespace engineering
