#pragma once
// Included by the sketch after its unchanged bank/spline/time helpers.
// No GPIO, USB, Wi-Fi, NVS, heap allocation or instrumentation in this class.
namespace movement {
struct Generator {
  const tuning::Profile *profile = nullptr;
  const BulletTarget (*bank)[SHOTS_PER_SPRAY] = nullptr;
  CombatMode mode = MODE_CLOSE;
  int pattern = 0, shot = 0, laps = 0;
  bool sustain = false;
  uint32_t rng = 1, intervals[SHOTS_PER_SPRAY]{};
  uint32_t tapWindowUs = 20000;
  uint64_t heldUs = 0;
  float strength = 1, elapsed = 0, interval = 100000, inverseInterval = .00001f;
  float anchor = 0, targetMirror = 1, mirror = 1;
  float filteredX = 0, filteredY = 0, averageY = 0;
  float targetPercent[3] = {100, 100, 100};
  float autoPercent[3] = {100, 100, 100};
  float correction[3] = {1, 1, 1};
  float resumeFraction = 0, gateWeight = 1, gateWidth = .2f;
  R32CachedSpline spline;
  Noise noise;

  uint32_t random() {
    rng ^= rng << 13;
    rng ^= rng >> 17;
    rng ^= rng << 5;
    return rng;
  }
  uint32_t nextInterval() {
    const float white = float(random() & 0xffffffu) / 8388607.5f - 1;
    return uint32_t(int32_t(BASE_SHOT_INTERVAL_US) +
                    int32_t(white * INTERVAL_JITTER_US));
  }
  static float primitive(float a, float b, float c, float d, float t) {
    return t * (a + t * (b * .5f + t * (c / 3.0f + t * d * .25f)));
  }
  static Pair integral(const R32CachedSpline &s, float a, float b) {
    return {primitive(s.a.x, s.b.x, s.c.x, s.d.x, b) -
                primitive(s.a.x, s.b.x, s.c.x, s.d.x, a),
            primitive(s.a.y, s.b.y, s.c.y, s.d.y, b) -
                primitive(s.a.y, s.b.y, s.c.y, s.d.y, a)};
  }
  // Cubic startup envelope integrated into a monotone phase map. Smoothly
  // repays the initial lag by the end of the first segment, preserving
  // distance.
  float mapped(float phase) const {
    if (shot != 0 || gateWeight == 0)
      return phase;
    const float remaining = 1 - resumeFraction;
    const float q = fastClampF((phase - resumeFraction) / remaining, 0, 1);
    float z;
    if (q < gateWidth) {
      const float u = q / gateWidth;
      z = q * u * u * u * .25f;
    } else {
      const float u = (q - gateWidth) / (1 - gateWidth);
      z = q - .75f * gateWidth * (1 - easeCubic(u));
    }
    return resumeFraction + remaining * (q + gateWeight * (z - q));
  }
  void begin(const tuning::Profile &p, CombatMode m, int index, float amplitude,
             uint32_t seed, float phase = 0, bool looping = false,
             float mirrorSign = 1) {
    profile = &p;
    mode = m;
    pattern = index;
    strength = amplitude;
    bank = m == MODE_LONG ? PATTERN_LONG : PATTERN_CLOSE;
    anchor = m == MODE_LONG ? CORE_ANCHOR_LONG_Y : CORE_ANCHOR_CLOSE_Y;
    rng = seed ? seed : 1;
    heldUs = 0;
    laps = 0;
    // Separate streams keep noise independent of speed, smoothing, section
    // controls, and how many timing/loop random draws a hold consumes.
    noise.reset(seed ^ 0xa91535e7u);
    tapWindowUs = TAP_MIN_US + random() % uint32_t(TAP_MAX_US - TAP_MIN_US + 1);
    float totals[3] = {0, 0, 0}, times[3] = {0, 0, 0};
    R32CachedSpline ref;
    for (int i = 0; i < SHOTS_PER_SPRAY; ++i) {
      intervals[i] = nextInterval();
      r32PrepareSpline(ref, i, index, m, false, bank, anchor);
      const int section = i < tuning::BODY_FIRST   ? 0
                          : i < tuning::TAIL_FIRST ? 1
                                                   : 2;
      totals[section] += integral(ref, 0, 1).y * BASE_PIXEL_SCALE_Y;
      times[section] += float(intervals[i]);
    }
    averageY =
        (totals[0] + totals[1] + totals[2]) / (times[0] + times[1] + times[2]);
    const int trims[3] = {p.start, p.body, p.tail};
    for (int i = 0; i < 3; ++i) {
      const int hundredths =
          totals[i] > 1e-6f
              ? int(__builtin_lrintf(10000 * averageY * times[i] / totals[i]))
              : 10000;
      targetPercent[i] = float(hundredths) * .01f;
      autoPercent[i] = tuning::automaticPercent(hundredths, p.vertical);
      const float effective =
          fastClampF(autoPercent[i] + float(trims[i]), 0, 300);
      correction[i] = effective / fmaxf(autoPercent[i], .001f);
    }
    shot = fastClampI(int(phase), 0, SHOTS_PER_SPRAY - 1);
    sustain = looping;
    elapsed =
        fastClampF(phase - float(shot), 0, .999999f) * float(intervals[shot]);
    interval = float(intervals[shot]);
    inverseInterval = 1 / interval;
    resumeFraction = elapsed * inverseInterval;
    gateWeight = shot == 0 ? 1 - tuning::smooth5(resumeFraction) : 0;
    const float remainingRealUs = (interval - elapsed);
    gateWidth = fastClampF(float(tapWindowUs) / remainingRealUs, .00001f, .9f);
    targetMirror = mirror = mirrorSign;
    filteredX = filteredY = 0;
    spline.shot = -1;
  }
  float phase() const { return float(shot) + elapsed * inverseInterval; }
  float unwrappedPhase() const { return phase() + float(laps * 12); }
  float manualGain(float phase) const {
    const int section = phase < tuning::BODY_FIRST   ? 0
                        : phase < tuning::TAIL_FIRST ? 1
                                                     : 2;
    if (correction[section] == 0)
      return 0;
    const float boundaries[2] = {float(tuning::BODY_FIRST),
                                 float(tuning::TAIL_FIRST)};
    for (int i = 0; i < 2; ++i) {
      const float b = boundaries[i], a = correction[i], z = correction[i + 1];
      if (phase < b - .4f || phase > b + .4f || a == z)
        continue;
      if (a == 0)
        return z * tuning::smooth5((phase - b) / .4f);
      if (z == 0)
        return a * (1 - tuning::smooth5((phase - (b - .4f)) / .4f));
      return a + (z - a) * tuning::smooth5((phase - (b - .4f)) / .8f);
    }
    return correction[section];
  }
  void clearFilter() { filteredX = filteredY = 0; }
  Pair step(uint32_t dtUs) {
    const R32TimeDynamics d = r32TimeDynamics(dtUs);
    heldUs += dtUs;
    Pair base = {0, 0};
    const float virtualDt = float(dtUs);
    float left = virtualDt, flat = 0, weightedManual = 0;
    unsigned crossed = 0;
    while (left > 0 && crossed++ < 64) {
      const float amount = fminf(left, interval - elapsed);
      const float a = elapsed * inverseInterval,
                  b = (elapsed + amount) * inverseInterval;
      r32PrepareSpline(spline, shot, pattern, mode, sustain, bank, anchor);
      const Pair displacement = integral(spline, mapped(a), mapped(b));
      const float gain = manualGain(float(shot) + (a + b) * .5f);
      const float s = float(profile->vertical) * .01f;
      base.x += displacement.x;
      base.y += ((1 - s) * displacement.y * BASE_PIXEL_SCALE_Y +
                 s * averageY * amount) *
                gain;
      // The constant component bypasses the geometry filter at 100% smoothing.
      flat += s * averageY * amount * gain;
      weightedManual += gain * amount;
      elapsed += amount;
      left -= amount;
      if (elapsed >= interval - .001f) {
        elapsed = 0;
        ++shot;
        if (shot >= SHOTS_PER_SPRAY) {
          shot = LOOP_START_SHOT;
          sustain = true;
          ++laps;
          if (random() & 1)
            targetMirror = -targetMirror;
        }
        interval = float(sustain ? nextInterval() : intervals[shot]);
        inverseInterval = 1 / interval;
      }
    }
    mirror += d.mirrorAlpha * (targetMirror - mirror);
    float x = 0, y = 0;
    if (strength > 0) {
      const float h = float(profile->horizontal) * .01f;
      x = recoil::filterIncrement(
          base.x * BASE_PIXEL_SCALE_X * (mode == MODE_LONG ? .20f : .70f) *
              mirror * h * strength,
          float(dtUs) / BASE_TICK_US, d.emaAlpha, EMA_SMOOTH_ALPHA, filteredX);
      if (!h)
        filteredX = x = 0;
      // Filter only the original component; uniform motion has no EMA ramp.
      y = recoil::filterIncrement((base.y - flat) * strength,
                                  float(dtUs) / BASE_TICK_US, d.emaAlpha,
                                  EMA_SMOOTH_ALPHA, filteredY) +
          flat * strength;
      if (weightedManual == 0)
        filteredY = y = 0;
    } else
      clearFilter();
    const Pair n = noise.step(dtUs, d, profile->noise);
    return {x + n.x, y + n.y};
  }
};
} // namespace movement
