#pragma once
#include "EngineSafety.h"
#include "TuningConfig.h"

namespace movement {
struct Pair {
  float x, y;
};

// A separate non-cryptographic stream for motion noise. Hardware entropy seeds
// it once per hold; preview uses a fixed seed for stable slider comparisons.
struct Noise {
  uint32_t rng = 1, lastDt = 0;
  float driftX = 0, driftY = 0, microX = 0, microY = 0, alpha = 0;
  void reset(uint32_t seed) {
    rng = seed ? seed : 1;
    lastDt = 0;
    driftX = driftY = microX = microY = 0;
  }
  float white() {
    rng ^= rng << 13;
    rng ^= rng >> 17;
    rng ^= rng << 5;
    return float(rng & 0x00ffffffu) * (1.0f / 8388607.5f) - 1.0f;
  }
  Pair step(uint32_t dtUs, const R32TimeDynamics &d, int percent) {
    if (lastDt != dtUs) {
      lastDt = dtUs;
      alpha = float(dtUs) / (12000.0f + float(dtUs));
    }
    driftX = d.driftRho * driftX + d.driftInnovation * white() * .08f;
    driftY = d.driftRho * driftY + d.driftInnovation * white() * .08f;
    microX += alpha * (white() - microX);
    microY += alpha * (white() - microY);
    const float gain = float(percent) * .01f;
    return {(driftX + microX * .10f * d.microScale) * gain,
            (driftY + microY * .10f * d.microScale) * gain};
  }
};

struct HidStep {
  int16_t x, y;
};
// This final fractional-remainder/round/clamp stage is shared verbatim by
// production and preview. Only successful queue submissions consume a step.
struct Quantizer {
  float x = 0, y = 0;
  void clear() { x = y = 0; }
  void add(Pair p) {
    x += p.x;
    y += p.y;
  }
  static int16_t round(float value) {
    if (value > 32767)
      return 32767;
    if (value < -32767)
      return -32767;
    return int16_t(__builtin_lrintf(value));
  }
  HidStep pending() const { return {round(x), round(y)}; }
  void accepted(HidStep p) {
    x -= p.x;
    y -= p.y;
  }
};
} // namespace movement
