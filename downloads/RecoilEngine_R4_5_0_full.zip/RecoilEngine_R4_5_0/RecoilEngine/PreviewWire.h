#pragma once
#include "EngineeringMode.h"
#include <algorithm>
#include <cstdio>
#include <cstring>

namespace engineering {
// Bounded, stateless JSON slices. No response-sized String, reallocations or
// format loop over the complete trajectory inside an AsyncTCP callback.
class PreviewWire {
  const Preview &data;
  char header[600];
  size_t headerSize = 0;

public:
  static constexpr size_t ROW_BYTES = 46;
  PreviewWire(const Preview &p, uint32_t revision, bool longMode, int pattern)
      : data(p) {
    const int n = snprintf(
        header, sizeof(header),
        "{\"revision\":%lu,\"mode\":%u,\"pattern\":%d,"
        "\"bounds\":[%ld,%ld,%ld,%ld],\"durationMs\":%lu,"
        "\"tapUs\":%lu,\"sampleMs\":%lu,"
        "\"targets\":[%.2f,%.2f,%.2f],\"automatic\":[%.0f,%.0f,%.0f],"
        "\"points\":[",
        (unsigned long)revision, unsigned(longMode), pattern, (long)p.minX,
        (long)p.maxX, (long)p.minY, (long)p.maxY, (unsigned long)p.durationMs,
        (unsigned long)p.tapUs, (unsigned long)p.sampleMs,
        double(p.targetPercent[0]), double(p.targetPercent[1]),
        double(p.targetPercent[2]), double(p.autoPercent[0]),
        double(p.autoPercent[1]), double(p.autoPercent[2]));
    if (n > 0 && size_t(n) < sizeof(header))
      headerSize = size_t(n);
  }
  bool valid() const {
    return headerSize && data.count && data.count <= Preview::COUNT;
  }
  size_t length() const { return headerSize + data.count * ROW_BYTES + 2; }
  size_t fill(uint8_t *buffer, size_t capacity, size_t index) const {
    if (!valid() || index >= length())
      return 0;
    size_t written = 0;
    while (written < capacity && index < length()) {
      const char *source;
      size_t available;
      char row[ROW_BYTES + 1];
      if (index < headerSize) {
        source = header + index;
        available = headerSize - index;
      } else if (index < headerSize + data.count * ROW_BYTES) {
        const size_t relative = index - headerSize, i = relative / ROW_BYTES,
                     offset = relative % ROW_BYTES;
        const auto &p = data.points[i];
        const int n = snprintf(row, sizeof(row), "%c[%11ld,%11ld,%8.4f,%10lu]",
                               i ? ',' : ' ', (long)p.x, (long)p.y,
                               double(p.phase), (unsigned long)p.timeUs);
        if (n != int(ROW_BYTES))
          return written;
        source = row + offset;
        available = ROW_BYTES - offset;
      } else {
        const size_t offset = index - headerSize - data.count * ROW_BYTES;
        source = "]}" + offset;
        available = 2 - offset;
      }
      const size_t n = std::min(available, capacity - written);
      memcpy(buffer + written, source, n);
      written += n;
      index += n;
    }
    return written;
  }
};
} // namespace engineering
