#pragma once
#include "TuningModel.h"

namespace tuning {
struct Config {
  Profile profiles[2];
  uint16_t strength = 50; // neutral amplitude 1.00x
  uint16_t transitionMs =
      80; // full width around each boundary at nominal 100 ms/segment
  uint16_t catchupMaxPct = 50;
  uint16_t idleTimeoutSec =
      300; // no connected clients; 0 disables automatic exit
  bool noiseFollowStrength = false;
  bool limitCatchup = true;
  bool continuousWarm = true;
};
inline bool valid(const Config &c) {
  return valid(c.profiles[0]) && valid(c.profiles[1]) && c.strength <= 150 &&
         c.transitionMs <= 100 && c.catchupMaxPct <= 300 &&
         (c.idleTimeoutSec == 0 ||
          (c.idleTimeoutSec >= 30 && c.idleTimeoutSec <= 3600));
}
inline bool equal(const Config &a, const Config &b) {
  return equal(a.profiles[0], b.profiles[0]) &&
         equal(a.profiles[1], b.profiles[1]) && a.strength == b.strength &&
         a.transitionMs == b.transitionMs &&
         a.catchupMaxPct == b.catchupMaxPct &&
         a.idleTimeoutSec == b.idleTimeoutSec &&
         a.noiseFollowStrength == b.noiseFollowStrength &&
         a.limitCatchup == b.limitCatchup &&
         a.continuousWarm == b.continuousWarm;
}
// Old advanced controls are read for migration, then fixed internally. The
// public schema contains only strength and six independent controls per mode.
inline void normalize(Config &c) {
  c.transitionMs = 80;
  c.catchupMaxPct = 50;
  c.idleTimeoutSec = 300;
  c.noiseFollowStrength = false;
  c.limitCatchup = c.continuousWarm = true;
  c.profiles[0].microMs = c.profiles[1].microMs = 12;
}
inline Config legacyConfig(const Profile (&p)[2], uint16_t strength) {
  Config c;
  c.profiles[0] = p[0];
  c.profiles[1] = p[1];
  c.strength = strength;
  migrateProfile(c.profiles[0]);
  migrateProfile(c.profiles[1]);
  normalize(c);
  return c;
}
inline float clamp01(float t) { return t < 0 ? 0 : t > 1 ? 1 : t; }
inline float smooth5(float t) {
  t = clamp01(t);
  const bool reversed = t > 0.5f;
  if (reversed)
    t = 1.0f - t;
  const float y = t * t * t * (t * (t * 6.0f - 15.0f) + 10.0f);
  return reversed ? 1.0f - y : y;
}
inline float sectionGain(const Profile &p, float phase, uint16_t transitionMs) {
  const float here = sectionGain(p, int(phase));
  if (!transitionMs || here == 0)
    return here; // never leak motion inside a disabled section
  const float halfWidth =
      float(transitionMs) * 0.005f; // half width in nominal segments
  const float boundaries[2] = {float(BODY_FIRST), float(TAIL_FIRST)};
  const float gains[3] = {float(100 + p.start) * .01f,
                          float(100 + p.body) * .01f,
                          float(100 + p.tail) * .01f};
  for (unsigned i = 0; i < 2; ++i) {
    const float b = boundaries[i], a = gains[i], z = gains[i + 1];
    if (phase < b - halfWidth || phase > b + halfWidth || a == z)
      continue;
    if (a == 0)
      return z * smooth5((phase - b) / halfWidth);
    if (z == 0)
      return a * (1.0f - smooth5((phase - (b - halfWidth)) / halfWidth));
    return a +
           (z - a) * smooth5((phase - (b - halfWidth)) / (2.0f * halfWidth));
  }
  return here;
}
inline float cooledPhase(float releasedPhase, uint64_t idleUs,
                         uint64_t cooldownUs) {
  if (!cooldownUs || idleUs >= cooldownUs)
    return 0;
  return releasedPhase * (1.0f - smooth5(float(idleUs) / float(cooldownUs)));
}
inline float microSample(float white, float dtUs, int microMs, float &state) {
  if (microMs == 0) {
    state = white;
    return white;
  }
  const float a = dtUs / (float(microMs) * 1000.0f + dtUs);
  state += a * (white - state);
  return state; // bounded by input range, no variance amplification
}
inline float catchupStep(float totalDebt, float progress, float paid,
                         float baseIncrement, uint16_t maxPct) {
  const float wanted = totalDebt * clamp01(progress) - paid;
  const float limit = fabsf(baseIncrement) * float(maxPct) * .01f;
  return wanted < -limit ? -limit : wanted > limit ? limit : wanted;
}
static constexpr size_t CONFIG_BLOB_SIZE = 64;
inline void put16(uint8_t *p, uint16_t n) {
  p[0] = uint8_t(n);
  p[1] = uint8_t(n >> 8);
}
inline uint16_t get16(const uint8_t *p) {
  return uint16_t(p[0]) | (uint16_t(p[1]) << 8);
}
inline void put32(uint8_t *p, uint32_t n) {
  for (unsigned i = 0; i < 4; ++i)
    p[i] = uint8_t(n >> (8 * i));
}
inline uint32_t get32(const uint8_t *p) {
  uint32_t n = 0;
  for (unsigned i = 0; i < 4; ++i)
    n |= uint32_t(p[i]) << (8 * i);
  return n;
}
inline void encodeConfig(const Config &c, uint32_t generation,
                         uint8_t (&out)[CONFIG_BLOB_SIZE]) {
  memset(out, 0, sizeof(out));
  memcpy(out, "S3T5", 4);
  out[4] = 6;
  put16(out + 6, c.strength);
  put32(out + 16, generation);
  size_t at = 20;
  for (const auto &p : c.profiles) {
    const int16_t fields[] = {p.horizontal, p.vertical, p.start,
                              p.body,       p.tail,     p.noise};
    for (int16_t value : fields) {
      put16(out + at, uint16_t(value));
      at += 2;
    }
  }
  put32(out + 60, crc32(out, 60));
}
inline bool decodeConfig(const uint8_t *in, size_t n, Config &out,
                         uint32_t &generation) {
  if (n != CONFIG_BLOB_SIZE || memcmp(in, "S3T5", 4) ||
      (in[4] != 3 && in[4] != 4 && in[4] != 5 && in[4] != 6) ||
      get32(in + 60) != crc32(in, 60))
    return false;
  const bool old = in[4] == 3;
  if (old) {
    const uint16_t timeout = get16(in + 12);
    if ((in[5] & ~7u) || get16(in + 8) > 100 || get16(in + 10) > 300 ||
        (timeout != 0 && (timeout < 30 || timeout > 3600)) || in[14] || in[15])
      return false;
  } else {
    if (in[5])
      return false;
    for (size_t i = 8; i < 16; ++i)
      if (in[i])
        return false;
  }
  for (size_t i = old ? 48 : 44; i < 60; ++i)
    if (in[i])
      return false;
  Config c;
  c.strength = get16(in + 6);
  size_t at = 20;
  for (auto &p : c.profiles) {
    int16_t *fields[] = {&p.horizontal, &p.vertical, &p.start,  &p.body,
                         &p.tail,       &p.noise,    &p.microMs};
    for (unsigned i = 0; i < (old ? 7u : 6u); ++i) {
      const uint16_t v = get16(in + at);
      at += 2;
      *fields[i] = int16_t(v < 32768 ? int(v) : int(v) - 65536);
    }
  }
  if (!valid(c) || (in[4] < 5 && (!validLegacy(c.profiles[0]) ||
                                  !validLegacy(c.profiles[1]))))
    return false;
  if (in[4] < 5) {
    migrateProfile(c.profiles[0]);
    migrateProfile(c.profiles[1]);
  }
  normalize(c);
  out = c;
  generation = get32(in + 16);
  return true;
}
inline bool generationNewer(uint32_t a, uint32_t b) {
  return int32_t(a - b) > 0;
}
} // namespace tuning
