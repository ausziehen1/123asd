#pragma once
#include "TuningConfig.h"
#include <Arduino.h>
#include <cJSON.h>
#include <math.h>
namespace tuning {
inline bool keys(const cJSON *o, int count) {
  return cJSON_IsObject(o) && cJSON_GetArraySize(o) == count;
}
inline bool jsonInt(const cJSON *o, const char *key, int low, int high,
                    int &result) {
  const cJSON *v = cJSON_GetObjectItemCaseSensitive(o, key);
  if (!cJSON_IsNumber(v) || !isfinite(v->valuedouble) || v->valuedouble < low ||
      v->valuedouble > high || floor(v->valuedouble) != v->valuedouble)
    return false;
  result = int(v->valuedouble);
  return true;
}
inline bool jsonBool(const cJSON *o, const char *key, bool &result) {
  const cJSON *v = cJSON_GetObjectItemCaseSensitive(o, key);
  if (!cJSON_IsBool(v))
    return false;
  result = cJSON_IsTrue(v);
  return true;
}
inline bool parseDocument(const String &text, Config &out) {
  if (text.length() > 2048)
    return false;
  int depth = 0;
  bool quoted = false, escape = false;
  for (size_t i = 0; i < text.length(); ++i) {
    const char c = text.c_str()[i];
    if (!c)
      return false;
    if (quoted) {
      if (escape)
        escape = false;
      else if (c == '\\')
        escape = true;
      else if (c == '"')
        quoted = false;
    } else if (c == '"')
      quoted = true;
    else if (c == '{' || c == '[') {
      if (++depth > 8)
        return false;
    } else if (c == '}' || c == ']') {
      if (--depth < 0)
        return false;
    }
  }
  if (depth || quoted)
    return false;
  const char *end = nullptr;
  cJSON *root =
      cJSON_ParseWithLengthOpts(text.c_str(), text.length() + 1, &end, true);
  if (!root)
    return false;
  bool ok = false;
  Config c;
  int schema = 0;
  do {
    if (!jsonInt(root, "schema", 2, 6, schema))
      break;
    const cJSON *body = root;
    if (schema >= 3) {
      if (!keys(root, 2))
        break;
      body = cJSON_GetObjectItemCaseSensitive(root, "config");
      if (!keys(body, schema >= 4 ? 2 : 8))
        break;
    } else if (!keys(root, 3))
      break;
    int strength;
    if (!jsonInt(body, "strength", 0, 150, strength))
      break;
    c.strength = uint16_t(strength);
    const cJSON *profiles = cJSON_GetObjectItemCaseSensitive(body, "profiles");
    if (!cJSON_IsArray(profiles) || cJSON_GetArraySize(profiles) != 2)
      break;
    bool profilesOk = true;
    for (unsigned i = 0; i < 2; ++i) {
      const cJSON *p = cJSON_GetArrayItem(profiles, i);
      if (!keys(p, schema == 3 ? 7 : schema >= 4 ? 6 : 5)) {
        profilesOk = false;
        break;
      }
      const char *names[] = {"horizontal", "vertical", "start",  "body",
                             "tail",       "noise",    "microMs"};
      int16_t *fields[] = {&c.profiles[i].horizontal, &c.profiles[i].vertical,
                           &c.profiles[i].start,      &c.profiles[i].body,
                           &c.profiles[i].tail,       &c.profiles[i].noise,
                           &c.profiles[i].microMs};
      for (unsigned j = 0; j < unsigned(schema == 3   ? 7
                                        : schema >= 4 ? 6
                                                      : 5);
           ++j) {
        int n;
        int low = j >= 2 && j <= 4 ? (schema >= 5 ? -300 : -100) : 0;
        int high = j == 5                                          ? 200
                   : schema >= 5 && (j == 0 || (j >= 2 && j <= 4)) ? 300
                                                                   : 100;
        if (!jsonInt(p, names[j], low, high, n)) {
          profilesOk = false;
          break;
        }
        *fields[j] = int16_t(n);
      }
      if (!profilesOk)
        break;
    }
    if (!profilesOk)
      break;
    if (schema == 2)
      c = legacyConfig(c.profiles, c.strength);
    else if (schema == 3) {
      int transition, catchup, timeout;
      if (!jsonInt(body, "transitionMs", 0, 100, transition) ||
          !jsonInt(body, "catchupMaxPct", 0, 300, catchup) ||
          !jsonInt(body, "idleTimeoutSec", 0, 3600, timeout) ||
          !jsonBool(body, "noiseFollowStrength", c.noiseFollowStrength) ||
          !jsonBool(body, "limitCatchup", c.limitCatchup) ||
          !jsonBool(body, "continuousWarm", c.continuousWarm))
        break;
      c.transitionMs = uint16_t(transition);
      c.catchupMaxPct = uint16_t(catchup);
      c.idleTimeoutSec = uint16_t(timeout);
    }
    if (schema == 3 || schema == 4) {
      migrateProfile(c.profiles[0]);
      migrateProfile(c.profiles[1]);
    }
    ok = valid(c);
    if (ok)
      normalize(c);
  } while (false);
  cJSON_Delete(root);
  if (ok)
    out = c;
  return ok;
}
inline String configJson(const Config &c) {
  const auto &a = c.profiles[0];
  const auto &b = c.profiles[1];
  char text[650];
  snprintf(text, sizeof(text),
           "{\"strength\":%u,\"profiles\":["
           "{\"horizontal\":%d,\"vertical\":%d,\"start\":%d,\"body\":%d,"
           "\"tail\":%d,\"noise\":%d},"
           "{\"horizontal\":%d,\"vertical\":%d,\"start\":%d,\"body\":%d,"
           "\"tail\":%d,\"noise\":%d}]}",
           unsigned(c.strength), a.horizontal, a.vertical, a.start, a.body,
           a.tail, a.noise, b.horizontal, b.vertical, b.start, b.body, b.tail,
           b.noise);
  return String(text);
}
inline String documentJson(const Config &c) {
  return String("{\"schema\":6,\"config\":") + configJson(c) + "}";
}
} // namespace tuning
