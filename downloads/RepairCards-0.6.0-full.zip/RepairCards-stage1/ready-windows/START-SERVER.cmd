@echo off
cd /d "%~dp0"
if exist config.local.json (
  repair_server.exe --config config.local.json
) else (
  repair_server.exe --config config.example.json
)
pause
